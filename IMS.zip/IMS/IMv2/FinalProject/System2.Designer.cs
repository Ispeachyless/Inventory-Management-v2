﻿namespace FinalProject
{
    partial class System2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(System2));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle60 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle61 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle62 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle63 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle64 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Title = new System.Windows.Forms.Panel();
            this.Logo = new System.Windows.Forms.Label();
            this.MainMenu = new System.Windows.Forms.FlowLayoutPanel();
            this.SalesOrderBtn = new System.Windows.Forms.Button();
            this.InvoiceBtn = new System.Windows.Forms.Button();
            this.logOutBtn = new System.Windows.Forms.Button();
            this.exitSys1Btn = new System.Windows.Forms.Button();
            this.SalesOrder = new System.Windows.Forms.Panel();
            this.SOrderUpdate = new System.Windows.Forms.Panel();
            this.SOrderUpExitBtn = new System.Windows.Forms.Button();
            this.SOrderUpStatusBtn = new System.Windows.Forms.Button();
            this.SOrderLbl1 = new System.Windows.Forms.Label();
            this.SOrderStatusCbx1 = new System.Windows.Forms.ComboBox();
            this.SInvoiceLbl2 = new System.Windows.Forms.Label();
            this.InvoiceCbx1 = new System.Windows.Forms.ComboBox();
            this.UpdateSalesStatusLbl = new System.Windows.Forms.Label();
            this.SOrderSearchPanel = new System.Windows.Forms.Panel();
            this.SOrderSearch = new System.Windows.Forms.Button();
            this.TxtOrderSearch = new System.Windows.Forms.TextBox();
            this.SearchLbl12 = new System.Windows.Forms.Label();
            this.OrderCount = new System.Windows.Forms.Label();
            this.SOrderExitBtn1 = new System.Windows.Forms.Button();
            this.SOrderUpdateBtn1 = new System.Windows.Forms.Button();
            this.SOrderDivider = new System.Windows.Forms.Panel();
            this.SOrderNewBtn1 = new System.Windows.Forms.Button();
            this.OSalesTbl = new System.Windows.Forms.DataGridView();
            this.SOrderDate1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOrderID1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOrderInvoice1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOrderCustomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOrderStatus1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOrderDueDate1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOrderEmployeeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Divider = new System.Windows.Forms.Panel();
            this.SalesOrderLbl = new System.Windows.Forms.Label();
            this.Invoice = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.productname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label13 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.lblSubTotal = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblOrder = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.InvoiceTbl = new System.Windows.Forms.DataGridView();
            this.invoicedate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invoiceno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customername = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.duedate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalamount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.print = new System.Windows.Forms.DataGridViewImageColumn();
            this.InvoiceSearchPanel = new System.Windows.Forms.Panel();
            this.InvoiceSearch = new System.Windows.Forms.Button();
            this.TxtInvoiceSearch = new System.Windows.Forms.TextBox();
            this.SearchLbl3 = new System.Windows.Forms.Label();
            this.InvoiceCount = new System.Windows.Forms.Label();
            this.CloseInvoiceBtn = new System.Windows.Forms.Button();
            this.Divider8 = new System.Windows.Forms.Panel();
            this.Divider7 = new System.Windows.Forms.Panel();
            this.Invoicelbl = new System.Windows.Forms.Label();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.NewSOrder = new System.Windows.Forms.Panel();
            this.dueDate1 = new System.Windows.Forms.DateTimePicker();
            this.DueDateLbl = new System.Windows.Forms.Label();
            this.OrderList = new System.Windows.Forms.ListView();
            this.SOrderClear = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.NewSOrderAdd = new System.Windows.Forms.Button();
            this.TxtQuantity = new System.Windows.Forms.TextBox();
            this.SQuantityLabel = new System.Windows.Forms.Label();
            this.SProductCBX = new System.Windows.Forms.ComboBox();
            this.SProductLabel = new System.Windows.Forms.Label();
            this.SCustomerCBX = new System.Windows.Forms.ComboBox();
            this.SCustomerLabel = new System.Windows.Forms.Label();
            this.NewSOrderSave = new System.Windows.Forms.Button();
            this.NewSOrderClose = new System.Windows.Forms.Button();
            this.NewOrderLabel = new System.Windows.Forms.Label();
            this.Title.SuspendLayout();
            this.MainMenu.SuspendLayout();
            this.SalesOrder.SuspendLayout();
            this.SOrderUpdate.SuspendLayout();
            this.SOrderSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OSalesTbl)).BeginInit();
            this.Invoice.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.InvoiceTbl)).BeginInit();
            this.InvoiceSearchPanel.SuspendLayout();
            this.NewSOrder.SuspendLayout();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(16)))), ((int)(((byte)(18)))));
            this.Title.Controls.Add(this.Logo);
            this.Title.Location = new System.Drawing.Point(-6, -5);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(326, 69);
            this.Title.TabIndex = 5;
            // 
            // Logo
            // 
            this.Logo.AutoSize = true;
            this.Logo.Font = new System.Drawing.Font("Futura Hv BT", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Logo.ForeColor = System.Drawing.Color.White;
            this.Logo.Image = ((System.Drawing.Image)(resources.GetObject("Logo.Image")));
            this.Logo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Logo.Location = new System.Drawing.Point(18, 14);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(279, 45);
            this.Logo.TabIndex = 25;
            this.Logo.Text = "     LUMINAIRE";
            // 
            // MainMenu
            // 
            this.MainMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.MainMenu.Controls.Add(this.SalesOrderBtn);
            this.MainMenu.Controls.Add(this.InvoiceBtn);
            this.MainMenu.Controls.Add(this.logOutBtn);
            this.MainMenu.Location = new System.Drawing.Point(0, 54);
            this.MainMenu.Margin = new System.Windows.Forms.Padding(0);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Padding = new System.Windows.Forms.Padding(0, 15, 0, 0);
            this.MainMenu.Size = new System.Drawing.Size(320, 726);
            this.MainMenu.TabIndex = 4;
            // 
            // SalesOrderBtn
            // 
            this.SalesOrderBtn.FlatAppearance.BorderSize = 0;
            this.SalesOrderBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SalesOrderBtn.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalesOrderBtn.ForeColor = System.Drawing.Color.White;
            this.SalesOrderBtn.Image = ((System.Drawing.Image)(resources.GetObject("SalesOrderBtn.Image")));
            this.SalesOrderBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SalesOrderBtn.Location = new System.Drawing.Point(3, 18);
            this.SalesOrderBtn.Name = "SalesOrderBtn";
            this.SalesOrderBtn.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.SalesOrderBtn.Size = new System.Drawing.Size(314, 50);
            this.SalesOrderBtn.TabIndex = 37;
            this.SalesOrderBtn.Text = "         SALES ORDER";
            this.SalesOrderBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SalesOrderBtn.UseVisualStyleBackColor = true;
            this.SalesOrderBtn.Click += new System.EventHandler(this.SalesOrderBtn_Click);
            // 
            // InvoiceBtn
            // 
            this.InvoiceBtn.FlatAppearance.BorderSize = 0;
            this.InvoiceBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InvoiceBtn.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvoiceBtn.ForeColor = System.Drawing.Color.White;
            this.InvoiceBtn.Image = ((System.Drawing.Image)(resources.GetObject("InvoiceBtn.Image")));
            this.InvoiceBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.InvoiceBtn.Location = new System.Drawing.Point(3, 74);
            this.InvoiceBtn.Name = "InvoiceBtn";
            this.InvoiceBtn.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.InvoiceBtn.Size = new System.Drawing.Size(314, 50);
            this.InvoiceBtn.TabIndex = 37;
            this.InvoiceBtn.Text = "         INVOICE";
            this.InvoiceBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.InvoiceBtn.UseVisualStyleBackColor = true;
            this.InvoiceBtn.Click += new System.EventHandler(this.InvoiceBtn_Click);
            // 
            // logOutBtn
            // 
            this.logOutBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.logOutBtn.FlatAppearance.BorderSize = 0;
            this.logOutBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logOutBtn.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logOutBtn.ForeColor = System.Drawing.Color.White;
            this.logOutBtn.Image = ((System.Drawing.Image)(resources.GetObject("logOutBtn.Image")));
            this.logOutBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.logOutBtn.Location = new System.Drawing.Point(3, 130);
            this.logOutBtn.Name = "logOutBtn";
            this.logOutBtn.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.logOutBtn.Size = new System.Drawing.Size(317, 55);
            this.logOutBtn.TabIndex = 28;
            this.logOutBtn.Text = "          LOG OUT";
            this.logOutBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.logOutBtn.UseVisualStyleBackColor = true;
            this.logOutBtn.Click += new System.EventHandler(this.logOutBtn_Click);
            // 
            // exitSys1Btn
            // 
            this.exitSys1Btn.FlatAppearance.BorderSize = 0;
            this.exitSys1Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitSys1Btn.Image = ((System.Drawing.Image)(resources.GetObject("exitSys1Btn.Image")));
            this.exitSys1Btn.Location = new System.Drawing.Point(1340, -5);
            this.exitSys1Btn.Name = "exitSys1Btn";
            this.exitSys1Btn.Size = new System.Drawing.Size(24, 34);
            this.exitSys1Btn.TabIndex = 6;
            this.exitSys1Btn.UseVisualStyleBackColor = true;
            this.exitSys1Btn.Click += new System.EventHandler(this.exitSys1Btn_Click);
            // 
            // SalesOrder
            // 
            this.SalesOrder.Controls.Add(this.SOrderUpdate);
            this.SalesOrder.Controls.Add(this.NewSOrder);
            this.SalesOrder.Controls.Add(this.SOrderSearchPanel);
            this.SalesOrder.Controls.Add(this.OrderCount);
            this.SalesOrder.Controls.Add(this.SOrderExitBtn1);
            this.SalesOrder.Controls.Add(this.SOrderUpdateBtn1);
            this.SalesOrder.Controls.Add(this.SOrderDivider);
            this.SalesOrder.Controls.Add(this.SOrderNewBtn1);
            this.SalesOrder.Controls.Add(this.OSalesTbl);
            this.SalesOrder.Controls.Add(this.Divider);
            this.SalesOrder.Controls.Add(this.SalesOrderLbl);
            this.SalesOrder.Location = new System.Drawing.Point(343, 12);
            this.SalesOrder.Name = "SalesOrder";
            this.SalesOrder.Size = new System.Drawing.Size(998, 735);
            this.SalesOrder.TabIndex = 69;
            this.SalesOrder.Visible = false;
            // 
            // SOrderUpdate
            // 
            this.SOrderUpdate.Controls.Add(this.SOrderUpExitBtn);
            this.SOrderUpdate.Controls.Add(this.SOrderUpStatusBtn);
            this.SOrderUpdate.Controls.Add(this.SOrderLbl1);
            this.SOrderUpdate.Controls.Add(this.SOrderStatusCbx1);
            this.SOrderUpdate.Controls.Add(this.SInvoiceLbl2);
            this.SOrderUpdate.Controls.Add(this.InvoiceCbx1);
            this.SOrderUpdate.Controls.Add(this.UpdateSalesStatusLbl);
            this.SOrderUpdate.Location = new System.Drawing.Point(274, 161);
            this.SOrderUpdate.Name = "SOrderUpdate";
            this.SOrderUpdate.Size = new System.Drawing.Size(444, 394);
            this.SOrderUpdate.TabIndex = 63;
            this.SOrderUpdate.Visible = false;
            // 
            // SOrderUpExitBtn
            // 
            this.SOrderUpExitBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrderUpExitBtn.FlatAppearance.BorderSize = 0;
            this.SOrderUpExitBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrderUpExitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderUpExitBtn.ForeColor = System.Drawing.Color.White;
            this.SOrderUpExitBtn.Image = ((System.Drawing.Image)(resources.GetObject("SOrderUpExitBtn.Image")));
            this.SOrderUpExitBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrderUpExitBtn.Location = new System.Drawing.Point(283, 316);
            this.SOrderUpExitBtn.Name = "SOrderUpExitBtn";
            this.SOrderUpExitBtn.Size = new System.Drawing.Size(128, 42);
            this.SOrderUpExitBtn.TabIndex = 64;
            this.SOrderUpExitBtn.Text = "     Cancel";
            this.SOrderUpExitBtn.UseVisualStyleBackColor = false;
            this.SOrderUpExitBtn.Click += new System.EventHandler(this.SOrderUpExitBtn_Click);
            // 
            // SOrderUpStatusBtn
            // 
            this.SOrderUpStatusBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrderUpStatusBtn.FlatAppearance.BorderSize = 0;
            this.SOrderUpStatusBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrderUpStatusBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderUpStatusBtn.ForeColor = System.Drawing.Color.White;
            this.SOrderUpStatusBtn.Image = ((System.Drawing.Image)(resources.GetObject("SOrderUpStatusBtn.Image")));
            this.SOrderUpStatusBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrderUpStatusBtn.Location = new System.Drawing.Point(149, 316);
            this.SOrderUpStatusBtn.Name = "SOrderUpStatusBtn";
            this.SOrderUpStatusBtn.Size = new System.Drawing.Size(128, 42);
            this.SOrderUpStatusBtn.TabIndex = 81;
            this.SOrderUpStatusBtn.Text = "     Update";
            this.SOrderUpStatusBtn.UseVisualStyleBackColor = false;
            this.SOrderUpStatusBtn.Click += new System.EventHandler(this.SOrderUpStatusBtn_Click);
            // 
            // SOrderLbl1
            // 
            this.SOrderLbl1.AutoSize = true;
            this.SOrderLbl1.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderLbl1.Location = new System.Drawing.Point(99, 190);
            this.SOrderLbl1.Name = "SOrderLbl1";
            this.SOrderLbl1.Size = new System.Drawing.Size(47, 18);
            this.SOrderLbl1.TabIndex = 80;
            this.SOrderLbl1.Text = "Status";
            // 
            // SOrderStatusCbx1
            // 
            this.SOrderStatusCbx1.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderStatusCbx1.FormattingEnabled = true;
            this.SOrderStatusCbx1.Location = new System.Drawing.Point(99, 228);
            this.SOrderStatusCbx1.Name = "SOrderStatusCbx1";
            this.SOrderStatusCbx1.Size = new System.Drawing.Size(244, 27);
            this.SOrderStatusCbx1.TabIndex = 79;
            // 
            // SInvoiceLbl2
            // 
            this.SInvoiceLbl2.AutoSize = true;
            this.SInvoiceLbl2.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SInvoiceLbl2.Location = new System.Drawing.Point(99, 90);
            this.SInvoiceLbl2.Name = "SInvoiceLbl2";
            this.SInvoiceLbl2.Size = new System.Drawing.Size(84, 18);
            this.SInvoiceLbl2.TabIndex = 78;
            this.SInvoiceLbl2.Text = "Invoice No.";
            // 
            // InvoiceCbx1
            // 
            this.InvoiceCbx1.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvoiceCbx1.FormattingEnabled = true;
            this.InvoiceCbx1.Location = new System.Drawing.Point(99, 128);
            this.InvoiceCbx1.Name = "InvoiceCbx1";
            this.InvoiceCbx1.Size = new System.Drawing.Size(244, 27);
            this.InvoiceCbx1.TabIndex = 77;
            this.InvoiceCbx1.SelectedIndexChanged += new System.EventHandler(this.InvoiceCbx1_SelectedIndexChanged);
            // 
            // UpdateSalesStatusLbl
            // 
            this.UpdateSalesStatusLbl.AutoSize = true;
            this.UpdateSalesStatusLbl.Font = new System.Drawing.Font("Futura Bk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateSalesStatusLbl.Location = new System.Drawing.Point(39, 29);
            this.UpdateSalesStatusLbl.Name = "UpdateSalesStatusLbl";
            this.UpdateSalesStatusLbl.Size = new System.Drawing.Size(177, 22);
            this.UpdateSalesStatusLbl.TabIndex = 76;
            this.UpdateSalesStatusLbl.Text = "Update Sales Status";
            // 
            // SOrderSearchPanel
            // 
            this.SOrderSearchPanel.Controls.Add(this.SOrderSearch);
            this.SOrderSearchPanel.Controls.Add(this.TxtOrderSearch);
            this.SOrderSearchPanel.Controls.Add(this.SearchLbl12);
            this.SOrderSearchPanel.Location = new System.Drawing.Point(453, 93);
            this.SOrderSearchPanel.Name = "SOrderSearchPanel";
            this.SOrderSearchPanel.Size = new System.Drawing.Size(517, 42);
            this.SOrderSearchPanel.TabIndex = 86;
            // 
            // SOrderSearch
            // 
            this.SOrderSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrderSearch.FlatAppearance.BorderSize = 0;
            this.SOrderSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrderSearch.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderSearch.ForeColor = System.Drawing.Color.White;
            this.SOrderSearch.Image = ((System.Drawing.Image)(resources.GetObject("SOrderSearch.Image")));
            this.SOrderSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrderSearch.Location = new System.Drawing.Point(390, 0);
            this.SOrderSearch.Name = "SOrderSearch";
            this.SOrderSearch.Size = new System.Drawing.Size(128, 42);
            this.SOrderSearch.TabIndex = 76;
            this.SOrderSearch.Text = "      Search";
            this.SOrderSearch.UseVisualStyleBackColor = false;
            // 
            // TxtOrderSearch
            // 
            this.TxtOrderSearch.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtOrderSearch.Location = new System.Drawing.Point(71, 9);
            this.TxtOrderSearch.Name = "TxtOrderSearch";
            this.TxtOrderSearch.Size = new System.Drawing.Size(310, 25);
            this.TxtOrderSearch.TabIndex = 75;
            // 
            // SearchLbl12
            // 
            this.SearchLbl12.AutoSize = true;
            this.SearchLbl12.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchLbl12.Location = new System.Drawing.Point(7, 12);
            this.SearchLbl12.Name = "SearchLbl12";
            this.SearchLbl12.Size = new System.Drawing.Size(58, 18);
            this.SearchLbl12.TabIndex = 74;
            this.SearchLbl12.Text = "Search:";
            // 
            // OrderCount
            // 
            this.OrderCount.AutoSize = true;
            this.OrderCount.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderCount.Location = new System.Drawing.Point(21, 610);
            this.OrderCount.Name = "OrderCount";
            this.OrderCount.Size = new System.Drawing.Size(128, 18);
            this.OrderCount.TabIndex = 85;
            this.OrderCount.Text = "Total records: ???";
            // 
            // SOrderExitBtn1
            // 
            this.SOrderExitBtn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrderExitBtn1.FlatAppearance.BorderSize = 0;
            this.SOrderExitBtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrderExitBtn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderExitBtn1.ForeColor = System.Drawing.Color.White;
            this.SOrderExitBtn1.Image = ((System.Drawing.Image)(resources.GetObject("SOrderExitBtn1.Image")));
            this.SOrderExitBtn1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrderExitBtn1.Location = new System.Drawing.Point(842, 670);
            this.SOrderExitBtn1.Name = "SOrderExitBtn1";
            this.SOrderExitBtn1.Size = new System.Drawing.Size(128, 42);
            this.SOrderExitBtn1.TabIndex = 62;
            this.SOrderExitBtn1.Text = "     Close";
            this.SOrderExitBtn1.UseVisualStyleBackColor = false;
            this.SOrderExitBtn1.Click += new System.EventHandler(this.SOrderExitBtn1_Click);
            // 
            // SOrderUpdateBtn1
            // 
            this.SOrderUpdateBtn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrderUpdateBtn1.FlatAppearance.BorderSize = 0;
            this.SOrderUpdateBtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrderUpdateBtn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderUpdateBtn1.ForeColor = System.Drawing.Color.White;
            this.SOrderUpdateBtn1.Image = ((System.Drawing.Image)(resources.GetObject("SOrderUpdateBtn1.Image")));
            this.SOrderUpdateBtn1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrderUpdateBtn1.Location = new System.Drawing.Point(688, 670);
            this.SOrderUpdateBtn1.Name = "SOrderUpdateBtn1";
            this.SOrderUpdateBtn1.Size = new System.Drawing.Size(128, 42);
            this.SOrderUpdateBtn1.TabIndex = 60;
            this.SOrderUpdateBtn1.Text = "     Update";
            this.SOrderUpdateBtn1.UseVisualStyleBackColor = false;
            this.SOrderUpdateBtn1.Click += new System.EventHandler(this.SOrderUpdateBtn1_Click);
            // 
            // SOrderDivider
            // 
            this.SOrderDivider.BackColor = System.Drawing.Color.Black;
            this.SOrderDivider.Location = new System.Drawing.Point(24, 650);
            this.SOrderDivider.Name = "SOrderDivider";
            this.SOrderDivider.Size = new System.Drawing.Size(943, 2);
            this.SOrderDivider.TabIndex = 59;
            // 
            // SOrderNewBtn1
            // 
            this.SOrderNewBtn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrderNewBtn1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.SOrderNewBtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrderNewBtn1.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderNewBtn1.ForeColor = System.Drawing.Color.White;
            this.SOrderNewBtn1.Image = ((System.Drawing.Image)(resources.GetObject("SOrderNewBtn1.Image")));
            this.SOrderNewBtn1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrderNewBtn1.Location = new System.Drawing.Point(536, 670);
            this.SOrderNewBtn1.Name = "SOrderNewBtn1";
            this.SOrderNewBtn1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SOrderNewBtn1.Size = new System.Drawing.Size(128, 42);
            this.SOrderNewBtn1.TabIndex = 58;
            this.SOrderNewBtn1.Text = "    New";
            this.SOrderNewBtn1.UseVisualStyleBackColor = false;
            this.SOrderNewBtn1.Click += new System.EventHandler(this.SOrderNewBtn1_Click);
            // 
            // OSalesTbl
            // 
            this.OSalesTbl.AllowUserToAddRows = false;
            this.OSalesTbl.AllowUserToDeleteRows = false;
            this.OSalesTbl.AllowUserToResizeColumns = false;
            this.OSalesTbl.AllowUserToResizeRows = false;
            this.OSalesTbl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.OSalesTbl.BackgroundColor = System.Drawing.Color.White;
            this.OSalesTbl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.OSalesTbl.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.OSalesTbl.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            dataGridViewCellStyle57.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle57.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle57.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle57.SelectionBackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle57.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle57.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.OSalesTbl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle57;
            this.OSalesTbl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.OSalesTbl.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SOrderDate1,
            this.SOrderID1,
            this.SOrderInvoice1,
            this.SOrderCustomer,
            this.SOrderStatus1,
            this.SOrderDueDate1,
            this.SOrderEmployeeID});
            dataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle58.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle58.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle58.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle58.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle58.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle58.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.OSalesTbl.DefaultCellStyle = dataGridViewCellStyle58;
            this.OSalesTbl.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.OSalesTbl.EnableHeadersVisualStyles = false;
            this.OSalesTbl.GridColor = System.Drawing.Color.White;
            this.OSalesTbl.Location = new System.Drawing.Point(27, 145);
            this.OSalesTbl.Margin = new System.Windows.Forms.Padding(0);
            this.OSalesTbl.Name = "OSalesTbl";
            this.OSalesTbl.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle59.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle59.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle59.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle59.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle59.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle59.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.OSalesTbl.RowHeadersDefaultCellStyle = dataGridViewCellStyle59;
            this.OSalesTbl.RowHeadersVisible = false;
            this.OSalesTbl.RowHeadersWidth = 80;
            this.OSalesTbl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle60.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle60.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle60.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.OSalesTbl.RowsDefaultCellStyle = dataGridViewCellStyle60;
            this.OSalesTbl.RowTemplate.Height = 30;
            this.OSalesTbl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.OSalesTbl.Size = new System.Drawing.Size(943, 444);
            this.OSalesTbl.TabIndex = 57;
            // 
            // SOrderDate1
            // 
            this.SOrderDate1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SOrderDate1.FillWeight = 80F;
            this.SOrderDate1.HeaderText = "Date";
            this.SOrderDate1.Name = "SOrderDate1";
            // 
            // SOrderID1
            // 
            this.SOrderID1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SOrderID1.FillWeight = 50F;
            this.SOrderID1.HeaderText = "Order No.";
            this.SOrderID1.Name = "SOrderID1";
            this.SOrderID1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // SOrderInvoice1
            // 
            this.SOrderInvoice1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SOrderInvoice1.FillWeight = 50F;
            this.SOrderInvoice1.HeaderText = "Invoice No.";
            this.SOrderInvoice1.Name = "SOrderInvoice1";
            // 
            // SOrderCustomer
            // 
            this.SOrderCustomer.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SOrderCustomer.HeaderText = "Customer";
            this.SOrderCustomer.Name = "SOrderCustomer";
            // 
            // SOrderStatus1
            // 
            this.SOrderStatus1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SOrderStatus1.FillWeight = 80F;
            this.SOrderStatus1.HeaderText = "Status";
            this.SOrderStatus1.Name = "SOrderStatus1";
            this.SOrderStatus1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // SOrderDueDate1
            // 
            this.SOrderDueDate1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SOrderDueDate1.FillWeight = 80F;
            this.SOrderDueDate1.HeaderText = "Due Date";
            this.SOrderDueDate1.Name = "SOrderDueDate1";
            // 
            // SOrderEmployeeID
            // 
            this.SOrderEmployeeID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SOrderEmployeeID.FillWeight = 50F;
            this.SOrderEmployeeID.HeaderText = "Employee ID";
            this.SOrderEmployeeID.Name = "SOrderEmployeeID";
            // 
            // Divider
            // 
            this.Divider.BackColor = System.Drawing.Color.Black;
            this.Divider.Location = new System.Drawing.Point(27, 76);
            this.Divider.Name = "Divider";
            this.Divider.Size = new System.Drawing.Size(943, 2);
            this.Divider.TabIndex = 56;
            // 
            // SalesOrderLbl
            // 
            this.SalesOrderLbl.AutoSize = true;
            this.SalesOrderLbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalesOrderLbl.ForeColor = System.Drawing.Color.Black;
            this.SalesOrderLbl.Location = new System.Drawing.Point(372, 23);
            this.SalesOrderLbl.Name = "SalesOrderLbl";
            this.SalesOrderLbl.Size = new System.Drawing.Size(228, 39);
            this.SalesOrderLbl.TabIndex = 55;
            this.SalesOrderLbl.Text = "SALES ORDER";
            // 
            // Invoice
            // 
            this.Invoice.Controls.Add(this.panel5);
            this.Invoice.Controls.Add(this.InvoiceTbl);
            this.Invoice.Controls.Add(this.InvoiceSearchPanel);
            this.Invoice.Controls.Add(this.InvoiceCount);
            this.Invoice.Controls.Add(this.CloseInvoiceBtn);
            this.Invoice.Controls.Add(this.Divider8);
            this.Invoice.Controls.Add(this.Divider7);
            this.Invoice.Controls.Add(this.Invoicelbl);
            this.Invoice.Location = new System.Drawing.Point(343, 12);
            this.Invoice.Name = "Invoice";
            this.Invoice.Size = new System.Drawing.Size(998, 735);
            this.Invoice.TabIndex = 72;
            this.Invoice.Visible = false;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.btnClose);
            this.panel5.Controls.Add(this.dataGridView2);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.lblName);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.btnPrint);
            this.panel5.Controls.Add(this.lblSubTotal);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.lblDate);
            this.panel5.Controls.Add(this.lblOrder);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Controls.Add(this.label2);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Location = new System.Drawing.Point(299, 114);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(403, 514);
            this.panel5.TabIndex = 88;
            this.panel5.Visible = false;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.ForeColor = System.Drawing.Color.Black;
            this.btnClose.Location = new System.Drawing.Point(354, -1);
            this.btnClose.Margin = new System.Windows.Forms.Padding(2);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(56, 19);
            this.btnClose.TabIndex = 38;
            this.btnClose.Text = "X";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.ColumnHeadersVisible = false;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productname,
            this.qty,
            this.unitprice,
            this.total});
            this.dataGridView2.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView2.Location = new System.Drawing.Point(5, 193);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowHeadersWidth = 49;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(388, 214);
            this.dataGridView2.TabIndex = 37;
            // 
            // productname
            // 
            this.productname.HeaderText = "Product Name";
            this.productname.MinimumWidth = 6;
            this.productname.Name = "productname";
            this.productname.ReadOnly = true;
            this.productname.Width = 230;
            // 
            // qty
            // 
            this.qty.FillWeight = 150F;
            this.qty.HeaderText = "Qty";
            this.qty.MinimumWidth = 6;
            this.qty.Name = "qty";
            this.qty.ReadOnly = true;
            this.qty.Width = 80;
            // 
            // unitprice
            // 
            this.unitprice.FillWeight = 80F;
            this.unitprice.HeaderText = "Unit Price";
            this.unitprice.MinimumWidth = 6;
            this.unitprice.Name = "unitprice";
            this.unitprice.ReadOnly = true;
            this.unitprice.Width = 130;
            // 
            // total
            // 
            this.total.HeaderText = "Total";
            this.total.MinimumWidth = 6;
            this.total.Name = "total";
            this.total.ReadOnly = true;
            this.total.Width = 130;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(2, 172);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(451, 13);
            this.label13.TabIndex = 36;
            this.label13.Text = "__________________________________________________________________________\r\n";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(97, 115);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(34, 14);
            this.lblName.TabIndex = 35;
            this.lblName.Text = "name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 14);
            this.label1.TabIndex = 34;
            this.label1.Text = "Customer Name:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(344, 158);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 14);
            this.label6.TabIndex = 33;
            this.label6.Text = "Total";
            // 
            // btnPrint
            // 
            this.btnPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrint.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.ForeColor = System.Drawing.Color.White;
            this.btnPrint.Location = new System.Drawing.Point(147, 459);
            this.btnPrint.Margin = new System.Windows.Forms.Padding(2);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(128, 42);
            this.btnPrint.TabIndex = 32;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // lblSubTotal
            // 
            this.lblSubTotal.AutoSize = true;
            this.lblSubTotal.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubTotal.Location = new System.Drawing.Point(326, 427);
            this.lblSubTotal.Name = "lblSubTotal";
            this.lblSubTotal.Size = new System.Drawing.Size(28, 14);
            this.lblSubTotal.TabIndex = 31;
            this.lblSubTotal.Text = "total";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(240, 426);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 14);
            this.label12.TabIndex = 30;
            this.label12.Text = "Total Amount:";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(54, 97);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(28, 14);
            this.lblDate.TabIndex = 29;
            this.lblDate.Text = "date";
            // 
            // lblOrder
            // 
            this.lblOrder.AutoSize = true;
            this.lblOrder.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrder.Location = new System.Drawing.Point(75, 77);
            this.lblOrder.Name = "lblOrder";
            this.lblOrder.Size = new System.Drawing.Size(33, 14);
            this.lblOrder.TabIndex = 28;
            this.lblOrder.Text = "order";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(244, 158);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 14);
            this.label9.TabIndex = 27;
            this.label9.Text = "Unit Price";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(177, 158);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 14);
            this.label8.TabIndex = 26;
            this.label8.Text = "Qty";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(10, 158);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 14);
            this.label7.TabIndex = 25;
            this.label7.Text = "Product Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(2, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(451, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "__________________________________________________________________________\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 14);
            this.label3.TabIndex = 23;
            this.label3.Text = "Date :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 14);
            this.label2.TabIndex = 22;
            this.label2.Text = "Invoice No: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(142, 24);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 25);
            this.label10.TabIndex = 21;
            this.label10.Text = "LUMINAIRE";
            // 
            // InvoiceTbl
            // 
            this.InvoiceTbl.AllowUserToAddRows = false;
            this.InvoiceTbl.AllowUserToDeleteRows = false;
            this.InvoiceTbl.AllowUserToResizeColumns = false;
            this.InvoiceTbl.AllowUserToResizeRows = false;
            this.InvoiceTbl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.InvoiceTbl.BackgroundColor = System.Drawing.Color.White;
            this.InvoiceTbl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.InvoiceTbl.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.InvoiceTbl.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle61.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle61.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            dataGridViewCellStyle61.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle61.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle61.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle61.SelectionBackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle61.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle61.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.InvoiceTbl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle61;
            this.InvoiceTbl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.InvoiceTbl.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.invoicedate,
            this.invoiceno,
            this.customername,
            this.duedate,
            this.totalamount,
            this.print});
            dataGridViewCellStyle62.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle62.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle62.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle62.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle62.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle62.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle62.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.InvoiceTbl.DefaultCellStyle = dataGridViewCellStyle62;
            this.InvoiceTbl.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.InvoiceTbl.EnableHeadersVisualStyles = false;
            this.InvoiceTbl.GridColor = System.Drawing.Color.White;
            this.InvoiceTbl.Location = new System.Drawing.Point(27, 145);
            this.InvoiceTbl.Margin = new System.Windows.Forms.Padding(0);
            this.InvoiceTbl.Name = "InvoiceTbl";
            this.InvoiceTbl.ReadOnly = true;
            this.InvoiceTbl.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle63.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle63.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle63.Font = new System.Drawing.Font("Futura Bk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle63.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle63.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle63.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle63.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.InvoiceTbl.RowHeadersDefaultCellStyle = dataGridViewCellStyle63;
            this.InvoiceTbl.RowHeadersVisible = false;
            this.InvoiceTbl.RowHeadersWidth = 80;
            this.InvoiceTbl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle64.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle64.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle64.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle64.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.InvoiceTbl.RowsDefaultCellStyle = dataGridViewCellStyle64;
            this.InvoiceTbl.RowTemplate.Height = 30;
            this.InvoiceTbl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.InvoiceTbl.Size = new System.Drawing.Size(943, 444);
            this.InvoiceTbl.TabIndex = 87;
            this.InvoiceTbl.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // invoicedate
            // 
            this.invoicedate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.invoicedate.HeaderText = "Invoice Date";
            this.invoicedate.MinimumWidth = 6;
            this.invoicedate.Name = "invoicedate";
            this.invoicedate.ReadOnly = true;
            // 
            // invoiceno
            // 
            this.invoiceno.HeaderText = "Invoice No.";
            this.invoiceno.MinimumWidth = 6;
            this.invoiceno.Name = "invoiceno";
            this.invoiceno.ReadOnly = true;
            this.invoiceno.Width = 120;
            // 
            // customername
            // 
            this.customername.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.customername.HeaderText = "Customer Name";
            this.customername.MinimumWidth = 6;
            this.customername.Name = "customername";
            this.customername.ReadOnly = true;
            // 
            // duedate
            // 
            this.duedate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.duedate.HeaderText = "Due Date";
            this.duedate.MinimumWidth = 6;
            this.duedate.Name = "duedate";
            this.duedate.ReadOnly = true;
            // 
            // totalamount
            // 
            this.totalamount.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.totalamount.HeaderText = "Total Amount";
            this.totalamount.MinimumWidth = 6;
            this.totalamount.Name = "totalamount";
            this.totalamount.ReadOnly = true;
            this.totalamount.Width = 105;
            // 
            // print
            // 
            this.print.FillWeight = 30F;
            this.print.HeaderText = "";
            this.print.Image = ((System.Drawing.Image)(resources.GetObject("print.Image")));
            this.print.MinimumWidth = 6;
            this.print.Name = "print";
            this.print.ReadOnly = true;
            this.print.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.print.Width = 30;
            // 
            // InvoiceSearchPanel
            // 
            this.InvoiceSearchPanel.Controls.Add(this.InvoiceSearch);
            this.InvoiceSearchPanel.Controls.Add(this.TxtInvoiceSearch);
            this.InvoiceSearchPanel.Controls.Add(this.SearchLbl3);
            this.InvoiceSearchPanel.Location = new System.Drawing.Point(453, 93);
            this.InvoiceSearchPanel.Name = "InvoiceSearchPanel";
            this.InvoiceSearchPanel.Size = new System.Drawing.Size(518, 42);
            this.InvoiceSearchPanel.TabIndex = 86;
            // 
            // InvoiceSearch
            // 
            this.InvoiceSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.InvoiceSearch.FlatAppearance.BorderSize = 0;
            this.InvoiceSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InvoiceSearch.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvoiceSearch.ForeColor = System.Drawing.Color.White;
            this.InvoiceSearch.Image = ((System.Drawing.Image)(resources.GetObject("InvoiceSearch.Image")));
            this.InvoiceSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.InvoiceSearch.Location = new System.Drawing.Point(390, 0);
            this.InvoiceSearch.Name = "InvoiceSearch";
            this.InvoiceSearch.Size = new System.Drawing.Size(128, 42);
            this.InvoiceSearch.TabIndex = 76;
            this.InvoiceSearch.Text = "      Search";
            this.InvoiceSearch.UseVisualStyleBackColor = false;
            this.InvoiceSearch.Click += new System.EventHandler(this.InvoiceSearch_Click);
            // 
            // TxtInvoiceSearch
            // 
            this.TxtInvoiceSearch.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtInvoiceSearch.Location = new System.Drawing.Point(71, 9);
            this.TxtInvoiceSearch.Name = "TxtInvoiceSearch";
            this.TxtInvoiceSearch.Size = new System.Drawing.Size(310, 25);
            this.TxtInvoiceSearch.TabIndex = 75;
            // 
            // SearchLbl3
            // 
            this.SearchLbl3.AutoSize = true;
            this.SearchLbl3.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchLbl3.Location = new System.Drawing.Point(7, 12);
            this.SearchLbl3.Name = "SearchLbl3";
            this.SearchLbl3.Size = new System.Drawing.Size(58, 18);
            this.SearchLbl3.TabIndex = 74;
            this.SearchLbl3.Text = "Search:";
            // 
            // InvoiceCount
            // 
            this.InvoiceCount.AutoSize = true;
            this.InvoiceCount.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvoiceCount.Location = new System.Drawing.Point(21, 610);
            this.InvoiceCount.Name = "InvoiceCount";
            this.InvoiceCount.Size = new System.Drawing.Size(128, 18);
            this.InvoiceCount.TabIndex = 85;
            this.InvoiceCount.Text = "Total records: ???";
            // 
            // CloseInvoiceBtn
            // 
            this.CloseInvoiceBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.CloseInvoiceBtn.FlatAppearance.BorderSize = 0;
            this.CloseInvoiceBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CloseInvoiceBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CloseInvoiceBtn.ForeColor = System.Drawing.Color.White;
            this.CloseInvoiceBtn.Image = ((System.Drawing.Image)(resources.GetObject("CloseInvoiceBtn.Image")));
            this.CloseInvoiceBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CloseInvoiceBtn.Location = new System.Drawing.Point(842, 670);
            this.CloseInvoiceBtn.Name = "CloseInvoiceBtn";
            this.CloseInvoiceBtn.Size = new System.Drawing.Size(128, 42);
            this.CloseInvoiceBtn.TabIndex = 62;
            this.CloseInvoiceBtn.Text = "     Close";
            this.CloseInvoiceBtn.UseVisualStyleBackColor = false;
            this.CloseInvoiceBtn.Click += new System.EventHandler(this.CloseInvoiceBtn_Click);
            // 
            // Divider8
            // 
            this.Divider8.BackColor = System.Drawing.Color.Black;
            this.Divider8.Location = new System.Drawing.Point(24, 650);
            this.Divider8.Name = "Divider8";
            this.Divider8.Size = new System.Drawing.Size(943, 2);
            this.Divider8.TabIndex = 59;
            // 
            // Divider7
            // 
            this.Divider7.BackColor = System.Drawing.Color.Black;
            this.Divider7.Location = new System.Drawing.Point(27, 76);
            this.Divider7.Name = "Divider7";
            this.Divider7.Size = new System.Drawing.Size(943, 2);
            this.Divider7.TabIndex = 56;
            // 
            // Invoicelbl
            // 
            this.Invoicelbl.AutoSize = true;
            this.Invoicelbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Invoicelbl.ForeColor = System.Drawing.Color.Black;
            this.Invoicelbl.Location = new System.Drawing.Point(448, 18);
            this.Invoicelbl.Name = "Invoicelbl";
            this.Invoicelbl.Size = new System.Drawing.Size(154, 39);
            this.Invoicelbl.TabIndex = 55;
            this.Invoicelbl.Text = "INVOICE";
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage_1);
            // 
            // NewSOrder
            // 
            this.NewSOrder.Controls.Add(this.dueDate1);
            this.NewSOrder.Controls.Add(this.DueDateLbl);
            this.NewSOrder.Controls.Add(this.OrderList);
            this.NewSOrder.Controls.Add(this.SOrderClear);
            this.NewSOrder.Controls.Add(this.label5);
            this.NewSOrder.Controls.Add(this.NewSOrderAdd);
            this.NewSOrder.Controls.Add(this.TxtQuantity);
            this.NewSOrder.Controls.Add(this.SQuantityLabel);
            this.NewSOrder.Controls.Add(this.SProductCBX);
            this.NewSOrder.Controls.Add(this.SProductLabel);
            this.NewSOrder.Controls.Add(this.SCustomerCBX);
            this.NewSOrder.Controls.Add(this.SCustomerLabel);
            this.NewSOrder.Controls.Add(this.NewSOrderSave);
            this.NewSOrder.Controls.Add(this.NewSOrderClose);
            this.NewSOrder.Controls.Add(this.NewOrderLabel);
            this.NewSOrder.Location = new System.Drawing.Point(192, 159);
            this.NewSOrder.Name = "NewSOrder";
            this.NewSOrder.Size = new System.Drawing.Size(614, 416);
            this.NewSOrder.TabIndex = 88;
            this.NewSOrder.Visible = false;
            // 
            // dueDate1
            // 
            this.dueDate1.CustomFormat = "yyyy-MM-dd";
            this.dueDate1.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dueDate1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dueDate1.Location = new System.Drawing.Point(39, 279);
            this.dueDate1.Name = "dueDate1";
            this.dueDate1.Size = new System.Drawing.Size(258, 27);
            this.dueDate1.TabIndex = 93;
            // 
            // DueDateLbl
            // 
            this.DueDateLbl.AutoSize = true;
            this.DueDateLbl.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DueDateLbl.Location = new System.Drawing.Point(39, 248);
            this.DueDateLbl.Name = "DueDateLbl";
            this.DueDateLbl.Size = new System.Drawing.Size(71, 18);
            this.DueDateLbl.TabIndex = 92;
            this.DueDateLbl.Text = "Due Date";
            // 
            // OrderList
            // 
            this.OrderList.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderList.HideSelection = false;
            this.OrderList.Location = new System.Drawing.Point(327, 112);
            this.OrderList.Name = "OrderList";
            this.OrderList.Size = new System.Drawing.Size(250, 192);
            this.OrderList.TabIndex = 91;
            this.OrderList.UseCompatibleStateImageBehavior = false;
            // 
            // SOrderClear
            // 
            this.SOrderClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrderClear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.SOrderClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrderClear.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderClear.ForeColor = System.Drawing.Color.White;
            this.SOrderClear.Image = ((System.Drawing.Image)(resources.GetObject("SOrderClear.Image")));
            this.SOrderClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrderClear.Location = new System.Drawing.Point(38, 334);
            this.SOrderClear.Name = "SOrderClear";
            this.SOrderClear.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SOrderClear.Size = new System.Drawing.Size(128, 42);
            this.SOrderClear.TabIndex = 90;
            this.SOrderClear.Text = "    Clear";
            this.SOrderClear.UseVisualStyleBackColor = false;
            this.SOrderClear.Click += new System.EventHandler(this.SOrderClear_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(324, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 18);
            this.label5.TabIndex = 89;
            this.label5.Text = "Order List";
            // 
            // NewSOrderAdd
            // 
            this.NewSOrderAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.NewSOrderAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.NewSOrderAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewSOrderAdd.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewSOrderAdd.ForeColor = System.Drawing.Color.White;
            this.NewSOrderAdd.Image = ((System.Drawing.Image)(resources.GetObject("NewSOrderAdd.Image")));
            this.NewSOrderAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NewSOrderAdd.Location = new System.Drawing.Point(175, 334);
            this.NewSOrderAdd.Name = "NewSOrderAdd";
            this.NewSOrderAdd.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.NewSOrderAdd.Size = new System.Drawing.Size(128, 42);
            this.NewSOrderAdd.TabIndex = 87;
            this.NewSOrderAdd.Text = "    Add";
            this.NewSOrderAdd.UseVisualStyleBackColor = false;
            this.NewSOrderAdd.Click += new System.EventHandler(this.NewSOrderAdd_Click);
            // 
            // TxtQuantity
            // 
            this.TxtQuantity.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtQuantity.Location = new System.Drawing.Point(200, 197);
            this.TxtQuantity.Name = "TxtQuantity";
            this.TxtQuantity.Size = new System.Drawing.Size(97, 25);
            this.TxtQuantity.TabIndex = 86;
            // 
            // SQuantityLabel
            // 
            this.SQuantityLabel.AutoSize = true;
            this.SQuantityLabel.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SQuantityLabel.Location = new System.Drawing.Point(197, 158);
            this.SQuantityLabel.Name = "SQuantityLabel";
            this.SQuantityLabel.Size = new System.Drawing.Size(65, 18);
            this.SQuantityLabel.TabIndex = 85;
            this.SQuantityLabel.Text = "Quantity";
            // 
            // SProductCBX
            // 
            this.SProductCBX.DropDownWidth = 335;
            this.SProductCBX.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SProductCBX.FormattingEnabled = true;
            this.SProductCBX.Location = new System.Drawing.Point(40, 195);
            this.SProductCBX.Name = "SProductCBX";
            this.SProductCBX.Size = new System.Drawing.Size(140, 27);
            this.SProductCBX.TabIndex = 84;
            // 
            // SProductLabel
            // 
            this.SProductLabel.AutoSize = true;
            this.SProductLabel.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SProductLabel.Location = new System.Drawing.Point(40, 158);
            this.SProductLabel.Name = "SProductLabel";
            this.SProductLabel.Size = new System.Drawing.Size(58, 18);
            this.SProductLabel.TabIndex = 83;
            this.SProductLabel.Text = "Product";
            // 
            // SCustomerCBX
            // 
            this.SCustomerCBX.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SCustomerCBX.Location = new System.Drawing.Point(42, 112);
            this.SCustomerCBX.Name = "SCustomerCBX";
            this.SCustomerCBX.Size = new System.Drawing.Size(256, 27);
            this.SCustomerCBX.TabIndex = 82;
            // 
            // SCustomerLabel
            // 
            this.SCustomerLabel.AutoSize = true;
            this.SCustomerLabel.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SCustomerLabel.Location = new System.Drawing.Point(39, 76);
            this.SCustomerLabel.Name = "SCustomerLabel";
            this.SCustomerLabel.Size = new System.Drawing.Size(72, 18);
            this.SCustomerLabel.TabIndex = 81;
            this.SCustomerLabel.Text = "Customer";
            // 
            // NewSOrderSave
            // 
            this.NewSOrderSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.NewSOrderSave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.NewSOrderSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewSOrderSave.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewSOrderSave.ForeColor = System.Drawing.Color.White;
            this.NewSOrderSave.Image = ((System.Drawing.Image)(resources.GetObject("NewSOrderSave.Image")));
            this.NewSOrderSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NewSOrderSave.Location = new System.Drawing.Point(310, 334);
            this.NewSOrderSave.Name = "NewSOrderSave";
            this.NewSOrderSave.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.NewSOrderSave.Size = new System.Drawing.Size(128, 42);
            this.NewSOrderSave.TabIndex = 77;
            this.NewSOrderSave.Text = "    Save";
            this.NewSOrderSave.UseVisualStyleBackColor = false;
            this.NewSOrderSave.Click += new System.EventHandler(this.NewSOrderSave_Click);
            // 
            // NewSOrderClose
            // 
            this.NewSOrderClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.NewSOrderClose.FlatAppearance.BorderSize = 0;
            this.NewSOrderClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewSOrderClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewSOrderClose.ForeColor = System.Drawing.Color.White;
            this.NewSOrderClose.Image = ((System.Drawing.Image)(resources.GetObject("NewSOrderClose.Image")));
            this.NewSOrderClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NewSOrderClose.Location = new System.Drawing.Point(447, 334);
            this.NewSOrderClose.Name = "NewSOrderClose";
            this.NewSOrderClose.Size = new System.Drawing.Size(128, 42);
            this.NewSOrderClose.TabIndex = 64;
            this.NewSOrderClose.Text = "     Cancel";
            this.NewSOrderClose.UseVisualStyleBackColor = false;
            this.NewSOrderClose.Click += new System.EventHandler(this.NewSOrderClose_Click_1);
            // 
            // NewOrderLabel
            // 
            this.NewOrderLabel.AutoSize = true;
            this.NewOrderLabel.Font = new System.Drawing.Font("Futura Bk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewOrderLabel.Location = new System.Drawing.Point(39, 29);
            this.NewOrderLabel.Name = "NewOrderLabel";
            this.NewOrderLabel.Size = new System.Drawing.Size(106, 22);
            this.NewOrderLabel.TabIndex = 76;
            this.NewOrderLabel.Text = "New Order";
            // 
            // System2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1363, 755);
            this.ControlBox = false;
            this.Controls.Add(this.SalesOrder);
            this.Controls.Add(this.Invoice);
            this.Controls.Add(this.exitSys1Btn);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.MainMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "System2";
            this.Load += new System.EventHandler(this.System2_Load);
            this.Title.ResumeLayout(false);
            this.Title.PerformLayout();
            this.MainMenu.ResumeLayout(false);
            this.SalesOrder.ResumeLayout(false);
            this.SalesOrder.PerformLayout();
            this.SOrderUpdate.ResumeLayout(false);
            this.SOrderUpdate.PerformLayout();
            this.SOrderSearchPanel.ResumeLayout(false);
            this.SOrderSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OSalesTbl)).EndInit();
            this.Invoice.ResumeLayout(false);
            this.Invoice.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.InvoiceTbl)).EndInit();
            this.InvoiceSearchPanel.ResumeLayout(false);
            this.InvoiceSearchPanel.PerformLayout();
            this.NewSOrder.ResumeLayout(false);
            this.NewSOrder.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Title;
        private System.Windows.Forms.Label Logo;
        private System.Windows.Forms.FlowLayoutPanel MainMenu;
        private System.Windows.Forms.Button logOutBtn;
        private System.Windows.Forms.Button SalesOrderBtn;
        private System.Windows.Forms.Button InvoiceBtn;
        private System.Windows.Forms.Button exitSys1Btn;
        private System.Windows.Forms.Panel SalesOrder;
        private System.Windows.Forms.Panel SOrderUpdate;
        private System.Windows.Forms.Button SOrderUpExitBtn;
        private System.Windows.Forms.Button SOrderUpStatusBtn;
        private System.Windows.Forms.Label SOrderLbl1;
        private System.Windows.Forms.ComboBox SOrderStatusCbx1;
        private System.Windows.Forms.Label SInvoiceLbl2;
        private System.Windows.Forms.ComboBox InvoiceCbx1;
        private System.Windows.Forms.Label UpdateSalesStatusLbl;
        private System.Windows.Forms.Panel SOrderSearchPanel;
        private System.Windows.Forms.Button SOrderSearch;
        private System.Windows.Forms.TextBox TxtOrderSearch;
        private System.Windows.Forms.Label SearchLbl12;
        private System.Windows.Forms.Label OrderCount;
        private System.Windows.Forms.Button SOrderExitBtn1;
        private System.Windows.Forms.Button SOrderUpdateBtn1;
        private System.Windows.Forms.Panel SOrderDivider;
        private System.Windows.Forms.Button SOrderNewBtn1;
        private System.Windows.Forms.Panel Divider;
        private System.Windows.Forms.Label SalesOrderLbl;
        private System.Windows.Forms.Panel Invoice;
        private System.Windows.Forms.Panel InvoiceSearchPanel;
        private System.Windows.Forms.Button InvoiceSearch;
        private System.Windows.Forms.TextBox TxtInvoiceSearch;
        private System.Windows.Forms.Label SearchLbl3;
        private System.Windows.Forms.Label InvoiceCount;
        private System.Windows.Forms.Button CloseInvoiceBtn;
        private System.Windows.Forms.Panel Divider8;
        private System.Windows.Forms.Panel Divider7;
        private System.Windows.Forms.Label Invoicelbl;
        public System.Windows.Forms.DataGridView OSalesTbl;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOrderDate1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOrderID1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOrderInvoice1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOrderCustomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOrderStatus1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOrderDueDate1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOrderEmployeeID;
        public System.Windows.Forms.DataGridView InvoiceTbl;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn productname;
        private System.Windows.Forms.DataGridViewTextBoxColumn qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitprice;
        private System.Windows.Forms.DataGridViewTextBoxColumn total;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Label lblSubTotal;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblOrder;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoicedate;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoiceno;
        private System.Windows.Forms.DataGridViewTextBoxColumn customername;
        private System.Windows.Forms.DataGridViewTextBoxColumn duedate;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalamount;
        private System.Windows.Forms.DataGridViewImageColumn print;
        private System.Windows.Forms.Panel NewSOrder;
        private System.Windows.Forms.DateTimePicker dueDate1;
        private System.Windows.Forms.Label DueDateLbl;
        private System.Windows.Forms.ListView OrderList;
        private System.Windows.Forms.Button SOrderClear;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button NewSOrderAdd;
        private System.Windows.Forms.TextBox TxtQuantity;
        private System.Windows.Forms.Label SQuantityLabel;
        private System.Windows.Forms.ComboBox SProductCBX;
        private System.Windows.Forms.Label SProductLabel;
        private System.Windows.Forms.ComboBox SCustomerCBX;
        private System.Windows.Forms.Label SCustomerLabel;
        private System.Windows.Forms.Button NewSOrderSave;
        private System.Windows.Forms.Button NewSOrderClose;
        private System.Windows.Forms.Label NewOrderLabel;
    }
}