﻿namespace FinalProject
{
    partial class System1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(System1));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            this.exitSys1Btn = new System.Windows.Forms.Button();
            this.ContactsTransition = new System.Windows.Forms.Timer(this.components);
            this.SalesTransition = new System.Windows.Forms.Timer(this.components);
            this.ReportTransition = new System.Windows.Forms.Timer(this.components);
            this.Dashboard = new System.Windows.Forms.Panel();
            this.Divider1 = new System.Windows.Forms.Panel();
            this.SalesChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.SalesOrderSummaryLbl = new System.Windows.Forms.Label();
            this.OrderPlacedCount = new System.Windows.Forms.Label();
            this.InTransitCount = new System.Windows.Forms.Label();
            this.DashboardLbl = new System.Windows.Forms.Label();
            this.TotalSalesLbl = new System.Windows.Forms.Label();
            this.TotalSalesCount = new System.Windows.Forms.Label();
            this.CompletedLbl = new System.Windows.Forms.Label();
            this.InTransitLbl = new System.Windows.Forms.Label();
            this.OrderPlacedLbl = new System.Windows.Forms.Label();
            this.CompletedCount = new System.Windows.Forms.Label();
            this.SalesActivityLbl = new System.Windows.Forms.Label();
            this.StockPanel = new System.Windows.Forms.Panel();
            this.TotalStock = new System.Windows.Forms.Label();
            this.StockPic = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.TotalStockLbl = new System.Windows.Forms.Label();
            this.ItemPanel = new System.Windows.Forms.Panel();
            this.TotalItems = new System.Windows.Forms.Label();
            this.ItemPic = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.TotalItemLbl = new System.Windows.Forms.Label();
            this.CustomerPanel = new System.Windows.Forms.Panel();
            this.TotalCus = new System.Windows.Forms.Label();
            this.CustomerPic = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.TotalCustomer = new System.Windows.Forms.Label();
            this.logOutBtn = new System.Windows.Forms.Button();
            this.MReport = new System.Windows.Forms.FlowLayoutPanel();
            this.ReportBtn = new System.Windows.Forms.Button();
            this.RAuditLog = new System.Windows.Forms.Button();
            this.RLowStock = new System.Windows.Forms.Button();
            this.RCompletedSales = new System.Windows.Forms.Button();
            this.RPaymentsReceived = new System.Windows.Forms.Button();
            this.RInventorySummary = new System.Windows.Forms.Button();
            this.MSales = new System.Windows.Forms.FlowLayoutPanel();
            this.SalesBtn = new System.Windows.Forms.Button();
            this.SOrder = new System.Windows.Forms.Button();
            this.SInvoice = new System.Windows.Forms.Button();
            this.SReturn = new System.Windows.Forms.Button();
            this.DashboardBtn = new System.Windows.Forms.Button();
            this.MainMenu = new System.Windows.Forms.FlowLayoutPanel();
            this.ContactsBtn = new System.Windows.Forms.Button();
            this.MInventory = new System.Windows.Forms.FlowLayoutPanel();
            this.InventoryBtn = new System.Windows.Forms.Button();
            this.ItemBtn = new System.Windows.Forms.Button();
            this.ItemProductionBtn = new System.Windows.Forms.Button();
            this.Logo = new System.Windows.Forms.Label();
            this.Title = new System.Windows.Forms.Panel();
            this.InventoryTransition = new System.Windows.Forms.Timer(this.components);
            this.Contacts = new System.Windows.Forms.Panel();
            this.ContactsSearchPanel = new System.Windows.Forms.Panel();
            this.ContactsSearch = new System.Windows.Forms.Button();
            this.TxtSearch = new System.Windows.Forms.TextBox();
            this.SearchLbl1 = new System.Windows.Forms.Label();
            this.NewCus = new System.Windows.Forms.Panel();
            this.NewCustomerContact = new System.Windows.Forms.Label();
            this.txtPNum = new System.Windows.Forms.TextBox();
            this.PhoneNumber = new System.Windows.Forms.Label();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.LastName = new System.Windows.Forms.Label();
            this.FirstName = new System.Windows.Forms.Label();
            this.CusCancel = new System.Windows.Forms.Button();
            this.CusSaveBtn = new System.Windows.Forms.Button();
            this.CustomerTbl = new System.Windows.Forms.DataGridView();
            this.FullName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PNumber2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmployeeTbl = new System.Windows.Forms.DataGridView();
            this.EmployeeId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerCount = new System.Windows.Forms.Label();
            this.EmployeeCount = new System.Windows.Forms.Label();
            this.cusNew = new System.Windows.Forms.Button();
            this.Divider4 = new System.Windows.Forms.Panel();
            this.CusLbl = new System.Windows.Forms.Label();
            this.ContactsCloseBtn = new System.Windows.Forms.Button();
            this.Divider3 = new System.Windows.Forms.Panel();
            this.Divider2 = new System.Windows.Forms.Panel();
            this.EmpLbl = new System.Windows.Forms.Label();
            this.SalesOrder = new System.Windows.Forms.Panel();
            this.SOrderUpdate = new System.Windows.Forms.Panel();
            this.SOrderUpExitBtn = new System.Windows.Forms.Button();
            this.SOrderUpStatusBtn = new System.Windows.Forms.Button();
            this.SOrderLbl1 = new System.Windows.Forms.Label();
            this.SOrderStatusCbx1 = new System.Windows.Forms.ComboBox();
            this.SInvoiceLbl2 = new System.Windows.Forms.Label();
            this.InvoiceCbx1 = new System.Windows.Forms.ComboBox();
            this.UpdateSalesStatusLbl = new System.Windows.Forms.Label();
            this.NewSOrder = new System.Windows.Forms.Panel();
            this.DueDate = new System.Windows.Forms.DateTimePicker();
            this.DueDateLbl = new System.Windows.Forms.Label();
            this.OrderList = new System.Windows.Forms.ListView();
            this.SOrderClear = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.NewSOrderAdd = new System.Windows.Forms.Button();
            this.TxtQuantity = new System.Windows.Forms.TextBox();
            this.SQuantityLabel = new System.Windows.Forms.Label();
            this.SProductCBX = new System.Windows.Forms.ComboBox();
            this.SProductLabel = new System.Windows.Forms.Label();
            this.SCustomerCBX = new System.Windows.Forms.ComboBox();
            this.SCustomerLabel = new System.Windows.Forms.Label();
            this.NewSOrderSave = new System.Windows.Forms.Button();
            this.NewSOrderClose = new System.Windows.Forms.Button();
            this.NewOrderLabel = new System.Windows.Forms.Label();
            this.SOrderSearchPanel = new System.Windows.Forms.Panel();
            this.SOrderSearch = new System.Windows.Forms.Button();
            this.TxtOrderSearch = new System.Windows.Forms.TextBox();
            this.SearchLbl12 = new System.Windows.Forms.Label();
            this.OrderCount = new System.Windows.Forms.Label();
            this.SOrderExitBtn1 = new System.Windows.Forms.Button();
            this.OSalesTbl = new System.Windows.Forms.DataGridView();
            this.SOrderDate1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOrderID1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOrderInvoice1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOrderCustomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOrderStatus1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOrderDueDate1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOrderEmployeeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOrderUpdateBtn1 = new System.Windows.Forms.Button();
            this.SOrderDivider = new System.Windows.Forms.Panel();
            this.SOrderNewBtn1 = new System.Windows.Forms.Button();
            this.Divider = new System.Windows.Forms.Panel();
            this.SalesOrderLbl = new System.Windows.Forms.Label();
            this.Item = new System.Windows.Forms.Panel();
            this.pnl_AddItem = new System.Windows.Forms.Panel();
            this.txtbx_ROrdrLvl = new System.Windows.Forms.TextBox();
            this.lbl_ROrdrLvl = new System.Windows.Forms.Label();
            this.txtbx_Dscrptn = new System.Windows.Forms.TextBox();
            this.lbl_Dscptn = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtbx_Prc = new System.Windows.Forms.TextBox();
            this.lbl_Prc = new System.Windows.Forms.Label();
            this.txtbx_Nme = new System.Windows.Forms.TextBox();
            this.lbl_ItmNme = new System.Windows.Forms.Label();
            this.AddItmCnclbttn = new System.Windows.Forms.Button();
            this.bttnAddItm = new System.Windows.Forms.Button();
            this.pnl_UpdtPrc = new System.Windows.Forms.Panel();
            this.comboBox_ProductID = new System.Windows.Forms.ComboBox();
            this.UpdatePrce = new System.Windows.Forms.Label();
            this.TxtbxUntPrc = new System.Windows.Forms.TextBox();
            this.lblUntPrc = new System.Windows.Forms.Label();
            this.lblPrdctNme = new System.Windows.Forms.Label();
            this.bttnUpdte = new System.Windows.Forms.Button();
            this.UppdtBtncncl = new System.Windows.Forms.Button();
            this.ItemCount = new System.Windows.Forms.Label();
            this.ItemSearchPanel = new System.Windows.Forms.Panel();
            this.ItemSearch = new System.Windows.Forms.Button();
            this.TxtItemSearch = new System.Windows.Forms.TextBox();
            this.SearchLbl2 = new System.Windows.Forms.Label();
            this.ItemCloseBtn = new System.Windows.Forms.Button();
            this.ItemUpdateBtn = new System.Windows.Forms.Button();
            this.NewItemBtn = new System.Windows.Forms.Button();
            this.Divider5 = new System.Windows.Forms.Panel();
            this.ItemTbl = new System.Windows.Forms.DataGridView();
            this.ItemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemUnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Divider6 = new System.Windows.Forms.Panel();
            this.ItemLbl = new System.Windows.Forms.Label();
            this.ItemProduction = new System.Windows.Forms.Panel();
            this.UPDTPRDCTN = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.productiobCBX = new System.Windows.Forms.ComboBox();
            this.Reason = new System.Windows.Forms.TextBox();
            this.operationCB = new System.Windows.Forms.ComboBox();
            this.lbl_RsnUpdt = new System.Windows.Forms.Label();
            this.txtbx_QnttyUpdte = new System.Windows.Forms.TextBox();
            this.UpdateClose = new System.Windows.Forms.Button();
            this.BTTN_PrdctnUpdt = new System.Windows.Forms.Button();
            this.lbl_QnttyUpdt = new System.Windows.Forms.Label();
            this.lbl_PrdctUpdte = new System.Windows.Forms.Label();
            this.UpdtPrdctCBX = new System.Windows.Forms.ComboBox();
            this.lbl_UpdtPrdctn = new System.Windows.Forms.Label();
            this.pnl_NwPrdctn = new System.Windows.Forms.Panel();
            this.LVProductList = new System.Windows.Forms.ListView();
            this.Quantity = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Product = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.bttn_Clear = new System.Windows.Forms.Button();
            this.lbl_OrderList = new System.Windows.Forms.Label();
            this.bttn_Add = new System.Windows.Forms.Button();
            this.txtbx_Qntty = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cmbbx_Product = new System.Windows.Forms.ComboBox();
            this.lbl_Product = new System.Windows.Forms.Label();
            this.bttn_Save = new System.Windows.Forms.Button();
            this.bttn_Cancel = new System.Windows.Forms.Button();
            this.lbl_Nwprdctn = new System.Windows.Forms.Label();
            this.IProductionSearchPanel = new System.Windows.Forms.Panel();
            this.IProductionSearch = new System.Windows.Forms.Button();
            this.TxtProductionSearch = new System.Windows.Forms.TextBox();
            this.SearchLbl14 = new System.Windows.Forms.Label();
            this.ProductionCount = new System.Windows.Forms.Label();
            this.IProductionCloseBtn = new System.Windows.Forms.Button();
            this.IProductionUpdateBtn = new System.Windows.Forms.Button();
            this.Divider22 = new System.Windows.Forms.Panel();
            this.IProductionNewBtn = new System.Windows.Forms.Button();
            this.ItemProductionTbl = new System.Windows.Forms.DataGridView();
            this.IProductDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IProductionNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IItemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IProduct = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Divider21 = new System.Windows.Forms.Panel();
            this.ItemProductionLbl = new System.Windows.Forms.Label();
            this.Invoice = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.productname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label13 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.lblSubTotal = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblOrder = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.InvoiceTbl = new System.Windows.Forms.DataGridView();
            this.invoicedate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invoiceno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customername = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalamount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.print = new System.Windows.Forms.DataGridViewImageColumn();
            this.InvoiceSearchPanel = new System.Windows.Forms.Panel();
            this.InvoiceSearch = new System.Windows.Forms.Button();
            this.TxtInvoiceSearch = new System.Windows.Forms.TextBox();
            this.SearchLbl3 = new System.Windows.Forms.Label();
            this.InvoiceCount = new System.Windows.Forms.Label();
            this.CloseInvoiceBtn = new System.Windows.Forms.Button();
            this.Divider8 = new System.Windows.Forms.Panel();
            this.Divider7 = new System.Windows.Forms.Panel();
            this.Invoicelbl = new System.Windows.Forms.Label();
            this.SalesReturn = new System.Windows.Forms.Panel();
            this.SReturnUpdateRequestPnl = new System.Windows.Forms.Panel();
            this.SReturnProductNameTxt = new System.Windows.Forms.TextBox();
            this.SReturnUpdateRequestBtn = new System.Windows.Forms.Button();
            this.SReturnUpdateStatusCmb = new System.Windows.Forms.ComboBox();
            this.SReturnUpdateInvoiceCmb = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.SReturnUpdateStatusCancelBtn = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.SReturnNewRequestPnl = new System.Windows.Forms.Panel();
            this.SReturnQuantitytxt = new System.Windows.Forms.TextBox();
            this.SReturnReasonCmb = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.Quantitytxt = new System.Windows.Forms.Label();
            this.SReturnProductNameCmb = new System.Windows.Forms.ComboBox();
            this.SReturnProductName = new System.Windows.Forms.Label();
            this.SReturnSubmitNewRequestBtn = new System.Windows.Forms.Button();
            this.SReturnInvoiceNoCmb = new System.Windows.Forms.ComboBox();
            this.label44 = new System.Windows.Forms.Label();
            this.SReturnNewRequestCancelBtn = new System.Windows.Forms.Button();
            this.label45 = new System.Windows.Forms.Label();
            this.ReturnCount = new System.Windows.Forms.Label();
            this.SReturnDataGridView = new System.Windows.Forms.DataGridView();
            this.SReturnSearchPanel = new System.Windows.Forms.Panel();
            this.SReturnSearch = new System.Windows.Forms.Button();
            this.TxtReturnSearch = new System.Windows.Forms.TextBox();
            this.SearchLbl11 = new System.Windows.Forms.Label();
            this.SReturnExitBtn = new System.Windows.Forms.Button();
            this.SReturnUpdateBtn = new System.Windows.Forms.Button();
            this.Divider17 = new System.Windows.Forms.Panel();
            this.SReturnNewBtn = new System.Windows.Forms.Button();
            this.Divider18 = new System.Windows.Forms.Panel();
            this.SalesReturnLbl = new System.Windows.Forms.Label();
            this.LowStock = new System.Windows.Forms.Panel();
            this.StockCount = new System.Windows.Forms.Label();
            this.LStockSearchPanel = new System.Windows.Forms.Panel();
            this.LStockSearch = new System.Windows.Forms.Button();
            this.TxtLStockSearch = new System.Windows.Forms.TextBox();
            this.SearchLbl7 = new System.Windows.Forms.Label();
            this.LStockCloseBtn = new System.Windows.Forms.Button();
            this.Divider13 = new System.Windows.Forms.Panel();
            this.LowStocksTbl = new System.Windows.Forms.DataGridView();
            this.LStockItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LStockQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LStockOrderP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Divider14 = new System.Windows.Forms.Panel();
            this.LowStockLbl = new System.Windows.Forms.Label();
            this.CompletedSales = new System.Windows.Forms.Panel();
            this.CSalesSearchPanel = new System.Windows.Forms.Panel();
            this.CSalesSearch = new System.Windows.Forms.Button();
            this.TxtCSalesSearch = new System.Windows.Forms.TextBox();
            this.Searchlbl4 = new System.Windows.Forms.Label();
            this.CompleteCount = new System.Windows.Forms.Label();
            this.CSalesCloseBtn = new System.Windows.Forms.Button();
            this.Divider9 = new System.Windows.Forms.Panel();
            this.CompletedSalesTbl = new System.Windows.Forms.DataGridView();
            this.Divider10 = new System.Windows.Forms.Panel();
            this.CompletedSalesLbl = new System.Windows.Forms.Label();
            this.PaymentRecieved = new System.Windows.Forms.Panel();
            this.PaymentCount = new System.Windows.Forms.Label();
            this.PRecievedSearchPanel = new System.Windows.Forms.Panel();
            this.PRecievedSearch = new System.Windows.Forms.Button();
            this.TxtPRecievedSearch = new System.Windows.Forms.TextBox();
            this.SearchLbl6 = new System.Windows.Forms.Label();
            this.PReceivedCloseBtn = new System.Windows.Forms.Button();
            this.Divider11 = new System.Windows.Forms.Panel();
            this.PaymentsTbl = new System.Windows.Forms.DataGridView();
            this.PRecievedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRecievedInvoiceNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRCusName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRTotalPayment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Divider12 = new System.Windows.Forms.Panel();
            this.PaymentsRecievedLbl = new System.Windows.Forms.Label();
            this.InventorySummary = new System.Windows.Forms.Panel();
            this.SummaryCount = new System.Windows.Forms.Label();
            this.ISummaryCloseBtn = new System.Windows.Forms.Button();
            this.Divider15 = new System.Windows.Forms.Panel();
            this.InventorySummaryTbl = new System.Windows.Forms.DataGridView();
            this.ISummaryItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ISummaryQuantityIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ISummaryQuantityOut = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Divider16 = new System.Windows.Forms.Panel();
            this.InventorySummaryLbl = new System.Windows.Forms.Label();
            this.AuditLog = new System.Windows.Forms.Panel();
            this.AuditCount = new System.Windows.Forms.Label();
            this.AuditSearchPanel = new System.Windows.Forms.Panel();
            this.AuditSearch = new System.Windows.Forms.Button();
            this.TxtAuditSearch = new System.Windows.Forms.TextBox();
            this.SearchLbl8 = new System.Windows.Forms.Label();
            this.AuditCloseBtn = new System.Windows.Forms.Button();
            this.Divider19 = new System.Windows.Forms.Panel();
            this.AuditLogTbl = new System.Windows.Forms.DataGridView();
            this.Divder20 = new System.Windows.Forms.Panel();
            this.AuditLogLbl = new System.Windows.Forms.Label();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.Dashboard.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SalesChart)).BeginInit();
            this.StockPanel.SuspendLayout();
            this.StockPic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.ItemPanel.SuspendLayout();
            this.ItemPic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.CustomerPanel.SuspendLayout();
            this.CustomerPic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.MReport.SuspendLayout();
            this.MSales.SuspendLayout();
            this.MainMenu.SuspendLayout();
            this.MInventory.SuspendLayout();
            this.Title.SuspendLayout();
            this.Contacts.SuspendLayout();
            this.ContactsSearchPanel.SuspendLayout();
            this.NewCus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerTbl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EmployeeTbl)).BeginInit();
            this.SalesOrder.SuspendLayout();
            this.SOrderUpdate.SuspendLayout();
            this.NewSOrder.SuspendLayout();
            this.SOrderSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OSalesTbl)).BeginInit();
            this.Item.SuspendLayout();
            this.pnl_AddItem.SuspendLayout();
            this.pnl_UpdtPrc.SuspendLayout();
            this.ItemSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemTbl)).BeginInit();
            this.ItemProduction.SuspendLayout();
            this.UPDTPRDCTN.SuspendLayout();
            this.pnl_NwPrdctn.SuspendLayout();
            this.IProductionSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemProductionTbl)).BeginInit();
            this.Invoice.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.InvoiceTbl)).BeginInit();
            this.InvoiceSearchPanel.SuspendLayout();
            this.SalesReturn.SuspendLayout();
            this.SReturnUpdateRequestPnl.SuspendLayout();
            this.SReturnNewRequestPnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SReturnDataGridView)).BeginInit();
            this.SReturnSearchPanel.SuspendLayout();
            this.LowStock.SuspendLayout();
            this.LStockSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LowStocksTbl)).BeginInit();
            this.CompletedSales.SuspendLayout();
            this.CSalesSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CompletedSalesTbl)).BeginInit();
            this.PaymentRecieved.SuspendLayout();
            this.PRecievedSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PaymentsTbl)).BeginInit();
            this.InventorySummary.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InventorySummaryTbl)).BeginInit();
            this.AuditLog.SuspendLayout();
            this.AuditSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AuditLogTbl)).BeginInit();
            this.SuspendLayout();
            // 
            // exitSys1Btn
            // 
            this.exitSys1Btn.FlatAppearance.BorderSize = 0;
            this.exitSys1Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitSys1Btn.Image = ((System.Drawing.Image)(resources.GetObject("exitSys1Btn.Image")));
            this.exitSys1Btn.Location = new System.Drawing.Point(1340, -5);
            this.exitSys1Btn.Name = "exitSys1Btn";
            this.exitSys1Btn.Size = new System.Drawing.Size(29, 30);
            this.exitSys1Btn.TabIndex = 1;
            this.exitSys1Btn.UseVisualStyleBackColor = true;
            this.exitSys1Btn.Click += new System.EventHandler(this.button5_Click);
            // 
            // SalesTransition
            // 
            this.SalesTransition.Interval = 5;
            this.SalesTransition.Tick += new System.EventHandler(this.SalesTransition_Tick);
            // 
            // ReportTransition
            // 
            this.ReportTransition.Interval = 5;
            this.ReportTransition.Tick += new System.EventHandler(this.ReportTransition_Tick);
            // 
            // Dashboard
            // 
            this.Dashboard.Controls.Add(this.Divider1);
            this.Dashboard.Controls.Add(this.SalesChart);
            this.Dashboard.Controls.Add(this.SalesOrderSummaryLbl);
            this.Dashboard.Controls.Add(this.OrderPlacedCount);
            this.Dashboard.Controls.Add(this.InTransitCount);
            this.Dashboard.Controls.Add(this.DashboardLbl);
            this.Dashboard.Controls.Add(this.TotalSalesLbl);
            this.Dashboard.Controls.Add(this.TotalSalesCount);
            this.Dashboard.Controls.Add(this.CompletedLbl);
            this.Dashboard.Controls.Add(this.InTransitLbl);
            this.Dashboard.Controls.Add(this.OrderPlacedLbl);
            this.Dashboard.Controls.Add(this.CompletedCount);
            this.Dashboard.Controls.Add(this.SalesActivityLbl);
            this.Dashboard.Controls.Add(this.StockPanel);
            this.Dashboard.Controls.Add(this.ItemPanel);
            this.Dashboard.Controls.Add(this.CustomerPanel);
            this.Dashboard.Location = new System.Drawing.Point(343, 12);
            this.Dashboard.Name = "Dashboard";
            this.Dashboard.Size = new System.Drawing.Size(998, 735);
            this.Dashboard.TabIndex = 4;
            // 
            // Divider1
            // 
            this.Divider1.BackColor = System.Drawing.Color.Black;
            this.Divider1.Location = new System.Drawing.Point(27, 76);
            this.Divider1.Name = "Divider1";
            this.Divider1.Size = new System.Drawing.Size(943, 2);
            this.Divider1.TabIndex = 56;
            // 
            // SalesChart
            // 
            chartArea1.Name = "ChartArea1";
            this.SalesChart.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.SalesChart.Legends.Add(legend1);
            this.SalesChart.Location = new System.Drawing.Point(49, 466);
            this.SalesChart.Name = "SalesChart";
            this.SalesChart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "Payments Received";
            this.SalesChart.Series.Add(series1);
            this.SalesChart.Size = new System.Drawing.Size(909, 222);
            this.SalesChart.TabIndex = 60;
            this.SalesChart.Text = "chart1";
            // 
            // SalesOrderSummaryLbl
            // 
            this.SalesOrderSummaryLbl.AutoSize = true;
            this.SalesOrderSummaryLbl.Font = new System.Drawing.Font("Futura Hv BT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalesOrderSummaryLbl.Location = new System.Drawing.Point(25, 396);
            this.SalesOrderSummaryLbl.Name = "SalesOrderSummaryLbl";
            this.SalesOrderSummaryLbl.Size = new System.Drawing.Size(267, 32);
            this.SalesOrderSummaryLbl.TabIndex = 59;
            this.SalesOrderSummaryLbl.Text = "Payments Summary";
            // 
            // OrderPlacedCount
            // 
            this.OrderPlacedCount.AutoSize = true;
            this.OrderPlacedCount.Font = new System.Drawing.Font("Futura Bk BT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderPlacedCount.Location = new System.Drawing.Point(120, 284);
            this.OrderPlacedCount.Name = "OrderPlacedCount";
            this.OrderPlacedCount.Size = new System.Drawing.Size(30, 32);
            this.OrderPlacedCount.TabIndex = 58;
            this.OrderPlacedCount.Text = "0";
            this.OrderPlacedCount.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // InTransitCount
            // 
            this.InTransitCount.AutoSize = true;
            this.InTransitCount.Font = new System.Drawing.Font("Futura Bk BT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InTransitCount.Location = new System.Drawing.Point(350, 284);
            this.InTransitCount.Name = "InTransitCount";
            this.InTransitCount.Size = new System.Drawing.Size(30, 32);
            this.InTransitCount.TabIndex = 57;
            this.InTransitCount.Text = "0";
            this.InTransitCount.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // DashboardLbl
            // 
            this.DashboardLbl.AutoSize = true;
            this.DashboardLbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DashboardLbl.ForeColor = System.Drawing.Color.Black;
            this.DashboardLbl.Location = new System.Drawing.Point(372, 23);
            this.DashboardLbl.Name = "DashboardLbl";
            this.DashboardLbl.Size = new System.Drawing.Size(220, 39);
            this.DashboardLbl.TabIndex = 55;
            this.DashboardLbl.Text = "DASHBOARD";
            // 
            // TotalSalesLbl
            // 
            this.TotalSalesLbl.AutoSize = true;
            this.TotalSalesLbl.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalSalesLbl.ForeColor = System.Drawing.Color.Black;
            this.TotalSalesLbl.Location = new System.Drawing.Point(791, 342);
            this.TotalSalesLbl.Name = "TotalSalesLbl";
            this.TotalSalesLbl.Size = new System.Drawing.Size(123, 25);
            this.TotalSalesLbl.TabIndex = 47;
            this.TotalSalesLbl.Text = "Total Sales  ";
            // 
            // TotalSalesCount
            // 
            this.TotalSalesCount.AutoSize = true;
            this.TotalSalesCount.Font = new System.Drawing.Font("Futura Bk BT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalSalesCount.Location = new System.Drawing.Point(829, 284);
            this.TotalSalesCount.Name = "TotalSalesCount";
            this.TotalSalesCount.Size = new System.Drawing.Size(30, 32);
            this.TotalSalesCount.TabIndex = 46;
            this.TotalSalesCount.Text = "0";
            this.TotalSalesCount.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // CompletedLbl
            // 
            this.CompletedLbl.AutoSize = true;
            this.CompletedLbl.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompletedLbl.ForeColor = System.Drawing.Color.Black;
            this.CompletedLbl.Location = new System.Drawing.Point(551, 337);
            this.CompletedLbl.Name = "CompletedLbl";
            this.CompletedLbl.Size = new System.Drawing.Size(113, 25);
            this.CompletedLbl.TabIndex = 40;
            this.CompletedLbl.Text = "Completed";
            // 
            // InTransitLbl
            // 
            this.InTransitLbl.AutoSize = true;
            this.InTransitLbl.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InTransitLbl.ForeColor = System.Drawing.Color.Black;
            this.InTransitLbl.Location = new System.Drawing.Point(321, 342);
            this.InTransitLbl.Name = "InTransitLbl";
            this.InTransitLbl.Size = new System.Drawing.Size(96, 25);
            this.InTransitLbl.TabIndex = 41;
            this.InTransitLbl.Text = "In Transit";
            // 
            // OrderPlacedLbl
            // 
            this.OrderPlacedLbl.AutoSize = true;
            this.OrderPlacedLbl.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderPlacedLbl.ForeColor = System.Drawing.Color.Black;
            this.OrderPlacedLbl.Location = new System.Drawing.Point(70, 342);
            this.OrderPlacedLbl.Name = "OrderPlacedLbl";
            this.OrderPlacedLbl.Size = new System.Drawing.Size(133, 25);
            this.OrderPlacedLbl.TabIndex = 44;
            this.OrderPlacedLbl.Text = "Order Placed";
            // 
            // CompletedCount
            // 
            this.CompletedCount.AutoSize = true;
            this.CompletedCount.Font = new System.Drawing.Font("Futura Bk BT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompletedCount.Location = new System.Drawing.Point(587, 283);
            this.CompletedCount.Name = "CompletedCount";
            this.CompletedCount.Size = new System.Drawing.Size(30, 32);
            this.CompletedCount.TabIndex = 43;
            this.CompletedCount.Text = "0";
            this.CompletedCount.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // SalesActivityLbl
            // 
            this.SalesActivityLbl.AutoSize = true;
            this.SalesActivityLbl.Font = new System.Drawing.Font("Futura Hv BT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalesActivityLbl.Location = new System.Drawing.Point(26, 214);
            this.SalesActivityLbl.Name = "SalesActivityLbl";
            this.SalesActivityLbl.Size = new System.Drawing.Size(179, 32);
            this.SalesActivityLbl.TabIndex = 39;
            this.SalesActivityLbl.Text = "Sales Activity";
            // 
            // StockPanel
            // 
            this.StockPanel.Controls.Add(this.TotalStock);
            this.StockPanel.Controls.Add(this.StockPic);
            this.StockPanel.Controls.Add(this.TotalStockLbl);
            this.StockPanel.Location = new System.Drawing.Point(676, 93);
            this.StockPanel.Name = "StockPanel";
            this.StockPanel.Size = new System.Drawing.Size(294, 94);
            this.StockPanel.TabIndex = 37;
            // 
            // TotalStock
            // 
            this.TotalStock.AutoSize = true;
            this.TotalStock.Font = new System.Drawing.Font("Futura Bk BT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalStock.Location = new System.Drawing.Point(160, 15);
            this.TotalStock.Name = "TotalStock";
            this.TotalStock.Size = new System.Drawing.Size(30, 32);
            this.TotalStock.TabIndex = 32;
            this.TotalStock.Text = "0";
            this.TotalStock.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // StockPic
            // 
            this.StockPic.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.StockPic.Controls.Add(this.pictureBox3);
            this.StockPic.Location = new System.Drawing.Point(0, 1);
            this.StockPic.Name = "StockPic";
            this.StockPic.Size = new System.Drawing.Size(84, 97);
            this.StockPic.TabIndex = 31;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(23, 27);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(42, 50);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // TotalStockLbl
            // 
            this.TotalStockLbl.AutoSize = true;
            this.TotalStockLbl.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalStockLbl.ForeColor = System.Drawing.Color.Black;
            this.TotalStockLbl.Location = new System.Drawing.Point(126, 52);
            this.TotalStockLbl.Name = "TotalStockLbl";
            this.TotalStockLbl.Size = new System.Drawing.Size(110, 25);
            this.TotalStockLbl.TabIndex = 2;
            this.TotalStockLbl.Text = "Total Stock";
            // 
            // ItemPanel
            // 
            this.ItemPanel.Controls.Add(this.TotalItems);
            this.ItemPanel.Controls.Add(this.ItemPic);
            this.ItemPanel.Controls.Add(this.TotalItemLbl);
            this.ItemPanel.Location = new System.Drawing.Point(357, 93);
            this.ItemPanel.Name = "ItemPanel";
            this.ItemPanel.Size = new System.Drawing.Size(294, 94);
            this.ItemPanel.TabIndex = 36;
            // 
            // TotalItems
            // 
            this.TotalItems.AutoSize = true;
            this.TotalItems.Font = new System.Drawing.Font("Futura Bk BT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalItems.Location = new System.Drawing.Point(167, 15);
            this.TotalItems.Name = "TotalItems";
            this.TotalItems.Size = new System.Drawing.Size(30, 32);
            this.TotalItems.TabIndex = 32;
            this.TotalItems.Text = "0";
            this.TotalItems.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // ItemPic
            // 
            this.ItemPic.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.ItemPic.Controls.Add(this.pictureBox2);
            this.ItemPic.Location = new System.Drawing.Point(0, 1);
            this.ItemPic.Name = "ItemPic";
            this.ItemPic.Size = new System.Drawing.Size(84, 97);
            this.ItemPic.TabIndex = 31;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(21, 27);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(42, 50);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // TotalItemLbl
            // 
            this.TotalItemLbl.AutoSize = true;
            this.TotalItemLbl.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalItemLbl.ForeColor = System.Drawing.Color.Black;
            this.TotalItemLbl.Location = new System.Drawing.Point(125, 55);
            this.TotalItemLbl.Name = "TotalItemLbl";
            this.TotalItemLbl.Size = new System.Drawing.Size(111, 25);
            this.TotalItemLbl.TabIndex = 2;
            this.TotalItemLbl.Text = "Total Items";
            // 
            // CustomerPanel
            // 
            this.CustomerPanel.Controls.Add(this.TotalCus);
            this.CustomerPanel.Controls.Add(this.CustomerPic);
            this.CustomerPanel.Controls.Add(this.TotalCustomer);
            this.CustomerPanel.Location = new System.Drawing.Point(26, 93);
            this.CustomerPanel.Name = "CustomerPanel";
            this.CustomerPanel.Size = new System.Drawing.Size(294, 94);
            this.CustomerPanel.TabIndex = 35;
            // 
            // TotalCus
            // 
            this.TotalCus.AutoSize = true;
            this.TotalCus.Font = new System.Drawing.Font("Futura Bk BT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalCus.Location = new System.Drawing.Point(167, 12);
            this.TotalCus.Name = "TotalCus";
            this.TotalCus.Size = new System.Drawing.Size(30, 32);
            this.TotalCus.TabIndex = 12;
            this.TotalCus.Text = "0";
            this.TotalCus.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // CustomerPic
            // 
            this.CustomerPic.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.CustomerPic.Controls.Add(this.pictureBox1);
            this.CustomerPic.Location = new System.Drawing.Point(0, 1);
            this.CustomerPic.Name = "CustomerPic";
            this.CustomerPic.Size = new System.Drawing.Size(84, 97);
            this.CustomerPic.TabIndex = 31;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(23, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(42, 50);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // TotalCustomer
            // 
            this.TotalCustomer.AutoSize = true;
            this.TotalCustomer.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalCustomer.ForeColor = System.Drawing.Color.Black;
            this.TotalCustomer.Location = new System.Drawing.Point(106, 55);
            this.TotalCustomer.Name = "TotalCustomer";
            this.TotalCustomer.Size = new System.Drawing.Size(160, 25);
            this.TotalCustomer.TabIndex = 2;
            this.TotalCustomer.Text = "Total Customers";
            // 
            // logOutBtn
            // 
            this.logOutBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.logOutBtn.FlatAppearance.BorderSize = 0;
            this.logOutBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logOutBtn.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logOutBtn.ForeColor = System.Drawing.Color.White;
            this.logOutBtn.Image = ((System.Drawing.Image)(resources.GetObject("logOutBtn.Image")));
            this.logOutBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.logOutBtn.Location = new System.Drawing.Point(3, 313);
            this.logOutBtn.Name = "logOutBtn";
            this.logOutBtn.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.logOutBtn.Size = new System.Drawing.Size(317, 55);
            this.logOutBtn.TabIndex = 28;
            this.logOutBtn.Text = "          LOG OUT";
            this.logOutBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.logOutBtn.UseVisualStyleBackColor = true;
            this.logOutBtn.Click += new System.EventHandler(this.logOutBtn_Click);
            // 
            // MReport
            // 
            this.MReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.MReport.Controls.Add(this.ReportBtn);
            this.MReport.Controls.Add(this.RAuditLog);
            this.MReport.Controls.Add(this.RLowStock);
            this.MReport.Controls.Add(this.RCompletedSales);
            this.MReport.Controls.Add(this.RPaymentsReceived);
            this.MReport.Controls.Add(this.RInventorySummary);
            this.MReport.Location = new System.Drawing.Point(3, 252);
            this.MReport.Name = "MReport";
            this.MReport.Size = new System.Drawing.Size(325, 55);
            this.MReport.TabIndex = 38;
            // 
            // ReportBtn
            // 
            this.ReportBtn.FlatAppearance.BorderSize = 0;
            this.ReportBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReportBtn.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReportBtn.ForeColor = System.Drawing.Color.White;
            this.ReportBtn.Image = ((System.Drawing.Image)(resources.GetObject("ReportBtn.Image")));
            this.ReportBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ReportBtn.Location = new System.Drawing.Point(3, 3);
            this.ReportBtn.Name = "ReportBtn";
            this.ReportBtn.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.ReportBtn.Size = new System.Drawing.Size(314, 55);
            this.ReportBtn.TabIndex = 29;
            this.ReportBtn.Text = "         REPORTS";
            this.ReportBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ReportBtn.UseVisualStyleBackColor = true;
            this.ReportBtn.Click += new System.EventHandler(this.InventoryBtn_Click);
            // 
            // RAuditLog
            // 
            this.RAuditLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.RAuditLog.FlatAppearance.BorderSize = 0;
            this.RAuditLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RAuditLog.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RAuditLog.ForeColor = System.Drawing.Color.White;
            this.RAuditLog.Image = ((System.Drawing.Image)(resources.GetObject("RAuditLog.Image")));
            this.RAuditLog.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RAuditLog.Location = new System.Drawing.Point(0, 61);
            this.RAuditLog.Margin = new System.Windows.Forms.Padding(0);
            this.RAuditLog.Name = "RAuditLog";
            this.RAuditLog.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.RAuditLog.Size = new System.Drawing.Size(317, 50);
            this.RAuditLog.TabIndex = 33;
            this.RAuditLog.Text = "         AUDIT LOG";
            this.RAuditLog.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RAuditLog.UseVisualStyleBackColor = false;
            this.RAuditLog.Click += new System.EventHandler(this.RAuditLog_Click);
            // 
            // RLowStock
            // 
            this.RLowStock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.RLowStock.FlatAppearance.BorderSize = 0;
            this.RLowStock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RLowStock.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RLowStock.ForeColor = System.Drawing.Color.White;
            this.RLowStock.Image = ((System.Drawing.Image)(resources.GetObject("RLowStock.Image")));
            this.RLowStock.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RLowStock.Location = new System.Drawing.Point(0, 111);
            this.RLowStock.Margin = new System.Windows.Forms.Padding(0);
            this.RLowStock.Name = "RLowStock";
            this.RLowStock.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.RLowStock.Size = new System.Drawing.Size(317, 50);
            this.RLowStock.TabIndex = 36;
            this.RLowStock.Text = "         LOW STOCK ITEMS";
            this.RLowStock.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RLowStock.UseVisualStyleBackColor = false;
            this.RLowStock.Click += new System.EventHandler(this.RLowStock_Click);
            // 
            // RCompletedSales
            // 
            this.RCompletedSales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.RCompletedSales.FlatAppearance.BorderSize = 0;
            this.RCompletedSales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RCompletedSales.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RCompletedSales.ForeColor = System.Drawing.Color.White;
            this.RCompletedSales.Image = ((System.Drawing.Image)(resources.GetObject("RCompletedSales.Image")));
            this.RCompletedSales.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RCompletedSales.Location = new System.Drawing.Point(0, 161);
            this.RCompletedSales.Margin = new System.Windows.Forms.Padding(0);
            this.RCompletedSales.Name = "RCompletedSales";
            this.RCompletedSales.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.RCompletedSales.Size = new System.Drawing.Size(317, 50);
            this.RCompletedSales.TabIndex = 37;
            this.RCompletedSales.Text = "         COMPLETED SALES";
            this.RCompletedSales.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RCompletedSales.UseVisualStyleBackColor = false;
            this.RCompletedSales.Click += new System.EventHandler(this.RCompletedSales_Click);
            // 
            // RPaymentsReceived
            // 
            this.RPaymentsReceived.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.RPaymentsReceived.FlatAppearance.BorderSize = 0;
            this.RPaymentsReceived.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RPaymentsReceived.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RPaymentsReceived.ForeColor = System.Drawing.Color.White;
            this.RPaymentsReceived.Image = ((System.Drawing.Image)(resources.GetObject("RPaymentsReceived.Image")));
            this.RPaymentsReceived.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RPaymentsReceived.Location = new System.Drawing.Point(0, 211);
            this.RPaymentsReceived.Margin = new System.Windows.Forms.Padding(0);
            this.RPaymentsReceived.Name = "RPaymentsReceived";
            this.RPaymentsReceived.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.RPaymentsReceived.Size = new System.Drawing.Size(317, 50);
            this.RPaymentsReceived.TabIndex = 38;
            this.RPaymentsReceived.Text = "         PAYMENTS RECEIVED";
            this.RPaymentsReceived.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RPaymentsReceived.UseVisualStyleBackColor = false;
            this.RPaymentsReceived.Click += new System.EventHandler(this.RPaymentsRecieved_Click);
            // 
            // RInventorySummary
            // 
            this.RInventorySummary.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.RInventorySummary.FlatAppearance.BorderSize = 0;
            this.RInventorySummary.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RInventorySummary.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RInventorySummary.ForeColor = System.Drawing.Color.White;
            this.RInventorySummary.Image = ((System.Drawing.Image)(resources.GetObject("RInventorySummary.Image")));
            this.RInventorySummary.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RInventorySummary.Location = new System.Drawing.Point(0, 261);
            this.RInventorySummary.Margin = new System.Windows.Forms.Padding(0);
            this.RInventorySummary.Name = "RInventorySummary";
            this.RInventorySummary.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.RInventorySummary.Size = new System.Drawing.Size(317, 50);
            this.RInventorySummary.TabIndex = 39;
            this.RInventorySummary.Text = "         INVENTORY SUMMARY";
            this.RInventorySummary.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RInventorySummary.UseVisualStyleBackColor = false;
            this.RInventorySummary.Click += new System.EventHandler(this.RInventorySummary_Click);
            // 
            // MSales
            // 
            this.MSales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.MSales.Controls.Add(this.SalesBtn);
            this.MSales.Controls.Add(this.SOrder);
            this.MSales.Controls.Add(this.SInvoice);
            this.MSales.Controls.Add(this.SReturn);
            this.MSales.Location = new System.Drawing.Point(3, 191);
            this.MSales.Name = "MSales";
            this.MSales.Size = new System.Drawing.Size(325, 55);
            this.MSales.TabIndex = 36;
            // 
            // SalesBtn
            // 
            this.SalesBtn.FlatAppearance.BorderSize = 0;
            this.SalesBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SalesBtn.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalesBtn.ForeColor = System.Drawing.Color.White;
            this.SalesBtn.Image = ((System.Drawing.Image)(resources.GetObject("SalesBtn.Image")));
            this.SalesBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SalesBtn.Location = new System.Drawing.Point(3, 3);
            this.SalesBtn.Name = "SalesBtn";
            this.SalesBtn.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.SalesBtn.Size = new System.Drawing.Size(314, 50);
            this.SalesBtn.TabIndex = 27;
            this.SalesBtn.Text = "         SALES";
            this.SalesBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SalesBtn.UseVisualStyleBackColor = true;
            this.SalesBtn.Click += new System.EventHandler(this.SalesBtn_Click);
            // 
            // SOrder
            // 
            this.SOrder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrder.FlatAppearance.BorderSize = 0;
            this.SOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrder.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrder.ForeColor = System.Drawing.Color.White;
            this.SOrder.Image = ((System.Drawing.Image)(resources.GetObject("SOrder.Image")));
            this.SOrder.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrder.Location = new System.Drawing.Point(0, 56);
            this.SOrder.Margin = new System.Windows.Forms.Padding(0);
            this.SOrder.Name = "SOrder";
            this.SOrder.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.SOrder.Size = new System.Drawing.Size(317, 50);
            this.SOrder.TabIndex = 33;
            this.SOrder.Text = "         SALES ORDER";
            this.SOrder.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrder.UseVisualStyleBackColor = false;
            this.SOrder.Click += new System.EventHandler(this.SOrder_Click);
            // 
            // SInvoice
            // 
            this.SInvoice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SInvoice.FlatAppearance.BorderSize = 0;
            this.SInvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SInvoice.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SInvoice.ForeColor = System.Drawing.Color.White;
            this.SInvoice.Image = ((System.Drawing.Image)(resources.GetObject("SInvoice.Image")));
            this.SInvoice.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SInvoice.Location = new System.Drawing.Point(0, 106);
            this.SInvoice.Margin = new System.Windows.Forms.Padding(0);
            this.SInvoice.Name = "SInvoice";
            this.SInvoice.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.SInvoice.Size = new System.Drawing.Size(317, 50);
            this.SInvoice.TabIndex = 36;
            this.SInvoice.Text = "         INVOICE";
            this.SInvoice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SInvoice.UseVisualStyleBackColor = false;
            this.SInvoice.Click += new System.EventHandler(this.SInvoice_Click);
            // 
            // SReturn
            // 
            this.SReturn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SReturn.FlatAppearance.BorderSize = 0;
            this.SReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SReturn.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturn.ForeColor = System.Drawing.Color.White;
            this.SReturn.Image = ((System.Drawing.Image)(resources.GetObject("SReturn.Image")));
            this.SReturn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SReturn.Location = new System.Drawing.Point(0, 156);
            this.SReturn.Margin = new System.Windows.Forms.Padding(0);
            this.SReturn.Name = "SReturn";
            this.SReturn.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.SReturn.Size = new System.Drawing.Size(317, 50);
            this.SReturn.TabIndex = 34;
            this.SReturn.Text = "         SALES RETURN";
            this.SReturn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SReturn.UseVisualStyleBackColor = false;
            this.SReturn.Click += new System.EventHandler(this.SReturn_Click);
            // 
            // DashboardBtn
            // 
            this.DashboardBtn.FlatAppearance.BorderSize = 0;
            this.DashboardBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DashboardBtn.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DashboardBtn.ForeColor = System.Drawing.Color.White;
            this.DashboardBtn.Image = ((System.Drawing.Image)(resources.GetObject("DashboardBtn.Image")));
            this.DashboardBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DashboardBtn.Location = new System.Drawing.Point(3, 18);
            this.DashboardBtn.Name = "DashboardBtn";
            this.DashboardBtn.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.DashboardBtn.Size = new System.Drawing.Size(317, 50);
            this.DashboardBtn.TabIndex = 28;
            this.DashboardBtn.Text = "          HOME";
            this.DashboardBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DashboardBtn.UseVisualStyleBackColor = true;
            this.DashboardBtn.Click += new System.EventHandler(this.DashboardBtn_Click);
            // 
            // MainMenu
            // 
            this.MainMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.MainMenu.Controls.Add(this.DashboardBtn);
            this.MainMenu.Controls.Add(this.ContactsBtn);
            this.MainMenu.Controls.Add(this.MInventory);
            this.MainMenu.Controls.Add(this.MSales);
            this.MainMenu.Controls.Add(this.MReport);
            this.MainMenu.Controls.Add(this.logOutBtn);
            this.MainMenu.Location = new System.Drawing.Point(0, 54);
            this.MainMenu.Margin = new System.Windows.Forms.Padding(0);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Padding = new System.Windows.Forms.Padding(0, 15, 0, 0);
            this.MainMenu.Size = new System.Drawing.Size(320, 726);
            this.MainMenu.TabIndex = 2;
            // 
            // ContactsBtn
            // 
            this.ContactsBtn.FlatAppearance.BorderSize = 0;
            this.ContactsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ContactsBtn.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContactsBtn.ForeColor = System.Drawing.Color.White;
            this.ContactsBtn.Image = ((System.Drawing.Image)(resources.GetObject("ContactsBtn.Image")));
            this.ContactsBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ContactsBtn.Location = new System.Drawing.Point(3, 74);
            this.ContactsBtn.Name = "ContactsBtn";
            this.ContactsBtn.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.ContactsBtn.Size = new System.Drawing.Size(317, 50);
            this.ContactsBtn.TabIndex = 39;
            this.ContactsBtn.Text = "         CONTACTS";
            this.ContactsBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ContactsBtn.UseVisualStyleBackColor = true;
            this.ContactsBtn.Click += new System.EventHandler(this.ContactsBtn_Click);
            // 
            // MInventory
            // 
            this.MInventory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.MInventory.Controls.Add(this.InventoryBtn);
            this.MInventory.Controls.Add(this.ItemBtn);
            this.MInventory.Controls.Add(this.ItemProductionBtn);
            this.MInventory.Location = new System.Drawing.Point(3, 130);
            this.MInventory.Name = "MInventory";
            this.MInventory.Size = new System.Drawing.Size(325, 55);
            this.MInventory.TabIndex = 36;
            // 
            // InventoryBtn
            // 
            this.InventoryBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.InventoryBtn.FlatAppearance.BorderSize = 0;
            this.InventoryBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InventoryBtn.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InventoryBtn.ForeColor = System.Drawing.Color.White;
            this.InventoryBtn.Image = ((System.Drawing.Image)(resources.GetObject("InventoryBtn.Image")));
            this.InventoryBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.InventoryBtn.Location = new System.Drawing.Point(3, 3);
            this.InventoryBtn.Name = "InventoryBtn";
            this.InventoryBtn.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.InventoryBtn.Size = new System.Drawing.Size(314, 50);
            this.InventoryBtn.TabIndex = 36;
            this.InventoryBtn.Text = "          INVENTORY";
            this.InventoryBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.InventoryBtn.UseVisualStyleBackColor = true;
            this.InventoryBtn.Click += new System.EventHandler(this.InventoryBtn_Click_1);
            // 
            // ItemBtn
            // 
            this.ItemBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.ItemBtn.FlatAppearance.BorderSize = 0;
            this.ItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ItemBtn.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemBtn.ForeColor = System.Drawing.Color.White;
            this.ItemBtn.Image = ((System.Drawing.Image)(resources.GetObject("ItemBtn.Image")));
            this.ItemBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ItemBtn.Location = new System.Drawing.Point(0, 56);
            this.ItemBtn.Margin = new System.Windows.Forms.Padding(0);
            this.ItemBtn.Name = "ItemBtn";
            this.ItemBtn.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.ItemBtn.Size = new System.Drawing.Size(317, 50);
            this.ItemBtn.TabIndex = 33;
            this.ItemBtn.Text = "          ITEM";
            this.ItemBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ItemBtn.UseVisualStyleBackColor = false;
            this.ItemBtn.Click += new System.EventHandler(this.ItemBtn_Click);
            // 
            // ItemProductionBtn
            // 
            this.ItemProductionBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.ItemProductionBtn.FlatAppearance.BorderSize = 0;
            this.ItemProductionBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ItemProductionBtn.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemProductionBtn.ForeColor = System.Drawing.Color.White;
            this.ItemProductionBtn.Image = ((System.Drawing.Image)(resources.GetObject("ItemProductionBtn.Image")));
            this.ItemProductionBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ItemProductionBtn.Location = new System.Drawing.Point(0, 106);
            this.ItemProductionBtn.Margin = new System.Windows.Forms.Padding(0);
            this.ItemProductionBtn.Name = "ItemProductionBtn";
            this.ItemProductionBtn.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.ItemProductionBtn.Size = new System.Drawing.Size(317, 50);
            this.ItemProductionBtn.TabIndex = 35;
            this.ItemProductionBtn.Text = "          ITEM PRODUCTION";
            this.ItemProductionBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ItemProductionBtn.UseVisualStyleBackColor = false;
            this.ItemProductionBtn.Click += new System.EventHandler(this.ItemProductionBtn_Click);
            // 
            // Logo
            // 
            this.Logo.AutoSize = true;
            this.Logo.Font = new System.Drawing.Font("Futura Hv BT", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Logo.ForeColor = System.Drawing.Color.White;
            this.Logo.Image = ((System.Drawing.Image)(resources.GetObject("Logo.Image")));
            this.Logo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Logo.Location = new System.Drawing.Point(18, 14);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(279, 45);
            this.Logo.TabIndex = 25;
            this.Logo.Text = "     LUMINAIRE";
            // 
            // Title
            // 
            this.Title.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(16)))), ((int)(((byte)(18)))));
            this.Title.Controls.Add(this.Logo);
            this.Title.Location = new System.Drawing.Point(-6, -5);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(326, 69);
            this.Title.TabIndex = 3;
            // 
            // InventoryTransition
            // 
            this.InventoryTransition.Interval = 5;
            this.InventoryTransition.Tick += new System.EventHandler(this.InventoryTransition_Tick);
            // 
            // Contacts
            // 
            this.Contacts.Controls.Add(this.ContactsSearchPanel);
            this.Contacts.Controls.Add(this.NewCus);
            this.Contacts.Controls.Add(this.CustomerTbl);
            this.Contacts.Controls.Add(this.EmployeeTbl);
            this.Contacts.Controls.Add(this.CustomerCount);
            this.Contacts.Controls.Add(this.EmployeeCount);
            this.Contacts.Controls.Add(this.cusNew);
            this.Contacts.Controls.Add(this.Divider4);
            this.Contacts.Controls.Add(this.CusLbl);
            this.Contacts.Controls.Add(this.ContactsCloseBtn);
            this.Contacts.Controls.Add(this.Divider3);
            this.Contacts.Controls.Add(this.Divider2);
            this.Contacts.Controls.Add(this.EmpLbl);
            this.Contacts.Location = new System.Drawing.Point(343, 12);
            this.Contacts.Name = "Contacts";
            this.Contacts.Size = new System.Drawing.Size(998, 735);
            this.Contacts.TabIndex = 8;
            this.Contacts.Visible = false;
            // 
            // ContactsSearchPanel
            // 
            this.ContactsSearchPanel.Controls.Add(this.ContactsSearch);
            this.ContactsSearchPanel.Controls.Add(this.TxtSearch);
            this.ContactsSearchPanel.Controls.Add(this.SearchLbl1);
            this.ContactsSearchPanel.Location = new System.Drawing.Point(441, 94);
            this.ContactsSearchPanel.Name = "ContactsSearchPanel";
            this.ContactsSearchPanel.Size = new System.Drawing.Size(517, 42);
            this.ContactsSearchPanel.TabIndex = 80;
            // 
            // ContactsSearch
            // 
            this.ContactsSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.ContactsSearch.FlatAppearance.BorderSize = 0;
            this.ContactsSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ContactsSearch.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContactsSearch.ForeColor = System.Drawing.Color.White;
            this.ContactsSearch.Image = ((System.Drawing.Image)(resources.GetObject("ContactsSearch.Image")));
            this.ContactsSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ContactsSearch.Location = new System.Drawing.Point(390, 0);
            this.ContactsSearch.Name = "ContactsSearch";
            this.ContactsSearch.Size = new System.Drawing.Size(128, 42);
            this.ContactsSearch.TabIndex = 76;
            this.ContactsSearch.Text = "      Search";
            this.ContactsSearch.UseVisualStyleBackColor = false;
            this.ContactsSearch.Click += new System.EventHandler(this.ContactsSearch_Click);
            // 
            // TxtSearch
            // 
            this.TxtSearch.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtSearch.Location = new System.Drawing.Point(71, 9);
            this.TxtSearch.Name = "TxtSearch";
            this.TxtSearch.Size = new System.Drawing.Size(310, 25);
            this.TxtSearch.TabIndex = 75;
            // 
            // SearchLbl1
            // 
            this.SearchLbl1.AutoSize = true;
            this.SearchLbl1.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchLbl1.Location = new System.Drawing.Point(7, 12);
            this.SearchLbl1.Name = "SearchLbl1";
            this.SearchLbl1.Size = new System.Drawing.Size(58, 18);
            this.SearchLbl1.TabIndex = 74;
            this.SearchLbl1.Text = "Search:";
            // 
            // NewCus
            // 
            this.NewCus.Controls.Add(this.NewCustomerContact);
            this.NewCus.Controls.Add(this.txtPNum);
            this.NewCus.Controls.Add(this.PhoneNumber);
            this.NewCus.Controls.Add(this.txtLName);
            this.NewCus.Controls.Add(this.txtFName);
            this.NewCus.Controls.Add(this.LastName);
            this.NewCus.Controls.Add(this.FirstName);
            this.NewCus.Controls.Add(this.CusCancel);
            this.NewCus.Controls.Add(this.CusSaveBtn);
            this.NewCus.Location = new System.Drawing.Point(287, 145);
            this.NewCus.Name = "NewCus";
            this.NewCus.Size = new System.Drawing.Size(428, 471);
            this.NewCus.TabIndex = 82;
            this.NewCus.Visible = false;
            // 
            // NewCustomerContact
            // 
            this.NewCustomerContact.AutoSize = true;
            this.NewCustomerContact.Font = new System.Drawing.Font("Futura Bk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewCustomerContact.Location = new System.Drawing.Point(73, 52);
            this.NewCustomerContact.Name = "NewCustomerContact";
            this.NewCustomerContact.Size = new System.Drawing.Size(207, 22);
            this.NewCustomerContact.TabIndex = 75;
            this.NewCustomerContact.Text = "New Customer Contact";
            // 
            // txtPNum
            // 
            this.txtPNum.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPNum.Location = new System.Drawing.Point(76, 303);
            this.txtPNum.Name = "txtPNum";
            this.txtPNum.Size = new System.Drawing.Size(262, 25);
            this.txtPNum.TabIndex = 74;
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.AutoSize = true;
            this.PhoneNumber.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNumber.Location = new System.Drawing.Point(73, 273);
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.Size = new System.Drawing.Size(108, 18);
            this.PhoneNumber.TabIndex = 73;
            this.PhoneNumber.Text = "Phone Number";
            // 
            // txtLName
            // 
            this.txtLName.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLName.Location = new System.Drawing.Point(76, 224);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(262, 25);
            this.txtLName.TabIndex = 72;
            // 
            // txtFName
            // 
            this.txtFName.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFName.Location = new System.Drawing.Point(77, 145);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(262, 25);
            this.txtFName.TabIndex = 71;
            // 
            // LastName
            // 
            this.LastName.AutoSize = true;
            this.LastName.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastName.Location = new System.Drawing.Point(73, 194);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(80, 18);
            this.LastName.TabIndex = 70;
            this.LastName.Text = "Last Name";
            // 
            // FirstName
            // 
            this.FirstName.AutoSize = true;
            this.FirstName.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstName.Location = new System.Drawing.Point(74, 114);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(81, 18);
            this.FirstName.TabIndex = 69;
            this.FirstName.Text = "First Name";
            // 
            // CusCancel
            // 
            this.CusCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.CusCancel.FlatAppearance.BorderSize = 0;
            this.CusCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CusCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CusCancel.ForeColor = System.Drawing.Color.White;
            this.CusCancel.Image = ((System.Drawing.Image)(resources.GetObject("CusCancel.Image")));
            this.CusCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CusCancel.Location = new System.Drawing.Point(248, 374);
            this.CusCancel.Name = "CusCancel";
            this.CusCancel.Size = new System.Drawing.Size(128, 42);
            this.CusCancel.TabIndex = 68;
            this.CusCancel.Text = "     Cancel";
            this.CusCancel.UseVisualStyleBackColor = false;
            this.CusCancel.Click += new System.EventHandler(this.CusCancel_Click);
            // 
            // CusSaveBtn
            // 
            this.CusSaveBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.CusSaveBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.CusSaveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CusSaveBtn.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CusSaveBtn.ForeColor = System.Drawing.Color.White;
            this.CusSaveBtn.Image = ((System.Drawing.Image)(resources.GetObject("CusSaveBtn.Image")));
            this.CusSaveBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CusSaveBtn.Location = new System.Drawing.Point(113, 374);
            this.CusSaveBtn.Name = "CusSaveBtn";
            this.CusSaveBtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.CusSaveBtn.Size = new System.Drawing.Size(128, 42);
            this.CusSaveBtn.TabIndex = 68;
            this.CusSaveBtn.Text = "    Save";
            this.CusSaveBtn.UseVisualStyleBackColor = false;
            this.CusSaveBtn.Click += new System.EventHandler(this.CusSaveBtn_Click);
            // 
            // CustomerTbl
            // 
            this.CustomerTbl.AllowUserToAddRows = false;
            this.CustomerTbl.AllowUserToDeleteRows = false;
            this.CustomerTbl.AllowUserToResizeColumns = false;
            this.CustomerTbl.AllowUserToResizeRows = false;
            this.CustomerTbl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.CustomerTbl.BackgroundColor = System.Drawing.Color.White;
            this.CustomerTbl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CustomerTbl.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.CustomerTbl.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.CustomerTbl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.CustomerTbl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CustomerTbl.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FullName,
            this.PNumber2});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.CustomerTbl.DefaultCellStyle = dataGridViewCellStyle2;
            this.CustomerTbl.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.CustomerTbl.EnableHeadersVisualStyles = false;
            this.CustomerTbl.GridColor = System.Drawing.Color.White;
            this.CustomerTbl.Location = new System.Drawing.Point(585, 145);
            this.CustomerTbl.Margin = new System.Windows.Forms.Padding(0);
            this.CustomerTbl.Name = "CustomerTbl";
            this.CustomerTbl.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.CustomerTbl.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.CustomerTbl.RowHeadersVisible = false;
            this.CustomerTbl.RowHeadersWidth = 80;
            this.CustomerTbl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.CustomerTbl.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.CustomerTbl.RowTemplate.Height = 30;
            this.CustomerTbl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.CustomerTbl.Size = new System.Drawing.Size(373, 425);
            this.CustomerTbl.TabIndex = 63;
            // 
            // FullName
            // 
            this.FullName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.FullName.FillWeight = 150F;
            this.FullName.HeaderText = "Full Name";
            this.FullName.Name = "FullName";
            // 
            // PNumber2
            // 
            this.PNumber2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PNumber2.HeaderText = "Phone Number";
            this.PNumber2.Name = "PNumber2";
            this.PNumber2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // EmployeeTbl
            // 
            this.EmployeeTbl.AllowUserToAddRows = false;
            this.EmployeeTbl.AllowUserToDeleteRows = false;
            this.EmployeeTbl.AllowUserToResizeColumns = false;
            this.EmployeeTbl.AllowUserToResizeRows = false;
            this.EmployeeTbl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.EmployeeTbl.BackgroundColor = System.Drawing.Color.White;
            this.EmployeeTbl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EmployeeTbl.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.EmployeeTbl.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.EmployeeTbl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.EmployeeTbl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.EmployeeTbl.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EmployeeId,
            this.DDate,
            this.PNumber});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.EmployeeTbl.DefaultCellStyle = dataGridViewCellStyle6;
            this.EmployeeTbl.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.EmployeeTbl.EnableHeadersVisualStyles = false;
            this.EmployeeTbl.GridColor = System.Drawing.Color.White;
            this.EmployeeTbl.Location = new System.Drawing.Point(27, 145);
            this.EmployeeTbl.Margin = new System.Windows.Forms.Padding(0);
            this.EmployeeTbl.Name = "EmployeeTbl";
            this.EmployeeTbl.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.EmployeeTbl.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.EmployeeTbl.RowHeadersVisible = false;
            this.EmployeeTbl.RowHeadersWidth = 80;
            this.EmployeeTbl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.EmployeeTbl.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.EmployeeTbl.RowTemplate.Height = 30;
            this.EmployeeTbl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.EmployeeTbl.Size = new System.Drawing.Size(428, 425);
            this.EmployeeTbl.TabIndex = 57;
            // 
            // EmployeeId
            // 
            this.EmployeeId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.EmployeeId.HeaderText = "Employee ID";
            this.EmployeeId.Name = "EmployeeId";
            this.EmployeeId.Width = 102;
            // 
            // DDate
            // 
            this.DDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DDate.HeaderText = "Full Name";
            this.DDate.Name = "DDate";
            // 
            // PNumber
            // 
            this.PNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PNumber.HeaderText = "Phone Number";
            this.PNumber.Name = "PNumber";
            this.PNumber.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // CustomerCount
            // 
            this.CustomerCount.AutoSize = true;
            this.CustomerCount.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerCount.Location = new System.Drawing.Point(557, 610);
            this.CustomerCount.Name = "CustomerCount";
            this.CustomerCount.Size = new System.Drawing.Size(128, 18);
            this.CustomerCount.TabIndex = 77;
            this.CustomerCount.Text = "Total records: ???";
            // 
            // EmployeeCount
            // 
            this.EmployeeCount.AutoSize = true;
            this.EmployeeCount.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeCount.Location = new System.Drawing.Point(21, 610);
            this.EmployeeCount.Name = "EmployeeCount";
            this.EmployeeCount.Size = new System.Drawing.Size(128, 18);
            this.EmployeeCount.TabIndex = 78;
            this.EmployeeCount.Text = "Total records: ???";
            // 
            // cusNew
            // 
            this.cusNew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.cusNew.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.cusNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cusNew.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cusNew.ForeColor = System.Drawing.Color.White;
            this.cusNew.Image = ((System.Drawing.Image)(resources.GetObject("cusNew.Image")));
            this.cusNew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cusNew.Location = new System.Drawing.Point(842, 586);
            this.cusNew.Name = "cusNew";
            this.cusNew.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.cusNew.Size = new System.Drawing.Size(128, 42);
            this.cusNew.TabIndex = 66;
            this.cusNew.Text = "    New";
            this.cusNew.UseVisualStyleBackColor = false;
            this.cusNew.Click += new System.EventHandler(this.cusNew_Click);
            // 
            // Divider4
            // 
            this.Divider4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.Divider4.Location = new System.Drawing.Point(505, 145);
            this.Divider4.Name = "Divider4";
            this.Divider4.Size = new System.Drawing.Size(2, 483);
            this.Divider4.TabIndex = 65;
            // 
            // CusLbl
            // 
            this.CusLbl.AutoSize = true;
            this.CusLbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CusLbl.ForeColor = System.Drawing.Color.Black;
            this.CusLbl.Location = new System.Drawing.Point(681, 23);
            this.CusLbl.Name = "CusLbl";
            this.CusLbl.Size = new System.Drawing.Size(193, 39);
            this.CusLbl.TabIndex = 64;
            this.CusLbl.Text = "CUSTOMER";
            // 
            // ContactsCloseBtn
            // 
            this.ContactsCloseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.ContactsCloseBtn.FlatAppearance.BorderSize = 0;
            this.ContactsCloseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ContactsCloseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContactsCloseBtn.ForeColor = System.Drawing.Color.White;
            this.ContactsCloseBtn.Image = ((System.Drawing.Image)(resources.GetObject("ContactsCloseBtn.Image")));
            this.ContactsCloseBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ContactsCloseBtn.Location = new System.Drawing.Point(842, 670);
            this.ContactsCloseBtn.Name = "ContactsCloseBtn";
            this.ContactsCloseBtn.Size = new System.Drawing.Size(128, 42);
            this.ContactsCloseBtn.TabIndex = 62;
            this.ContactsCloseBtn.Text = "     Close";
            this.ContactsCloseBtn.UseVisualStyleBackColor = false;
            this.ContactsCloseBtn.Click += new System.EventHandler(this.ContactsCloseBtn_Click);
            // 
            // Divider3
            // 
            this.Divider3.BackColor = System.Drawing.Color.Black;
            this.Divider3.Location = new System.Drawing.Point(24, 650);
            this.Divider3.Name = "Divider3";
            this.Divider3.Size = new System.Drawing.Size(943, 2);
            this.Divider3.TabIndex = 59;
            // 
            // Divider2
            // 
            this.Divider2.BackColor = System.Drawing.Color.Black;
            this.Divider2.Location = new System.Drawing.Point(27, 76);
            this.Divider2.Name = "Divider2";
            this.Divider2.Size = new System.Drawing.Size(943, 2);
            this.Divider2.TabIndex = 56;
            // 
            // EmpLbl
            // 
            this.EmpLbl.AutoSize = true;
            this.EmpLbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpLbl.ForeColor = System.Drawing.Color.Black;
            this.EmpLbl.Location = new System.Drawing.Point(157, 23);
            this.EmpLbl.Name = "EmpLbl";
            this.EmpLbl.Size = new System.Drawing.Size(180, 39);
            this.EmpLbl.TabIndex = 55;
            this.EmpLbl.Text = "EMPLOYEE";
            // 
            // SalesOrder
            // 
            this.SalesOrder.Controls.Add(this.SOrderUpdate);
            this.SalesOrder.Controls.Add(this.NewSOrder);
            this.SalesOrder.Controls.Add(this.SOrderSearchPanel);
            this.SalesOrder.Controls.Add(this.OrderCount);
            this.SalesOrder.Controls.Add(this.SOrderExitBtn1);
            this.SalesOrder.Controls.Add(this.OSalesTbl);
            this.SalesOrder.Controls.Add(this.SOrderUpdateBtn1);
            this.SalesOrder.Controls.Add(this.SOrderDivider);
            this.SalesOrder.Controls.Add(this.SOrderNewBtn1);
            this.SalesOrder.Controls.Add(this.Divider);
            this.SalesOrder.Controls.Add(this.SalesOrderLbl);
            this.SalesOrder.Location = new System.Drawing.Point(343, 12);
            this.SalesOrder.Name = "SalesOrder";
            this.SalesOrder.Size = new System.Drawing.Size(998, 735);
            this.SalesOrder.TabIndex = 68;
            this.SalesOrder.Visible = false;
            // 
            // SOrderUpdate
            // 
            this.SOrderUpdate.Controls.Add(this.SOrderUpExitBtn);
            this.SOrderUpdate.Controls.Add(this.SOrderUpStatusBtn);
            this.SOrderUpdate.Controls.Add(this.SOrderLbl1);
            this.SOrderUpdate.Controls.Add(this.SOrderStatusCbx1);
            this.SOrderUpdate.Controls.Add(this.SInvoiceLbl2);
            this.SOrderUpdate.Controls.Add(this.InvoiceCbx1);
            this.SOrderUpdate.Controls.Add(this.UpdateSalesStatusLbl);
            this.SOrderUpdate.Location = new System.Drawing.Point(274, 161);
            this.SOrderUpdate.Name = "SOrderUpdate";
            this.SOrderUpdate.Size = new System.Drawing.Size(444, 394);
            this.SOrderUpdate.TabIndex = 63;
            this.SOrderUpdate.Visible = false;
            // 
            // SOrderUpExitBtn
            // 
            this.SOrderUpExitBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrderUpExitBtn.FlatAppearance.BorderSize = 0;
            this.SOrderUpExitBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrderUpExitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderUpExitBtn.ForeColor = System.Drawing.Color.White;
            this.SOrderUpExitBtn.Image = ((System.Drawing.Image)(resources.GetObject("SOrderUpExitBtn.Image")));
            this.SOrderUpExitBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrderUpExitBtn.Location = new System.Drawing.Point(283, 316);
            this.SOrderUpExitBtn.Name = "SOrderUpExitBtn";
            this.SOrderUpExitBtn.Size = new System.Drawing.Size(128, 42);
            this.SOrderUpExitBtn.TabIndex = 64;
            this.SOrderUpExitBtn.Text = "     Cancel";
            this.SOrderUpExitBtn.UseVisualStyleBackColor = false;
            this.SOrderUpExitBtn.Click += new System.EventHandler(this.SOrderUpExitBtn_Click);
            // 
            // SOrderUpStatusBtn
            // 
            this.SOrderUpStatusBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrderUpStatusBtn.FlatAppearance.BorderSize = 0;
            this.SOrderUpStatusBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrderUpStatusBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderUpStatusBtn.ForeColor = System.Drawing.Color.White;
            this.SOrderUpStatusBtn.Image = ((System.Drawing.Image)(resources.GetObject("SOrderUpStatusBtn.Image")));
            this.SOrderUpStatusBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrderUpStatusBtn.Location = new System.Drawing.Point(149, 316);
            this.SOrderUpStatusBtn.Name = "SOrderUpStatusBtn";
            this.SOrderUpStatusBtn.Size = new System.Drawing.Size(128, 42);
            this.SOrderUpStatusBtn.TabIndex = 81;
            this.SOrderUpStatusBtn.Text = "     Update";
            this.SOrderUpStatusBtn.UseVisualStyleBackColor = false;
            this.SOrderUpStatusBtn.Click += new System.EventHandler(this.SOrderUpStatusBtn_Click);
            // 
            // SOrderLbl1
            // 
            this.SOrderLbl1.AutoSize = true;
            this.SOrderLbl1.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderLbl1.Location = new System.Drawing.Point(99, 190);
            this.SOrderLbl1.Name = "SOrderLbl1";
            this.SOrderLbl1.Size = new System.Drawing.Size(47, 18);
            this.SOrderLbl1.TabIndex = 80;
            this.SOrderLbl1.Text = "Status";
            // 
            // SOrderStatusCbx1
            // 
            this.SOrderStatusCbx1.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderStatusCbx1.FormattingEnabled = true;
            this.SOrderStatusCbx1.Location = new System.Drawing.Point(99, 228);
            this.SOrderStatusCbx1.Name = "SOrderStatusCbx1";
            this.SOrderStatusCbx1.Size = new System.Drawing.Size(244, 27);
            this.SOrderStatusCbx1.TabIndex = 79;
            // 
            // SInvoiceLbl2
            // 
            this.SInvoiceLbl2.AutoSize = true;
            this.SInvoiceLbl2.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SInvoiceLbl2.Location = new System.Drawing.Point(99, 90);
            this.SInvoiceLbl2.Name = "SInvoiceLbl2";
            this.SInvoiceLbl2.Size = new System.Drawing.Size(84, 18);
            this.SInvoiceLbl2.TabIndex = 78;
            this.SInvoiceLbl2.Text = "Invoice No.";
            // 
            // InvoiceCbx1
            // 
            this.InvoiceCbx1.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvoiceCbx1.FormattingEnabled = true;
            this.InvoiceCbx1.Location = new System.Drawing.Point(99, 128);
            this.InvoiceCbx1.Name = "InvoiceCbx1";
            this.InvoiceCbx1.Size = new System.Drawing.Size(244, 27);
            this.InvoiceCbx1.TabIndex = 77;
            this.InvoiceCbx1.SelectedIndexChanged += new System.EventHandler(this.InvoiceCbx1_SelectedIndexChanged);
            // 
            // UpdateSalesStatusLbl
            // 
            this.UpdateSalesStatusLbl.AutoSize = true;
            this.UpdateSalesStatusLbl.Font = new System.Drawing.Font("Futura Bk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateSalesStatusLbl.Location = new System.Drawing.Point(39, 29);
            this.UpdateSalesStatusLbl.Name = "UpdateSalesStatusLbl";
            this.UpdateSalesStatusLbl.Size = new System.Drawing.Size(177, 22);
            this.UpdateSalesStatusLbl.TabIndex = 76;
            this.UpdateSalesStatusLbl.Text = "Update Sales Status";
            // 
            // NewSOrder
            // 
            this.NewSOrder.Controls.Add(this.DueDate);
            this.NewSOrder.Controls.Add(this.DueDateLbl);
            this.NewSOrder.Controls.Add(this.OrderList);
            this.NewSOrder.Controls.Add(this.SOrderClear);
            this.NewSOrder.Controls.Add(this.label5);
            this.NewSOrder.Controls.Add(this.NewSOrderAdd);
            this.NewSOrder.Controls.Add(this.TxtQuantity);
            this.NewSOrder.Controls.Add(this.SQuantityLabel);
            this.NewSOrder.Controls.Add(this.SProductCBX);
            this.NewSOrder.Controls.Add(this.SProductLabel);
            this.NewSOrder.Controls.Add(this.SCustomerCBX);
            this.NewSOrder.Controls.Add(this.SCustomerLabel);
            this.NewSOrder.Controls.Add(this.NewSOrderSave);
            this.NewSOrder.Controls.Add(this.NewSOrderClose);
            this.NewSOrder.Controls.Add(this.NewOrderLabel);
            this.NewSOrder.Location = new System.Drawing.Point(220, 145);
            this.NewSOrder.Name = "NewSOrder";
            this.NewSOrder.Size = new System.Drawing.Size(614, 416);
            this.NewSOrder.TabIndex = 87;
            this.NewSOrder.Visible = false;
            // 
            // DueDate
            // 
            this.DueDate.CustomFormat = "yyyy-MM-dd";
            this.DueDate.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DueDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DueDate.Location = new System.Drawing.Point(39, 279);
            this.DueDate.Name = "DueDate";
            this.DueDate.Size = new System.Drawing.Size(258, 27);
            this.DueDate.TabIndex = 93;
            // 
            // DueDateLbl
            // 
            this.DueDateLbl.AutoSize = true;
            this.DueDateLbl.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DueDateLbl.Location = new System.Drawing.Point(39, 248);
            this.DueDateLbl.Name = "DueDateLbl";
            this.DueDateLbl.Size = new System.Drawing.Size(71, 18);
            this.DueDateLbl.TabIndex = 92;
            this.DueDateLbl.Text = "Due Date";
            // 
            // OrderList
            // 
            this.OrderList.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderList.HideSelection = false;
            this.OrderList.Location = new System.Drawing.Point(327, 112);
            this.OrderList.Name = "OrderList";
            this.OrderList.Size = new System.Drawing.Size(250, 192);
            this.OrderList.TabIndex = 91;
            this.OrderList.UseCompatibleStateImageBehavior = false;
            // 
            // SOrderClear
            // 
            this.SOrderClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrderClear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.SOrderClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrderClear.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderClear.ForeColor = System.Drawing.Color.White;
            this.SOrderClear.Image = ((System.Drawing.Image)(resources.GetObject("SOrderClear.Image")));
            this.SOrderClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrderClear.Location = new System.Drawing.Point(38, 334);
            this.SOrderClear.Name = "SOrderClear";
            this.SOrderClear.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SOrderClear.Size = new System.Drawing.Size(128, 42);
            this.SOrderClear.TabIndex = 90;
            this.SOrderClear.Text = "    Clear";
            this.SOrderClear.UseVisualStyleBackColor = false;
            this.SOrderClear.Click += new System.EventHandler(this.SOrderClear_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(324, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 18);
            this.label5.TabIndex = 89;
            this.label5.Text = "Order List";
            // 
            // NewSOrderAdd
            // 
            this.NewSOrderAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.NewSOrderAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.NewSOrderAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewSOrderAdd.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewSOrderAdd.ForeColor = System.Drawing.Color.White;
            this.NewSOrderAdd.Image = ((System.Drawing.Image)(resources.GetObject("NewSOrderAdd.Image")));
            this.NewSOrderAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NewSOrderAdd.Location = new System.Drawing.Point(175, 334);
            this.NewSOrderAdd.Name = "NewSOrderAdd";
            this.NewSOrderAdd.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.NewSOrderAdd.Size = new System.Drawing.Size(128, 42);
            this.NewSOrderAdd.TabIndex = 87;
            this.NewSOrderAdd.Text = "    Add";
            this.NewSOrderAdd.UseVisualStyleBackColor = false;
            this.NewSOrderAdd.Click += new System.EventHandler(this.NewSOrderAdd_Click);
            // 
            // TxtQuantity
            // 
            this.TxtQuantity.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtQuantity.Location = new System.Drawing.Point(200, 197);
            this.TxtQuantity.Name = "TxtQuantity";
            this.TxtQuantity.Size = new System.Drawing.Size(97, 25);
            this.TxtQuantity.TabIndex = 86;
            // 
            // SQuantityLabel
            // 
            this.SQuantityLabel.AutoSize = true;
            this.SQuantityLabel.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SQuantityLabel.Location = new System.Drawing.Point(197, 158);
            this.SQuantityLabel.Name = "SQuantityLabel";
            this.SQuantityLabel.Size = new System.Drawing.Size(65, 18);
            this.SQuantityLabel.TabIndex = 85;
            this.SQuantityLabel.Text = "Quantity";
            // 
            // SProductCBX
            // 
            this.SProductCBX.DropDownWidth = 335;
            this.SProductCBX.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SProductCBX.FormattingEnabled = true;
            this.SProductCBX.Location = new System.Drawing.Point(40, 195);
            this.SProductCBX.Name = "SProductCBX";
            this.SProductCBX.Size = new System.Drawing.Size(140, 27);
            this.SProductCBX.TabIndex = 84;
            // 
            // SProductLabel
            // 
            this.SProductLabel.AutoSize = true;
            this.SProductLabel.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SProductLabel.Location = new System.Drawing.Point(40, 158);
            this.SProductLabel.Name = "SProductLabel";
            this.SProductLabel.Size = new System.Drawing.Size(58, 18);
            this.SProductLabel.TabIndex = 83;
            this.SProductLabel.Text = "Product";
            // 
            // SCustomerCBX
            // 
            this.SCustomerCBX.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SCustomerCBX.Location = new System.Drawing.Point(42, 112);
            this.SCustomerCBX.Name = "SCustomerCBX";
            this.SCustomerCBX.Size = new System.Drawing.Size(256, 27);
            this.SCustomerCBX.TabIndex = 82;
            // 
            // SCustomerLabel
            // 
            this.SCustomerLabel.AutoSize = true;
            this.SCustomerLabel.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SCustomerLabel.Location = new System.Drawing.Point(39, 76);
            this.SCustomerLabel.Name = "SCustomerLabel";
            this.SCustomerLabel.Size = new System.Drawing.Size(72, 18);
            this.SCustomerLabel.TabIndex = 81;
            this.SCustomerLabel.Text = "Customer";
            // 
            // NewSOrderSave
            // 
            this.NewSOrderSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.NewSOrderSave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.NewSOrderSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewSOrderSave.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewSOrderSave.ForeColor = System.Drawing.Color.White;
            this.NewSOrderSave.Image = ((System.Drawing.Image)(resources.GetObject("NewSOrderSave.Image")));
            this.NewSOrderSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NewSOrderSave.Location = new System.Drawing.Point(310, 334);
            this.NewSOrderSave.Name = "NewSOrderSave";
            this.NewSOrderSave.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.NewSOrderSave.Size = new System.Drawing.Size(128, 42);
            this.NewSOrderSave.TabIndex = 77;
            this.NewSOrderSave.Text = "    Save";
            this.NewSOrderSave.UseVisualStyleBackColor = false;
            this.NewSOrderSave.Click += new System.EventHandler(this.NewSOrderSave_Click);
            // 
            // NewSOrderClose
            // 
            this.NewSOrderClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.NewSOrderClose.FlatAppearance.BorderSize = 0;
            this.NewSOrderClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewSOrderClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewSOrderClose.ForeColor = System.Drawing.Color.White;
            this.NewSOrderClose.Image = ((System.Drawing.Image)(resources.GetObject("NewSOrderClose.Image")));
            this.NewSOrderClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NewSOrderClose.Location = new System.Drawing.Point(447, 334);
            this.NewSOrderClose.Name = "NewSOrderClose";
            this.NewSOrderClose.Size = new System.Drawing.Size(128, 42);
            this.NewSOrderClose.TabIndex = 64;
            this.NewSOrderClose.Text = "     Cancel";
            this.NewSOrderClose.UseVisualStyleBackColor = false;
            this.NewSOrderClose.Click += new System.EventHandler(this.NewOrderClose_Click);
            // 
            // NewOrderLabel
            // 
            this.NewOrderLabel.AutoSize = true;
            this.NewOrderLabel.Font = new System.Drawing.Font("Futura Bk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewOrderLabel.Location = new System.Drawing.Point(39, 29);
            this.NewOrderLabel.Name = "NewOrderLabel";
            this.NewOrderLabel.Size = new System.Drawing.Size(106, 22);
            this.NewOrderLabel.TabIndex = 76;
            this.NewOrderLabel.Text = "New Order";
            // 
            // SOrderSearchPanel
            // 
            this.SOrderSearchPanel.Controls.Add(this.SOrderSearch);
            this.SOrderSearchPanel.Controls.Add(this.TxtOrderSearch);
            this.SOrderSearchPanel.Controls.Add(this.SearchLbl12);
            this.SOrderSearchPanel.Location = new System.Drawing.Point(453, 93);
            this.SOrderSearchPanel.Name = "SOrderSearchPanel";
            this.SOrderSearchPanel.Size = new System.Drawing.Size(517, 42);
            this.SOrderSearchPanel.TabIndex = 86;
            // 
            // SOrderSearch
            // 
            this.SOrderSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrderSearch.FlatAppearance.BorderSize = 0;
            this.SOrderSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrderSearch.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderSearch.ForeColor = System.Drawing.Color.White;
            this.SOrderSearch.Image = ((System.Drawing.Image)(resources.GetObject("SOrderSearch.Image")));
            this.SOrderSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrderSearch.Location = new System.Drawing.Point(390, 0);
            this.SOrderSearch.Name = "SOrderSearch";
            this.SOrderSearch.Size = new System.Drawing.Size(128, 42);
            this.SOrderSearch.TabIndex = 76;
            this.SOrderSearch.Text = "      Search";
            this.SOrderSearch.UseVisualStyleBackColor = false;
            this.SOrderSearch.Click += new System.EventHandler(this.SOrderSearch_Click);
            // 
            // TxtOrderSearch
            // 
            this.TxtOrderSearch.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtOrderSearch.Location = new System.Drawing.Point(71, 9);
            this.TxtOrderSearch.Name = "TxtOrderSearch";
            this.TxtOrderSearch.Size = new System.Drawing.Size(310, 25);
            this.TxtOrderSearch.TabIndex = 75;
            // 
            // SearchLbl12
            // 
            this.SearchLbl12.AutoSize = true;
            this.SearchLbl12.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchLbl12.Location = new System.Drawing.Point(7, 12);
            this.SearchLbl12.Name = "SearchLbl12";
            this.SearchLbl12.Size = new System.Drawing.Size(58, 18);
            this.SearchLbl12.TabIndex = 74;
            this.SearchLbl12.Text = "Search:";
            // 
            // OrderCount
            // 
            this.OrderCount.AutoSize = true;
            this.OrderCount.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderCount.Location = new System.Drawing.Point(21, 610);
            this.OrderCount.Name = "OrderCount";
            this.OrderCount.Size = new System.Drawing.Size(128, 18);
            this.OrderCount.TabIndex = 85;
            this.OrderCount.Text = "Total records: ???";
            // 
            // SOrderExitBtn1
            // 
            this.SOrderExitBtn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrderExitBtn1.FlatAppearance.BorderSize = 0;
            this.SOrderExitBtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrderExitBtn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderExitBtn1.ForeColor = System.Drawing.Color.White;
            this.SOrderExitBtn1.Image = ((System.Drawing.Image)(resources.GetObject("SOrderExitBtn1.Image")));
            this.SOrderExitBtn1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrderExitBtn1.Location = new System.Drawing.Point(842, 670);
            this.SOrderExitBtn1.Name = "SOrderExitBtn1";
            this.SOrderExitBtn1.Size = new System.Drawing.Size(128, 42);
            this.SOrderExitBtn1.TabIndex = 62;
            this.SOrderExitBtn1.Text = "     Close";
            this.SOrderExitBtn1.UseVisualStyleBackColor = false;
            this.SOrderExitBtn1.Click += new System.EventHandler(this.SOrderExitBtn1_Click);
            // 
            // OSalesTbl
            // 
            this.OSalesTbl.AllowUserToAddRows = false;
            this.OSalesTbl.AllowUserToDeleteRows = false;
            this.OSalesTbl.AllowUserToResizeColumns = false;
            this.OSalesTbl.AllowUserToResizeRows = false;
            this.OSalesTbl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.OSalesTbl.BackgroundColor = System.Drawing.Color.White;
            this.OSalesTbl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.OSalesTbl.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.OSalesTbl.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.OSalesTbl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.OSalesTbl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.OSalesTbl.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SOrderDate1,
            this.SOrderID1,
            this.SOrderInvoice1,
            this.SOrderCustomer,
            this.SOrderStatus1,
            this.SOrderDueDate1,
            this.SOrderEmployeeID});
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.OSalesTbl.DefaultCellStyle = dataGridViewCellStyle10;
            this.OSalesTbl.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.OSalesTbl.EnableHeadersVisualStyles = false;
            this.OSalesTbl.GridColor = System.Drawing.Color.White;
            this.OSalesTbl.Location = new System.Drawing.Point(27, 145);
            this.OSalesTbl.Margin = new System.Windows.Forms.Padding(0);
            this.OSalesTbl.Name = "OSalesTbl";
            this.OSalesTbl.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.OSalesTbl.RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.OSalesTbl.RowHeadersVisible = false;
            this.OSalesTbl.RowHeadersWidth = 80;
            this.OSalesTbl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.OSalesTbl.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.OSalesTbl.RowTemplate.Height = 30;
            this.OSalesTbl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.OSalesTbl.Size = new System.Drawing.Size(943, 444);
            this.OSalesTbl.TabIndex = 57;
            // 
            // SOrderDate1
            // 
            this.SOrderDate1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SOrderDate1.FillWeight = 80F;
            this.SOrderDate1.HeaderText = "Date";
            this.SOrderDate1.Name = "SOrderDate1";
            // 
            // SOrderID1
            // 
            this.SOrderID1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SOrderID1.FillWeight = 50F;
            this.SOrderID1.HeaderText = "Order No.";
            this.SOrderID1.Name = "SOrderID1";
            this.SOrderID1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // SOrderInvoice1
            // 
            this.SOrderInvoice1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SOrderInvoice1.FillWeight = 50F;
            this.SOrderInvoice1.HeaderText = "Invoice No.";
            this.SOrderInvoice1.Name = "SOrderInvoice1";
            // 
            // SOrderCustomer
            // 
            this.SOrderCustomer.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SOrderCustomer.HeaderText = "Customer";
            this.SOrderCustomer.Name = "SOrderCustomer";
            // 
            // SOrderStatus1
            // 
            this.SOrderStatus1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SOrderStatus1.FillWeight = 80F;
            this.SOrderStatus1.HeaderText = "Status";
            this.SOrderStatus1.Name = "SOrderStatus1";
            this.SOrderStatus1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // SOrderDueDate1
            // 
            this.SOrderDueDate1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SOrderDueDate1.FillWeight = 80F;
            this.SOrderDueDate1.HeaderText = "Due Date";
            this.SOrderDueDate1.Name = "SOrderDueDate1";
            // 
            // SOrderEmployeeID
            // 
            this.SOrderEmployeeID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SOrderEmployeeID.FillWeight = 50F;
            this.SOrderEmployeeID.HeaderText = "Employee ID";
            this.SOrderEmployeeID.Name = "SOrderEmployeeID";
            // 
            // SOrderUpdateBtn1
            // 
            this.SOrderUpdateBtn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrderUpdateBtn1.FlatAppearance.BorderSize = 0;
            this.SOrderUpdateBtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrderUpdateBtn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderUpdateBtn1.ForeColor = System.Drawing.Color.White;
            this.SOrderUpdateBtn1.Image = ((System.Drawing.Image)(resources.GetObject("SOrderUpdateBtn1.Image")));
            this.SOrderUpdateBtn1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrderUpdateBtn1.Location = new System.Drawing.Point(688, 670);
            this.SOrderUpdateBtn1.Name = "SOrderUpdateBtn1";
            this.SOrderUpdateBtn1.Size = new System.Drawing.Size(128, 42);
            this.SOrderUpdateBtn1.TabIndex = 60;
            this.SOrderUpdateBtn1.Text = "     Update";
            this.SOrderUpdateBtn1.UseVisualStyleBackColor = false;
            this.SOrderUpdateBtn1.Click += new System.EventHandler(this.SOrderUpdateBtn1_Click);
            // 
            // SOrderDivider
            // 
            this.SOrderDivider.BackColor = System.Drawing.Color.Black;
            this.SOrderDivider.Location = new System.Drawing.Point(24, 650);
            this.SOrderDivider.Name = "SOrderDivider";
            this.SOrderDivider.Size = new System.Drawing.Size(943, 2);
            this.SOrderDivider.TabIndex = 59;
            // 
            // SOrderNewBtn1
            // 
            this.SOrderNewBtn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SOrderNewBtn1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.SOrderNewBtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SOrderNewBtn1.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SOrderNewBtn1.ForeColor = System.Drawing.Color.White;
            this.SOrderNewBtn1.Image = ((System.Drawing.Image)(resources.GetObject("SOrderNewBtn1.Image")));
            this.SOrderNewBtn1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SOrderNewBtn1.Location = new System.Drawing.Point(536, 670);
            this.SOrderNewBtn1.Name = "SOrderNewBtn1";
            this.SOrderNewBtn1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SOrderNewBtn1.Size = new System.Drawing.Size(128, 42);
            this.SOrderNewBtn1.TabIndex = 58;
            this.SOrderNewBtn1.Text = "    New";
            this.SOrderNewBtn1.UseVisualStyleBackColor = false;
            this.SOrderNewBtn1.Click += new System.EventHandler(this.SOrderNewBtn1_Click);
            // 
            // Divider
            // 
            this.Divider.BackColor = System.Drawing.Color.Black;
            this.Divider.Location = new System.Drawing.Point(27, 76);
            this.Divider.Name = "Divider";
            this.Divider.Size = new System.Drawing.Size(943, 2);
            this.Divider.TabIndex = 56;
            // 
            // SalesOrderLbl
            // 
            this.SalesOrderLbl.AutoSize = true;
            this.SalesOrderLbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalesOrderLbl.ForeColor = System.Drawing.Color.Black;
            this.SalesOrderLbl.Location = new System.Drawing.Point(372, 23);
            this.SalesOrderLbl.Name = "SalesOrderLbl";
            this.SalesOrderLbl.Size = new System.Drawing.Size(228, 39);
            this.SalesOrderLbl.TabIndex = 55;
            this.SalesOrderLbl.Text = "SALES ORDER";
            // 
            // Item
            // 
            this.Item.Controls.Add(this.pnl_AddItem);
            this.Item.Controls.Add(this.pnl_UpdtPrc);
            this.Item.Controls.Add(this.ItemCount);
            this.Item.Controls.Add(this.ItemSearchPanel);
            this.Item.Controls.Add(this.ItemCloseBtn);
            this.Item.Controls.Add(this.ItemUpdateBtn);
            this.Item.Controls.Add(this.NewItemBtn);
            this.Item.Controls.Add(this.Divider5);
            this.Item.Controls.Add(this.ItemTbl);
            this.Item.Controls.Add(this.Divider6);
            this.Item.Controls.Add(this.ItemLbl);
            this.Item.Location = new System.Drawing.Point(343, 12);
            this.Item.Name = "Item";
            this.Item.Size = new System.Drawing.Size(998, 735);
            this.Item.TabIndex = 69;
            this.Item.Visible = false;
            // 
            // pnl_AddItem
            // 
            this.pnl_AddItem.Controls.Add(this.txtbx_ROrdrLvl);
            this.pnl_AddItem.Controls.Add(this.lbl_ROrdrLvl);
            this.pnl_AddItem.Controls.Add(this.txtbx_Dscrptn);
            this.pnl_AddItem.Controls.Add(this.lbl_Dscptn);
            this.pnl_AddItem.Controls.Add(this.label1);
            this.pnl_AddItem.Controls.Add(this.txtbx_Prc);
            this.pnl_AddItem.Controls.Add(this.lbl_Prc);
            this.pnl_AddItem.Controls.Add(this.txtbx_Nme);
            this.pnl_AddItem.Controls.Add(this.lbl_ItmNme);
            this.pnl_AddItem.Controls.Add(this.AddItmCnclbttn);
            this.pnl_AddItem.Controls.Add(this.bttnAddItm);
            this.pnl_AddItem.Location = new System.Drawing.Point(285, 127);
            this.pnl_AddItem.Name = "pnl_AddItem";
            this.pnl_AddItem.Size = new System.Drawing.Size(431, 447);
            this.pnl_AddItem.TabIndex = 84;
            this.pnl_AddItem.Visible = false;
            // 
            // txtbx_ROrdrLvl
            // 
            this.txtbx_ROrdrLvl.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_ROrdrLvl.Location = new System.Drawing.Point(220, 208);
            this.txtbx_ROrdrLvl.Name = "txtbx_ROrdrLvl";
            this.txtbx_ROrdrLvl.Size = new System.Drawing.Size(146, 25);
            this.txtbx_ROrdrLvl.TabIndex = 79;
            // 
            // lbl_ROrdrLvl
            // 
            this.lbl_ROrdrLvl.AutoSize = true;
            this.lbl_ROrdrLvl.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ROrdrLvl.Location = new System.Drawing.Point(221, 174);
            this.lbl_ROrdrLvl.Name = "lbl_ROrdrLvl";
            this.lbl_ROrdrLvl.Size = new System.Drawing.Size(116, 18);
            this.lbl_ROrdrLvl.TabIndex = 78;
            this.lbl_ROrdrLvl.Text = "Production Point";
            // 
            // txtbx_Dscrptn
            // 
            this.txtbx_Dscrptn.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Dscrptn.Location = new System.Drawing.Point(61, 291);
            this.txtbx_Dscrptn.Name = "txtbx_Dscrptn";
            this.txtbx_Dscrptn.Size = new System.Drawing.Size(305, 25);
            this.txtbx_Dscrptn.TabIndex = 77;
            // 
            // lbl_Dscptn
            // 
            this.lbl_Dscptn.AutoSize = true;
            this.lbl_Dscptn.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Dscptn.Location = new System.Drawing.Point(64, 258);
            this.lbl_Dscptn.Name = "lbl_Dscptn";
            this.lbl_Dscptn.Size = new System.Drawing.Size(116, 18);
            this.lbl_Dscptn.TabIndex = 76;
            this.lbl_Dscptn.Text = "Item Description";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Futura Bk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(60, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 22);
            this.label1.TabIndex = 75;
            this.label1.Text = "ADD ITEM";
            // 
            // txtbx_Prc
            // 
            this.txtbx_Prc.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Prc.Location = new System.Drawing.Point(64, 208);
            this.txtbx_Prc.Name = "txtbx_Prc";
            this.txtbx_Prc.Size = new System.Drawing.Size(133, 25);
            this.txtbx_Prc.TabIndex = 74;
            // 
            // lbl_Prc
            // 
            this.lbl_Prc.AutoSize = true;
            this.lbl_Prc.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Prc.Location = new System.Drawing.Point(64, 173);
            this.lbl_Prc.Name = "lbl_Prc";
            this.lbl_Prc.Size = new System.Drawing.Size(71, 18);
            this.lbl_Prc.TabIndex = 73;
            this.lbl_Prc.Text = "Unit Price";
            // 
            // txtbx_Nme
            // 
            this.txtbx_Nme.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Nme.Location = new System.Drawing.Point(64, 127);
            this.txtbx_Nme.Name = "txtbx_Nme";
            this.txtbx_Nme.Size = new System.Drawing.Size(302, 25);
            this.txtbx_Nme.TabIndex = 72;
            // 
            // lbl_ItmNme
            // 
            this.lbl_ItmNme.AutoSize = true;
            this.lbl_ItmNme.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ItmNme.Location = new System.Drawing.Point(64, 94);
            this.lbl_ItmNme.Name = "lbl_ItmNme";
            this.lbl_ItmNme.Size = new System.Drawing.Size(104, 18);
            this.lbl_ItmNme.TabIndex = 70;
            this.lbl_ItmNme.Text = "Product Name";
            // 
            // AddItmCnclbttn
            // 
            this.AddItmCnclbttn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.AddItmCnclbttn.FlatAppearance.BorderSize = 0;
            this.AddItmCnclbttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddItmCnclbttn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddItmCnclbttn.ForeColor = System.Drawing.Color.White;
            this.AddItmCnclbttn.Image = ((System.Drawing.Image)(resources.GetObject("AddItmCnclbttn.Image")));
            this.AddItmCnclbttn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AddItmCnclbttn.Location = new System.Drawing.Point(252, 365);
            this.AddItmCnclbttn.Name = "AddItmCnclbttn";
            this.AddItmCnclbttn.Size = new System.Drawing.Size(128, 42);
            this.AddItmCnclbttn.TabIndex = 68;
            this.AddItmCnclbttn.Text = "     Cancel";
            this.AddItmCnclbttn.UseVisualStyleBackColor = false;
            this.AddItmCnclbttn.Click += new System.EventHandler(this.AddItmCnclbttn_Click);
            // 
            // bttnAddItm
            // 
            this.bttnAddItm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.bttnAddItm.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.bttnAddItm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttnAddItm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnAddItm.ForeColor = System.Drawing.Color.White;
            this.bttnAddItm.Image = ((System.Drawing.Image)(resources.GetObject("bttnAddItm.Image")));
            this.bttnAddItm.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttnAddItm.Location = new System.Drawing.Point(117, 365);
            this.bttnAddItm.Name = "bttnAddItm";
            this.bttnAddItm.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bttnAddItm.Size = new System.Drawing.Size(128, 42);
            this.bttnAddItm.TabIndex = 68;
            this.bttnAddItm.Text = "    Add";
            this.bttnAddItm.UseVisualStyleBackColor = false;
            this.bttnAddItm.Click += new System.EventHandler(this.bttnAddItm_Click);
            // 
            // pnl_UpdtPrc
            // 
            this.pnl_UpdtPrc.Controls.Add(this.comboBox_ProductID);
            this.pnl_UpdtPrc.Controls.Add(this.UpdatePrce);
            this.pnl_UpdtPrc.Controls.Add(this.TxtbxUntPrc);
            this.pnl_UpdtPrc.Controls.Add(this.lblUntPrc);
            this.pnl_UpdtPrc.Controls.Add(this.lblPrdctNme);
            this.pnl_UpdtPrc.Controls.Add(this.bttnUpdte);
            this.pnl_UpdtPrc.Controls.Add(this.UppdtBtncncl);
            this.pnl_UpdtPrc.Location = new System.Drawing.Point(285, 190);
            this.pnl_UpdtPrc.Name = "pnl_UpdtPrc";
            this.pnl_UpdtPrc.Size = new System.Drawing.Size(431, 384);
            this.pnl_UpdtPrc.TabIndex = 85;
            this.pnl_UpdtPrc.Visible = false;
            // 
            // comboBox_ProductID
            // 
            this.comboBox_ProductID.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_ProductID.FormattingEnabled = true;
            this.comboBox_ProductID.Location = new System.Drawing.Point(59, 134);
            this.comboBox_ProductID.Name = "comboBox_ProductID";
            this.comboBox_ProductID.Size = new System.Drawing.Size(305, 26);
            this.comboBox_ProductID.TabIndex = 79;
            // 
            // UpdatePrce
            // 
            this.UpdatePrce.AutoSize = true;
            this.UpdatePrce.Font = new System.Drawing.Font("Futura Bk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdatePrce.Location = new System.Drawing.Point(57, 48);
            this.UpdatePrce.Name = "UpdatePrce";
            this.UpdatePrce.Size = new System.Drawing.Size(135, 22);
            this.UpdatePrce.TabIndex = 75;
            this.UpdatePrce.Text = "UPDATE PRICE";
            // 
            // TxtbxUntPrc
            // 
            this.TxtbxUntPrc.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtbxUntPrc.Location = new System.Drawing.Point(64, 217);
            this.TxtbxUntPrc.Name = "TxtbxUntPrc";
            this.TxtbxUntPrc.Size = new System.Drawing.Size(302, 25);
            this.TxtbxUntPrc.TabIndex = 74;
            // 
            // lblUntPrc
            // 
            this.lblUntPrc.AutoSize = true;
            this.lblUntPrc.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUntPrc.Location = new System.Drawing.Point(61, 187);
            this.lblUntPrc.Name = "lblUntPrc";
            this.lblUntPrc.Size = new System.Drawing.Size(71, 18);
            this.lblUntPrc.TabIndex = 73;
            this.lblUntPrc.Text = "Unit Price";
            // 
            // lblPrdctNme
            // 
            this.lblPrdctNme.AutoSize = true;
            this.lblPrdctNme.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrdctNme.Location = new System.Drawing.Point(61, 101);
            this.lblPrdctNme.Name = "lblPrdctNme";
            this.lblPrdctNme.Size = new System.Drawing.Size(104, 18);
            this.lblPrdctNme.TabIndex = 70;
            this.lblPrdctNme.Text = "Product Name";
            // 
            // bttnUpdte
            // 
            this.bttnUpdte.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.bttnUpdte.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.bttnUpdte.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttnUpdte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnUpdte.ForeColor = System.Drawing.Color.White;
            this.bttnUpdte.Image = ((System.Drawing.Image)(resources.GetObject("bttnUpdte.Image")));
            this.bttnUpdte.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttnUpdte.Location = new System.Drawing.Point(115, 282);
            this.bttnUpdte.Name = "bttnUpdte";
            this.bttnUpdte.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bttnUpdte.Size = new System.Drawing.Size(128, 42);
            this.bttnUpdte.TabIndex = 68;
            this.bttnUpdte.Text = "    Update";
            this.bttnUpdte.UseVisualStyleBackColor = false;
            this.bttnUpdte.Click += new System.EventHandler(this.bttnUpdte_Click);
            // 
            // UppdtBtncncl
            // 
            this.UppdtBtncncl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.UppdtBtncncl.FlatAppearance.BorderSize = 0;
            this.UppdtBtncncl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UppdtBtncncl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UppdtBtncncl.ForeColor = System.Drawing.Color.White;
            this.UppdtBtncncl.Image = ((System.Drawing.Image)(resources.GetObject("UppdtBtncncl.Image")));
            this.UppdtBtncncl.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.UppdtBtncncl.Location = new System.Drawing.Point(250, 282);
            this.UppdtBtncncl.Name = "UppdtBtncncl";
            this.UppdtBtncncl.Size = new System.Drawing.Size(128, 42);
            this.UppdtBtncncl.TabIndex = 68;
            this.UppdtBtncncl.Text = "     Cancel";
            this.UppdtBtncncl.UseVisualStyleBackColor = false;
            this.UppdtBtncncl.Click += new System.EventHandler(this.UppdtBtncncl_Click);
            // 
            // ItemCount
            // 
            this.ItemCount.AutoSize = true;
            this.ItemCount.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemCount.Location = new System.Drawing.Point(21, 610);
            this.ItemCount.Name = "ItemCount";
            this.ItemCount.Size = new System.Drawing.Size(128, 18);
            this.ItemCount.TabIndex = 81;
            this.ItemCount.Text = "Total records: ???";
            // 
            // ItemSearchPanel
            // 
            this.ItemSearchPanel.Controls.Add(this.ItemSearch);
            this.ItemSearchPanel.Controls.Add(this.TxtItemSearch);
            this.ItemSearchPanel.Controls.Add(this.SearchLbl2);
            this.ItemSearchPanel.Location = new System.Drawing.Point(453, 93);
            this.ItemSearchPanel.Name = "ItemSearchPanel";
            this.ItemSearchPanel.Size = new System.Drawing.Size(519, 42);
            this.ItemSearchPanel.TabIndex = 80;
            // 
            // ItemSearch
            // 
            this.ItemSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.ItemSearch.FlatAppearance.BorderSize = 0;
            this.ItemSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ItemSearch.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemSearch.ForeColor = System.Drawing.Color.White;
            this.ItemSearch.Image = ((System.Drawing.Image)(resources.GetObject("ItemSearch.Image")));
            this.ItemSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ItemSearch.Location = new System.Drawing.Point(390, 0);
            this.ItemSearch.Name = "ItemSearch";
            this.ItemSearch.Size = new System.Drawing.Size(128, 42);
            this.ItemSearch.TabIndex = 76;
            this.ItemSearch.Text = "      Search";
            this.ItemSearch.UseVisualStyleBackColor = false;
            // 
            // TxtItemSearch
            // 
            this.TxtItemSearch.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtItemSearch.Location = new System.Drawing.Point(71, 9);
            this.TxtItemSearch.Name = "TxtItemSearch";
            this.TxtItemSearch.Size = new System.Drawing.Size(310, 25);
            this.TxtItemSearch.TabIndex = 75;
            this.TxtItemSearch.TextChanged += new System.EventHandler(this.TxtItemSearch_TextChanged);
            // 
            // SearchLbl2
            // 
            this.SearchLbl2.AutoSize = true;
            this.SearchLbl2.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchLbl2.Location = new System.Drawing.Point(7, 12);
            this.SearchLbl2.Name = "SearchLbl2";
            this.SearchLbl2.Size = new System.Drawing.Size(58, 18);
            this.SearchLbl2.TabIndex = 74;
            this.SearchLbl2.Text = "Search:";
            // 
            // ItemCloseBtn
            // 
            this.ItemCloseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.ItemCloseBtn.FlatAppearance.BorderSize = 0;
            this.ItemCloseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ItemCloseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemCloseBtn.ForeColor = System.Drawing.Color.White;
            this.ItemCloseBtn.Image = ((System.Drawing.Image)(resources.GetObject("ItemCloseBtn.Image")));
            this.ItemCloseBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ItemCloseBtn.Location = new System.Drawing.Point(842, 670);
            this.ItemCloseBtn.Name = "ItemCloseBtn";
            this.ItemCloseBtn.Size = new System.Drawing.Size(128, 42);
            this.ItemCloseBtn.TabIndex = 62;
            this.ItemCloseBtn.Text = "     Close";
            this.ItemCloseBtn.UseVisualStyleBackColor = false;
            this.ItemCloseBtn.Click += new System.EventHandler(this.ItemCloseBtn_Click);
            // 
            // ItemUpdateBtn
            // 
            this.ItemUpdateBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.ItemUpdateBtn.FlatAppearance.BorderSize = 0;
            this.ItemUpdateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ItemUpdateBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemUpdateBtn.ForeColor = System.Drawing.Color.White;
            this.ItemUpdateBtn.Image = ((System.Drawing.Image)(resources.GetObject("ItemUpdateBtn.Image")));
            this.ItemUpdateBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ItemUpdateBtn.Location = new System.Drawing.Point(688, 670);
            this.ItemUpdateBtn.Name = "ItemUpdateBtn";
            this.ItemUpdateBtn.Size = new System.Drawing.Size(128, 42);
            this.ItemUpdateBtn.TabIndex = 60;
            this.ItemUpdateBtn.Text = "     Update";
            this.ItemUpdateBtn.UseVisualStyleBackColor = false;
            this.ItemUpdateBtn.Click += new System.EventHandler(this.ItemUpdateBtn_Click);
            // 
            // NewItemBtn
            // 
            this.NewItemBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.NewItemBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.NewItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewItemBtn.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewItemBtn.ForeColor = System.Drawing.Color.White;
            this.NewItemBtn.Image = ((System.Drawing.Image)(resources.GetObject("NewItemBtn.Image")));
            this.NewItemBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NewItemBtn.Location = new System.Drawing.Point(536, 670);
            this.NewItemBtn.Name = "NewItemBtn";
            this.NewItemBtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.NewItemBtn.Size = new System.Drawing.Size(128, 42);
            this.NewItemBtn.TabIndex = 58;
            this.NewItemBtn.Text = "    New";
            this.NewItemBtn.UseVisualStyleBackColor = false;
            this.NewItemBtn.Click += new System.EventHandler(this.NewItemBtn_Click);
            // 
            // Divider5
            // 
            this.Divider5.BackColor = System.Drawing.Color.Black;
            this.Divider5.Location = new System.Drawing.Point(24, 650);
            this.Divider5.Name = "Divider5";
            this.Divider5.Size = new System.Drawing.Size(943, 2);
            this.Divider5.TabIndex = 59;
            // 
            // ItemTbl
            // 
            this.ItemTbl.AllowUserToAddRows = false;
            this.ItemTbl.AllowUserToDeleteRows = false;
            this.ItemTbl.AllowUserToResizeColumns = false;
            this.ItemTbl.AllowUserToResizeRows = false;
            this.ItemTbl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.ItemTbl.BackgroundColor = System.Drawing.Color.White;
            this.ItemTbl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ItemTbl.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.ItemTbl.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ItemTbl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.ItemTbl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ItemTbl.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemID,
            this.ItemDescription,
            this.ItemUnitPrice,
            this.ItemCategory});
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ItemTbl.DefaultCellStyle = dataGridViewCellStyle14;
            this.ItemTbl.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ItemTbl.EnableHeadersVisualStyles = false;
            this.ItemTbl.GridColor = System.Drawing.Color.White;
            this.ItemTbl.Location = new System.Drawing.Point(27, 145);
            this.ItemTbl.Margin = new System.Windows.Forms.Padding(0);
            this.ItemTbl.Name = "ItemTbl";
            this.ItemTbl.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ItemTbl.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.ItemTbl.RowHeadersVisible = false;
            this.ItemTbl.RowHeadersWidth = 80;
            this.ItemTbl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ItemTbl.RowsDefaultCellStyle = dataGridViewCellStyle16;
            this.ItemTbl.RowTemplate.Height = 30;
            this.ItemTbl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ItemTbl.Size = new System.Drawing.Size(943, 444);
            this.ItemTbl.TabIndex = 57;
            // 
            // ItemID
            // 
            this.ItemID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ItemID.FillWeight = 150F;
            this.ItemID.HeaderText = "Name";
            this.ItemID.Name = "ItemID";
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ItemDescription.HeaderText = "Description";
            this.ItemDescription.Name = "ItemDescription";
            // 
            // ItemUnitPrice
            // 
            this.ItemUnitPrice.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ItemUnitPrice.FillWeight = 80F;
            this.ItemUnitPrice.HeaderText = "Unit Price";
            this.ItemUnitPrice.Name = "ItemUnitPrice";
            // 
            // ItemCategory
            // 
            this.ItemCategory.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ItemCategory.FillWeight = 80F;
            this.ItemCategory.HeaderText = "Production Point";
            this.ItemCategory.Name = "ItemCategory";
            // 
            // Divider6
            // 
            this.Divider6.BackColor = System.Drawing.Color.Black;
            this.Divider6.Location = new System.Drawing.Point(27, 76);
            this.Divider6.Name = "Divider6";
            this.Divider6.Size = new System.Drawing.Size(943, 2);
            this.Divider6.TabIndex = 56;
            // 
            // ItemLbl
            // 
            this.ItemLbl.AutoSize = true;
            this.ItemLbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemLbl.ForeColor = System.Drawing.Color.Black;
            this.ItemLbl.Location = new System.Drawing.Point(451, 21);
            this.ItemLbl.Name = "ItemLbl";
            this.ItemLbl.Size = new System.Drawing.Size(90, 39);
            this.ItemLbl.TabIndex = 55;
            this.ItemLbl.Text = "ITEM";
            // 
            // ItemProduction
            // 
            this.ItemProduction.Controls.Add(this.UPDTPRDCTN);
            this.ItemProduction.Controls.Add(this.pnl_NwPrdctn);
            this.ItemProduction.Controls.Add(this.IProductionSearchPanel);
            this.ItemProduction.Controls.Add(this.ProductionCount);
            this.ItemProduction.Controls.Add(this.IProductionCloseBtn);
            this.ItemProduction.Controls.Add(this.IProductionUpdateBtn);
            this.ItemProduction.Controls.Add(this.Divider22);
            this.ItemProduction.Controls.Add(this.IProductionNewBtn);
            this.ItemProduction.Controls.Add(this.ItemProductionTbl);
            this.ItemProduction.Controls.Add(this.Divider21);
            this.ItemProduction.Controls.Add(this.ItemProductionLbl);
            this.ItemProduction.Location = new System.Drawing.Point(343, 12);
            this.ItemProduction.Name = "ItemProduction";
            this.ItemProduction.Size = new System.Drawing.Size(998, 735);
            this.ItemProduction.TabIndex = 70;
            this.ItemProduction.Visible = false;
            // 
            // UPDTPRDCTN
            // 
            this.UPDTPRDCTN.Controls.Add(this.label16);
            this.UPDTPRDCTN.Controls.Add(this.productiobCBX);
            this.UPDTPRDCTN.Controls.Add(this.Reason);
            this.UPDTPRDCTN.Controls.Add(this.operationCB);
            this.UPDTPRDCTN.Controls.Add(this.lbl_RsnUpdt);
            this.UPDTPRDCTN.Controls.Add(this.txtbx_QnttyUpdte);
            this.UPDTPRDCTN.Controls.Add(this.UpdateClose);
            this.UPDTPRDCTN.Controls.Add(this.BTTN_PrdctnUpdt);
            this.UPDTPRDCTN.Controls.Add(this.lbl_QnttyUpdt);
            this.UPDTPRDCTN.Controls.Add(this.lbl_PrdctUpdte);
            this.UPDTPRDCTN.Controls.Add(this.UpdtPrdctCBX);
            this.UPDTPRDCTN.Controls.Add(this.lbl_UpdtPrdctn);
            this.UPDTPRDCTN.Location = new System.Drawing.Point(294, 142);
            this.UPDTPRDCTN.Name = "UPDTPRDCTN";
            this.UPDTPRDCTN.Size = new System.Drawing.Size(407, 463);
            this.UPDTPRDCTN.TabIndex = 90;
            this.UPDTPRDCTN.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(60, 76);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(98, 18);
            this.label16.TabIndex = 101;
            this.label16.Text = "Production ID";
            // 
            // productiobCBX
            // 
            this.productiobCBX.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productiobCBX.FormattingEnabled = true;
            this.productiobCBX.Location = new System.Drawing.Point(62, 107);
            this.productiobCBX.Name = "productiobCBX";
            this.productiobCBX.Size = new System.Drawing.Size(286, 26);
            this.productiobCBX.TabIndex = 100;
            this.productiobCBX.SelectedIndexChanged += new System.EventHandler(this.productiobCBX_SelectedIndexChanged);
            // 
            // Reason
            // 
            this.Reason.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reason.Location = new System.Drawing.Point(63, 319);
            this.Reason.Name = "Reason";
            this.Reason.Size = new System.Drawing.Size(287, 25);
            this.Reason.TabIndex = 99;
            // 
            // operationCB
            // 
            this.operationCB.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.operationCB.FormattingEnabled = true;
            this.operationCB.Location = new System.Drawing.Point(64, 250);
            this.operationCB.Name = "operationCB";
            this.operationCB.Size = new System.Drawing.Size(78, 26);
            this.operationCB.TabIndex = 98;
            // 
            // lbl_RsnUpdt
            // 
            this.lbl_RsnUpdt.AutoSize = true;
            this.lbl_RsnUpdt.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_RsnUpdt.Location = new System.Drawing.Point(60, 289);
            this.lbl_RsnUpdt.Name = "lbl_RsnUpdt";
            this.lbl_RsnUpdt.Size = new System.Drawing.Size(56, 18);
            this.lbl_RsnUpdt.TabIndex = 95;
            this.lbl_RsnUpdt.Text = "Reason";
            // 
            // txtbx_QnttyUpdte
            // 
            this.txtbx_QnttyUpdte.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_QnttyUpdte.Location = new System.Drawing.Point(153, 251);
            this.txtbx_QnttyUpdte.Name = "txtbx_QnttyUpdte";
            this.txtbx_QnttyUpdte.Size = new System.Drawing.Size(196, 25);
            this.txtbx_QnttyUpdte.TabIndex = 83;
            // 
            // UpdateClose
            // 
            this.UpdateClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.UpdateClose.FlatAppearance.BorderSize = 0;
            this.UpdateClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateClose.ForeColor = System.Drawing.Color.White;
            this.UpdateClose.Image = ((System.Drawing.Image)(resources.GetObject("UpdateClose.Image")));
            this.UpdateClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.UpdateClose.Location = new System.Drawing.Point(229, 381);
            this.UpdateClose.Name = "UpdateClose";
            this.UpdateClose.Size = new System.Drawing.Size(128, 42);
            this.UpdateClose.TabIndex = 64;
            this.UpdateClose.Text = "     Cancel";
            this.UpdateClose.UseVisualStyleBackColor = false;
            this.UpdateClose.Click += new System.EventHandler(this.UpdateClose_Click);
            // 
            // BTTN_PrdctnUpdt
            // 
            this.BTTN_PrdctnUpdt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.BTTN_PrdctnUpdt.FlatAppearance.BorderSize = 0;
            this.BTTN_PrdctnUpdt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTTN_PrdctnUpdt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTTN_PrdctnUpdt.ForeColor = System.Drawing.Color.White;
            this.BTTN_PrdctnUpdt.Image = ((System.Drawing.Image)(resources.GetObject("BTTN_PrdctnUpdt.Image")));
            this.BTTN_PrdctnUpdt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTTN_PrdctnUpdt.Location = new System.Drawing.Point(93, 381);
            this.BTTN_PrdctnUpdt.Name = "BTTN_PrdctnUpdt";
            this.BTTN_PrdctnUpdt.Size = new System.Drawing.Size(128, 42);
            this.BTTN_PrdctnUpdt.TabIndex = 81;
            this.BTTN_PrdctnUpdt.Text = "     Update";
            this.BTTN_PrdctnUpdt.UseVisualStyleBackColor = false;
            this.BTTN_PrdctnUpdt.Click += new System.EventHandler(this.BTTN_PrdctnUpdt_Click);
            // 
            // lbl_QnttyUpdt
            // 
            this.lbl_QnttyUpdt.AutoSize = true;
            this.lbl_QnttyUpdt.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_QnttyUpdt.Location = new System.Drawing.Point(61, 223);
            this.lbl_QnttyUpdt.Name = "lbl_QnttyUpdt";
            this.lbl_QnttyUpdt.Size = new System.Drawing.Size(65, 18);
            this.lbl_QnttyUpdt.TabIndex = 80;
            this.lbl_QnttyUpdt.Text = "Quantity";
            // 
            // lbl_PrdctUpdte
            // 
            this.lbl_PrdctUpdte.AutoSize = true;
            this.lbl_PrdctUpdte.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PrdctUpdte.Location = new System.Drawing.Point(61, 151);
            this.lbl_PrdctUpdte.Name = "lbl_PrdctUpdte";
            this.lbl_PrdctUpdte.Size = new System.Drawing.Size(58, 18);
            this.lbl_PrdctUpdte.TabIndex = 78;
            this.lbl_PrdctUpdte.Text = "Product";
            // 
            // UpdtPrdctCBX
            // 
            this.UpdtPrdctCBX.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdtPrdctCBX.FormattingEnabled = true;
            this.UpdtPrdctCBX.Location = new System.Drawing.Point(63, 182);
            this.UpdtPrdctCBX.Name = "UpdtPrdctCBX";
            this.UpdtPrdctCBX.Size = new System.Drawing.Size(286, 26);
            this.UpdtPrdctCBX.TabIndex = 77;
            this.UpdtPrdctCBX.SelectedIndexChanged += new System.EventHandler(this.UpdtPrdctCBX_SelectedIndexChanged);
            // 
            // lbl_UpdtPrdctn
            // 
            this.lbl_UpdtPrdctn.AutoSize = true;
            this.lbl_UpdtPrdctn.Font = new System.Drawing.Font("Futura Bk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UpdtPrdctn.Location = new System.Drawing.Point(32, 31);
            this.lbl_UpdtPrdctn.Name = "lbl_UpdtPrdctn";
            this.lbl_UpdtPrdctn.Size = new System.Drawing.Size(168, 22);
            this.lbl_UpdtPrdctn.TabIndex = 76;
            this.lbl_UpdtPrdctn.Text = "Update Production";
            // 
            // pnl_NwPrdctn
            // 
            this.pnl_NwPrdctn.Controls.Add(this.LVProductList);
            this.pnl_NwPrdctn.Controls.Add(this.bttn_Clear);
            this.pnl_NwPrdctn.Controls.Add(this.lbl_OrderList);
            this.pnl_NwPrdctn.Controls.Add(this.bttn_Add);
            this.pnl_NwPrdctn.Controls.Add(this.txtbx_Qntty);
            this.pnl_NwPrdctn.Controls.Add(this.label14);
            this.pnl_NwPrdctn.Controls.Add(this.cmbbx_Product);
            this.pnl_NwPrdctn.Controls.Add(this.lbl_Product);
            this.pnl_NwPrdctn.Controls.Add(this.bttn_Save);
            this.pnl_NwPrdctn.Controls.Add(this.bttn_Cancel);
            this.pnl_NwPrdctn.Controls.Add(this.lbl_Nwprdctn);
            this.pnl_NwPrdctn.Location = new System.Drawing.Point(183, 145);
            this.pnl_NwPrdctn.Name = "pnl_NwPrdctn";
            this.pnl_NwPrdctn.Size = new System.Drawing.Size(632, 360);
            this.pnl_NwPrdctn.TabIndex = 89;
            this.pnl_NwPrdctn.Visible = false;
            // 
            // LVProductList
            // 
            this.LVProductList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Quantity,
            this.Product});
            this.LVProductList.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LVProductList.HideSelection = false;
            this.LVProductList.Location = new System.Drawing.Point(333, 110);
            this.LVProductList.Name = "LVProductList";
            this.LVProductList.Size = new System.Drawing.Size(250, 156);
            this.LVProductList.TabIndex = 91;
            this.LVProductList.UseCompatibleStateImageBehavior = false;
            this.LVProductList.View = System.Windows.Forms.View.Details;
            // 
            // Quantity
            // 
            this.Quantity.Text = "Qty";
            this.Quantity.Width = 80;
            // 
            // Product
            // 
            this.Product.Text = "Product";
            this.Product.Width = 130;
            // 
            // bttn_Clear
            // 
            this.bttn_Clear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.bttn_Clear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.bttn_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_Clear.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_Clear.ForeColor = System.Drawing.Color.White;
            this.bttn_Clear.Image = ((System.Drawing.Image)(resources.GetObject("bttn_Clear.Image")));
            this.bttn_Clear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttn_Clear.Location = new System.Drawing.Point(43, 286);
            this.bttn_Clear.Name = "bttn_Clear";
            this.bttn_Clear.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bttn_Clear.Size = new System.Drawing.Size(128, 42);
            this.bttn_Clear.TabIndex = 90;
            this.bttn_Clear.Text = "    Clear";
            this.bttn_Clear.UseVisualStyleBackColor = false;
            this.bttn_Clear.Click += new System.EventHandler(this.bttn_Clear_Click);
            // 
            // lbl_OrderList
            // 
            this.lbl_OrderList.AutoSize = true;
            this.lbl_OrderList.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_OrderList.Location = new System.Drawing.Point(334, 81);
            this.lbl_OrderList.Name = "lbl_OrderList";
            this.lbl_OrderList.Size = new System.Drawing.Size(83, 18);
            this.lbl_OrderList.TabIndex = 89;
            this.lbl_OrderList.Text = "Product List";
            // 
            // bttn_Add
            // 
            this.bttn_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.bttn_Add.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.bttn_Add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_Add.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_Add.ForeColor = System.Drawing.Color.White;
            this.bttn_Add.Image = ((System.Drawing.Image)(resources.GetObject("bttn_Add.Image")));
            this.bttn_Add.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttn_Add.Location = new System.Drawing.Point(180, 286);
            this.bttn_Add.Name = "bttn_Add";
            this.bttn_Add.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bttn_Add.Size = new System.Drawing.Size(128, 42);
            this.bttn_Add.TabIndex = 87;
            this.bttn_Add.Text = "    Add";
            this.bttn_Add.UseVisualStyleBackColor = false;
            this.bttn_Add.Click += new System.EventHandler(this.bttn_Add_Click);
            // 
            // txtbx_Qntty
            // 
            this.txtbx_Qntty.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_Qntty.Location = new System.Drawing.Point(45, 221);
            this.txtbx_Qntty.Name = "txtbx_Qntty";
            this.txtbx_Qntty.Size = new System.Drawing.Size(231, 25);
            this.txtbx_Qntty.TabIndex = 86;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(42, 190);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 18);
            this.label14.TabIndex = 85;
            this.label14.Text = "Quantity";
            // 
            // cmbbx_Product
            // 
            this.cmbbx_Product.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbbx_Product.Location = new System.Drawing.Point(43, 141);
            this.cmbbx_Product.Name = "cmbbx_Product";
            this.cmbbx_Product.Size = new System.Drawing.Size(231, 26);
            this.cmbbx_Product.TabIndex = 82;
            // 
            // lbl_Product
            // 
            this.lbl_Product.AutoSize = true;
            this.lbl_Product.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Product.Location = new System.Drawing.Point(41, 115);
            this.lbl_Product.Name = "lbl_Product";
            this.lbl_Product.Size = new System.Drawing.Size(58, 18);
            this.lbl_Product.TabIndex = 81;
            this.lbl_Product.Text = "Product";
            // 
            // bttn_Save
            // 
            this.bttn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.bttn_Save.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.bttn_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_Save.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_Save.ForeColor = System.Drawing.Color.White;
            this.bttn_Save.Image = ((System.Drawing.Image)(resources.GetObject("bttn_Save.Image")));
            this.bttn_Save.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttn_Save.Location = new System.Drawing.Point(315, 286);
            this.bttn_Save.Name = "bttn_Save";
            this.bttn_Save.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bttn_Save.Size = new System.Drawing.Size(128, 42);
            this.bttn_Save.TabIndex = 77;
            this.bttn_Save.Text = "    Save";
            this.bttn_Save.UseVisualStyleBackColor = false;
            this.bttn_Save.Click += new System.EventHandler(this.bttn_Save_Click);
            // 
            // bttn_Cancel
            // 
            this.bttn_Cancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.bttn_Cancel.FlatAppearance.BorderSize = 0;
            this.bttn_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_Cancel.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_Cancel.ForeColor = System.Drawing.Color.White;
            this.bttn_Cancel.Image = ((System.Drawing.Image)(resources.GetObject("bttn_Cancel.Image")));
            this.bttn_Cancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttn_Cancel.Location = new System.Drawing.Point(452, 286);
            this.bttn_Cancel.Name = "bttn_Cancel";
            this.bttn_Cancel.Size = new System.Drawing.Size(128, 42);
            this.bttn_Cancel.TabIndex = 64;
            this.bttn_Cancel.Text = "     Cancel";
            this.bttn_Cancel.UseVisualStyleBackColor = false;
            this.bttn_Cancel.Click += new System.EventHandler(this.bttn_Cancel_Click);
            // 
            // lbl_Nwprdctn
            // 
            this.lbl_Nwprdctn.AutoSize = true;
            this.lbl_Nwprdctn.Font = new System.Drawing.Font("Futura Bk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Nwprdctn.Location = new System.Drawing.Point(41, 51);
            this.lbl_Nwprdctn.Name = "lbl_Nwprdctn";
            this.lbl_Nwprdctn.Size = new System.Drawing.Size(144, 22);
            this.lbl_Nwprdctn.TabIndex = 76;
            this.lbl_Nwprdctn.Text = "New Production";
            // 
            // IProductionSearchPanel
            // 
            this.IProductionSearchPanel.Controls.Add(this.IProductionSearch);
            this.IProductionSearchPanel.Controls.Add(this.TxtProductionSearch);
            this.IProductionSearchPanel.Controls.Add(this.SearchLbl14);
            this.IProductionSearchPanel.Location = new System.Drawing.Point(453, 93);
            this.IProductionSearchPanel.Name = "IProductionSearchPanel";
            this.IProductionSearchPanel.Size = new System.Drawing.Size(517, 42);
            this.IProductionSearchPanel.TabIndex = 85;
            // 
            // IProductionSearch
            // 
            this.IProductionSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.IProductionSearch.FlatAppearance.BorderSize = 0;
            this.IProductionSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.IProductionSearch.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IProductionSearch.ForeColor = System.Drawing.Color.White;
            this.IProductionSearch.Image = ((System.Drawing.Image)(resources.GetObject("IProductionSearch.Image")));
            this.IProductionSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.IProductionSearch.Location = new System.Drawing.Point(390, 0);
            this.IProductionSearch.Name = "IProductionSearch";
            this.IProductionSearch.Size = new System.Drawing.Size(128, 42);
            this.IProductionSearch.TabIndex = 76;
            this.IProductionSearch.Text = "      Search";
            this.IProductionSearch.UseVisualStyleBackColor = false;
            // 
            // TxtProductionSearch
            // 
            this.TxtProductionSearch.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtProductionSearch.Location = new System.Drawing.Point(71, 9);
            this.TxtProductionSearch.Name = "TxtProductionSearch";
            this.TxtProductionSearch.Size = new System.Drawing.Size(310, 25);
            this.TxtProductionSearch.TabIndex = 75;
            // 
            // SearchLbl14
            // 
            this.SearchLbl14.AutoSize = true;
            this.SearchLbl14.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchLbl14.Location = new System.Drawing.Point(7, 12);
            this.SearchLbl14.Name = "SearchLbl14";
            this.SearchLbl14.Size = new System.Drawing.Size(58, 18);
            this.SearchLbl14.TabIndex = 74;
            this.SearchLbl14.Text = "Search:";
            // 
            // ProductionCount
            // 
            this.ProductionCount.AutoSize = true;
            this.ProductionCount.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProductionCount.Location = new System.Drawing.Point(21, 610);
            this.ProductionCount.Name = "ProductionCount";
            this.ProductionCount.Size = new System.Drawing.Size(128, 18);
            this.ProductionCount.TabIndex = 84;
            this.ProductionCount.Text = "Total records: ???";
            // 
            // IProductionCloseBtn
            // 
            this.IProductionCloseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.IProductionCloseBtn.FlatAppearance.BorderSize = 0;
            this.IProductionCloseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.IProductionCloseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IProductionCloseBtn.ForeColor = System.Drawing.Color.White;
            this.IProductionCloseBtn.Image = ((System.Drawing.Image)(resources.GetObject("IProductionCloseBtn.Image")));
            this.IProductionCloseBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.IProductionCloseBtn.Location = new System.Drawing.Point(842, 670);
            this.IProductionCloseBtn.Name = "IProductionCloseBtn";
            this.IProductionCloseBtn.Size = new System.Drawing.Size(128, 42);
            this.IProductionCloseBtn.TabIndex = 62;
            this.IProductionCloseBtn.Text = "     Close";
            this.IProductionCloseBtn.UseVisualStyleBackColor = false;
            this.IProductionCloseBtn.Click += new System.EventHandler(this.IProductionCloseBtn_Click);
            // 
            // IProductionUpdateBtn
            // 
            this.IProductionUpdateBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.IProductionUpdateBtn.FlatAppearance.BorderSize = 0;
            this.IProductionUpdateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.IProductionUpdateBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IProductionUpdateBtn.ForeColor = System.Drawing.Color.White;
            this.IProductionUpdateBtn.Image = ((System.Drawing.Image)(resources.GetObject("IProductionUpdateBtn.Image")));
            this.IProductionUpdateBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.IProductionUpdateBtn.Location = new System.Drawing.Point(537, 670);
            this.IProductionUpdateBtn.Name = "IProductionUpdateBtn";
            this.IProductionUpdateBtn.Size = new System.Drawing.Size(128, 42);
            this.IProductionUpdateBtn.TabIndex = 60;
            this.IProductionUpdateBtn.Text = "     Update";
            this.IProductionUpdateBtn.UseVisualStyleBackColor = false;
            this.IProductionUpdateBtn.Visible = false;
            this.IProductionUpdateBtn.Click += new System.EventHandler(this.IProductionUpdateBtn_Click);
            // 
            // Divider22
            // 
            this.Divider22.BackColor = System.Drawing.Color.Black;
            this.Divider22.Location = new System.Drawing.Point(24, 650);
            this.Divider22.Name = "Divider22";
            this.Divider22.Size = new System.Drawing.Size(943, 2);
            this.Divider22.TabIndex = 59;
            // 
            // IProductionNewBtn
            // 
            this.IProductionNewBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.IProductionNewBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.IProductionNewBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.IProductionNewBtn.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IProductionNewBtn.ForeColor = System.Drawing.Color.White;
            this.IProductionNewBtn.Image = ((System.Drawing.Image)(resources.GetObject("IProductionNewBtn.Image")));
            this.IProductionNewBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.IProductionNewBtn.Location = new System.Drawing.Point(688, 670);
            this.IProductionNewBtn.Name = "IProductionNewBtn";
            this.IProductionNewBtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.IProductionNewBtn.Size = new System.Drawing.Size(128, 42);
            this.IProductionNewBtn.TabIndex = 58;
            this.IProductionNewBtn.Text = "    New";
            this.IProductionNewBtn.UseVisualStyleBackColor = false;
            this.IProductionNewBtn.Click += new System.EventHandler(this.IProductionNewBtn_Click);
            // 
            // ItemProductionTbl
            // 
            this.ItemProductionTbl.AllowUserToAddRows = false;
            this.ItemProductionTbl.AllowUserToDeleteRows = false;
            this.ItemProductionTbl.AllowUserToResizeColumns = false;
            this.ItemProductionTbl.AllowUserToResizeRows = false;
            this.ItemProductionTbl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.ItemProductionTbl.BackgroundColor = System.Drawing.Color.White;
            this.ItemProductionTbl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ItemProductionTbl.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.ItemProductionTbl.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ItemProductionTbl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.ItemProductionTbl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ItemProductionTbl.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IProductDate,
            this.IProductionNo,
            this.IItemID,
            this.IProduct,
            this.IQuantity});
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ItemProductionTbl.DefaultCellStyle = dataGridViewCellStyle18;
            this.ItemProductionTbl.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ItemProductionTbl.EnableHeadersVisualStyles = false;
            this.ItemProductionTbl.GridColor = System.Drawing.Color.White;
            this.ItemProductionTbl.Location = new System.Drawing.Point(27, 145);
            this.ItemProductionTbl.Margin = new System.Windows.Forms.Padding(0);
            this.ItemProductionTbl.Name = "ItemProductionTbl";
            this.ItemProductionTbl.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ItemProductionTbl.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.ItemProductionTbl.RowHeadersVisible = false;
            this.ItemProductionTbl.RowHeadersWidth = 80;
            this.ItemProductionTbl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ItemProductionTbl.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.ItemProductionTbl.RowTemplate.Height = 30;
            this.ItemProductionTbl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ItemProductionTbl.Size = new System.Drawing.Size(943, 444);
            this.ItemProductionTbl.TabIndex = 57;
            // 
            // IProductDate
            // 
            this.IProductDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.IProductDate.FillWeight = 80F;
            this.IProductDate.HeaderText = "Arrival Date";
            this.IProductDate.Name = "IProductDate";
            // 
            // IProductionNo
            // 
            this.IProductionNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.IProductionNo.FillWeight = 80F;
            this.IProductionNo.HeaderText = "Production No";
            this.IProductionNo.Name = "IProductionNo";
            // 
            // IItemID
            // 
            this.IItemID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.IItemID.FillWeight = 80F;
            this.IItemID.HeaderText = "Item ID";
            this.IItemID.Name = "IItemID";
            // 
            // IProduct
            // 
            this.IProduct.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.IProduct.FillWeight = 130F;
            this.IProduct.HeaderText = "Product";
            this.IProduct.Name = "IProduct";
            // 
            // IQuantity
            // 
            this.IQuantity.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.IQuantity.FillWeight = 80F;
            this.IQuantity.HeaderText = "Quantity";
            this.IQuantity.Name = "IQuantity";
            // 
            // Divider21
            // 
            this.Divider21.BackColor = System.Drawing.Color.Black;
            this.Divider21.Location = new System.Drawing.Point(27, 76);
            this.Divider21.Name = "Divider21";
            this.Divider21.Size = new System.Drawing.Size(943, 2);
            this.Divider21.TabIndex = 56;
            // 
            // ItemProductionLbl
            // 
            this.ItemProductionLbl.AutoSize = true;
            this.ItemProductionLbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemProductionLbl.ForeColor = System.Drawing.Color.Black;
            this.ItemProductionLbl.Location = new System.Drawing.Point(366, 22);
            this.ItemProductionLbl.Name = "ItemProductionLbl";
            this.ItemProductionLbl.Size = new System.Drawing.Size(319, 39);
            this.ItemProductionLbl.TabIndex = 55;
            this.ItemProductionLbl.Text = "ITEM PRODUCTION";
            // 
            // Invoice
            // 
            this.Invoice.Controls.Add(this.panel5);
            this.Invoice.Controls.Add(this.InvoiceTbl);
            this.Invoice.Controls.Add(this.InvoiceSearchPanel);
            this.Invoice.Controls.Add(this.InvoiceCount);
            this.Invoice.Controls.Add(this.CloseInvoiceBtn);
            this.Invoice.Controls.Add(this.Divider8);
            this.Invoice.Controls.Add(this.Divider7);
            this.Invoice.Controls.Add(this.Invoicelbl);
            this.Invoice.Location = new System.Drawing.Point(343, 12);
            this.Invoice.Name = "Invoice";
            this.Invoice.Size = new System.Drawing.Size(998, 735);
            this.Invoice.TabIndex = 71;
            this.Invoice.Visible = false;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.btnClose);
            this.panel5.Controls.Add(this.dataGridView2);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.lblName);
            this.panel5.Controls.Add(this.label2);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.btnPrint);
            this.panel5.Controls.Add(this.lblSubTotal);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.lblDate);
            this.panel5.Controls.Add(this.lblOrder);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Location = new System.Drawing.Point(298, 110);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(403, 514);
            this.panel5.TabIndex = 89;
            this.panel5.Visible = false;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.ForeColor = System.Drawing.Color.Black;
            this.btnClose.Location = new System.Drawing.Point(354, -1);
            this.btnClose.Margin = new System.Windows.Forms.Padding(2);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(56, 19);
            this.btnClose.TabIndex = 38;
            this.btnClose.Text = "X";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.ColumnHeadersVisible = false;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productname,
            this.qty,
            this.unitprice,
            this.total});
            this.dataGridView2.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView2.Location = new System.Drawing.Point(5, 193);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowHeadersWidth = 49;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(388, 214);
            this.dataGridView2.TabIndex = 37;
            // 
            // productname
            // 
            this.productname.FillWeight = 150F;
            this.productname.HeaderText = "Product Name";
            this.productname.MinimumWidth = 6;
            this.productname.Name = "productname";
            this.productname.ReadOnly = true;
            // 
            // qty
            // 
            this.qty.FillWeight = 150F;
            this.qty.HeaderText = "Qty";
            this.qty.MinimumWidth = 6;
            this.qty.Name = "qty";
            this.qty.ReadOnly = true;
            this.qty.Width = 80;
            // 
            // unitprice
            // 
            this.unitprice.FillWeight = 80F;
            this.unitprice.HeaderText = "Unit Price";
            this.unitprice.MinimumWidth = 6;
            this.unitprice.Name = "unitprice";
            this.unitprice.ReadOnly = true;
            this.unitprice.Width = 80;
            // 
            // total
            // 
            this.total.HeaderText = "Total";
            this.total.MinimumWidth = 6;
            this.total.Name = "total";
            this.total.ReadOnly = true;
            this.total.Width = 80;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(2, 172);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(451, 13);
            this.label13.TabIndex = 36;
            this.label13.Text = "__________________________________________________________________________\r\n";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(97, 115);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(34, 14);
            this.lblName.TabIndex = 35;
            this.lblName.Text = "name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 14);
            this.label2.TabIndex = 34;
            this.label2.Text = "Customer Name:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(344, 158);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 14);
            this.label6.TabIndex = 33;
            this.label6.Text = "Total";
            // 
            // btnPrint
            // 
            this.btnPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrint.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.ForeColor = System.Drawing.Color.White;
            this.btnPrint.Location = new System.Drawing.Point(147, 459);
            this.btnPrint.Margin = new System.Windows.Forms.Padding(2);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(128, 42);
            this.btnPrint.TabIndex = 32;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // lblSubTotal
            // 
            this.lblSubTotal.AutoSize = true;
            this.lblSubTotal.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubTotal.Location = new System.Drawing.Point(326, 427);
            this.lblSubTotal.Name = "lblSubTotal";
            this.lblSubTotal.Size = new System.Drawing.Size(28, 14);
            this.lblSubTotal.TabIndex = 31;
            this.lblSubTotal.Text = "total";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(240, 426);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 14);
            this.label12.TabIndex = 30;
            this.label12.Text = "Total Amount:";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(54, 97);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(28, 14);
            this.lblDate.TabIndex = 29;
            this.lblDate.Text = "date";
            // 
            // lblOrder
            // 
            this.lblOrder.AutoSize = true;
            this.lblOrder.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrder.Location = new System.Drawing.Point(75, 77);
            this.lblOrder.Name = "lblOrder";
            this.lblOrder.Size = new System.Drawing.Size(33, 14);
            this.lblOrder.TabIndex = 28;
            this.lblOrder.Text = "order";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(244, 158);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 14);
            this.label9.TabIndex = 27;
            this.label9.Text = "Unit Price";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(177, 158);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 14);
            this.label8.TabIndex = 26;
            this.label8.Text = "Qty";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(10, 158);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 14);
            this.label7.TabIndex = 25;
            this.label7.Text = "Product Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(2, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(451, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "__________________________________________________________________________\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 14);
            this.label3.TabIndex = 23;
            this.label3.Text = "Date :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Futura Bk BT", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(10, 77);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 14);
            this.label10.TabIndex = 22;
            this.label10.Text = "Invoice No: ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Futura Bk BT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(142, 24);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(116, 25);
            this.label11.TabIndex = 21;
            this.label11.Text = "LUMINAIRE";
            // 
            // InvoiceTbl
            // 
            this.InvoiceTbl.AllowUserToAddRows = false;
            this.InvoiceTbl.AllowUserToDeleteRows = false;
            this.InvoiceTbl.AllowUserToResizeColumns = false;
            this.InvoiceTbl.AllowUserToResizeRows = false;
            this.InvoiceTbl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.InvoiceTbl.BackgroundColor = System.Drawing.Color.White;
            this.InvoiceTbl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.InvoiceTbl.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.InvoiceTbl.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle21.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.InvoiceTbl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.InvoiceTbl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.InvoiceTbl.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.invoicedate,
            this.invoiceno,
            this.customername,
            this.dataGridViewTextBoxColumn1,
            this.totalamount,
            this.print});
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.InvoiceTbl.DefaultCellStyle = dataGridViewCellStyle22;
            this.InvoiceTbl.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.InvoiceTbl.EnableHeadersVisualStyles = false;
            this.InvoiceTbl.GridColor = System.Drawing.Color.White;
            this.InvoiceTbl.Location = new System.Drawing.Point(28, 145);
            this.InvoiceTbl.Margin = new System.Windows.Forms.Padding(0);
            this.InvoiceTbl.Name = "InvoiceTbl";
            this.InvoiceTbl.ReadOnly = true;
            this.InvoiceTbl.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Futura Bk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.InvoiceTbl.RowHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.InvoiceTbl.RowHeadersVisible = false;
            this.InvoiceTbl.RowHeadersWidth = 80;
            this.InvoiceTbl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.InvoiceTbl.RowsDefaultCellStyle = dataGridViewCellStyle24;
            this.InvoiceTbl.RowTemplate.Height = 30;
            this.InvoiceTbl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.InvoiceTbl.Size = new System.Drawing.Size(943, 444);
            this.InvoiceTbl.TabIndex = 90;
            this.InvoiceTbl.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.InvoiceTbl_CellClick);
            // 
            // invoicedate
            // 
            this.invoicedate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.invoicedate.HeaderText = "Invoice Date";
            this.invoicedate.MinimumWidth = 6;
            this.invoicedate.Name = "invoicedate";
            this.invoicedate.ReadOnly = true;
            // 
            // invoiceno
            // 
            this.invoiceno.HeaderText = "Invoice No.";
            this.invoiceno.MinimumWidth = 6;
            this.invoiceno.Name = "invoiceno";
            this.invoiceno.ReadOnly = true;
            this.invoiceno.Width = 120;
            // 
            // customername
            // 
            this.customername.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.customername.HeaderText = "Customer Name";
            this.customername.MinimumWidth = 6;
            this.customername.Name = "customername";
            this.customername.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.HeaderText = "Due Date";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // totalamount
            // 
            this.totalamount.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.totalamount.HeaderText = "Total Amount";
            this.totalamount.MinimumWidth = 6;
            this.totalamount.Name = "totalamount";
            this.totalamount.ReadOnly = true;
            this.totalamount.Width = 105;
            // 
            // print
            // 
            this.print.FillWeight = 30F;
            this.print.HeaderText = "";
            this.print.Image = ((System.Drawing.Image)(resources.GetObject("print.Image")));
            this.print.MinimumWidth = 6;
            this.print.Name = "print";
            this.print.ReadOnly = true;
            this.print.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.print.Width = 30;
            // 
            // InvoiceSearchPanel
            // 
            this.InvoiceSearchPanel.Controls.Add(this.InvoiceSearch);
            this.InvoiceSearchPanel.Controls.Add(this.TxtInvoiceSearch);
            this.InvoiceSearchPanel.Controls.Add(this.SearchLbl3);
            this.InvoiceSearchPanel.Location = new System.Drawing.Point(453, 93);
            this.InvoiceSearchPanel.Name = "InvoiceSearchPanel";
            this.InvoiceSearchPanel.Size = new System.Drawing.Size(518, 42);
            this.InvoiceSearchPanel.TabIndex = 86;
            // 
            // InvoiceSearch
            // 
            this.InvoiceSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.InvoiceSearch.FlatAppearance.BorderSize = 0;
            this.InvoiceSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InvoiceSearch.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvoiceSearch.ForeColor = System.Drawing.Color.White;
            this.InvoiceSearch.Image = ((System.Drawing.Image)(resources.GetObject("InvoiceSearch.Image")));
            this.InvoiceSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.InvoiceSearch.Location = new System.Drawing.Point(390, 0);
            this.InvoiceSearch.Name = "InvoiceSearch";
            this.InvoiceSearch.Size = new System.Drawing.Size(128, 42);
            this.InvoiceSearch.TabIndex = 76;
            this.InvoiceSearch.Text = "      Search";
            this.InvoiceSearch.UseVisualStyleBackColor = false;
            this.InvoiceSearch.Click += new System.EventHandler(this.InvoiceSearch_Click);
            // 
            // TxtInvoiceSearch
            // 
            this.TxtInvoiceSearch.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtInvoiceSearch.Location = new System.Drawing.Point(71, 9);
            this.TxtInvoiceSearch.Name = "TxtInvoiceSearch";
            this.TxtInvoiceSearch.Size = new System.Drawing.Size(310, 25);
            this.TxtInvoiceSearch.TabIndex = 75;
            // 
            // SearchLbl3
            // 
            this.SearchLbl3.AutoSize = true;
            this.SearchLbl3.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchLbl3.Location = new System.Drawing.Point(7, 12);
            this.SearchLbl3.Name = "SearchLbl3";
            this.SearchLbl3.Size = new System.Drawing.Size(58, 18);
            this.SearchLbl3.TabIndex = 74;
            this.SearchLbl3.Text = "Search:";
            // 
            // InvoiceCount
            // 
            this.InvoiceCount.AutoSize = true;
            this.InvoiceCount.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvoiceCount.Location = new System.Drawing.Point(21, 610);
            this.InvoiceCount.Name = "InvoiceCount";
            this.InvoiceCount.Size = new System.Drawing.Size(128, 18);
            this.InvoiceCount.TabIndex = 85;
            this.InvoiceCount.Text = "Total records: ???";
            // 
            // CloseInvoiceBtn
            // 
            this.CloseInvoiceBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.CloseInvoiceBtn.FlatAppearance.BorderSize = 0;
            this.CloseInvoiceBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CloseInvoiceBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CloseInvoiceBtn.ForeColor = System.Drawing.Color.White;
            this.CloseInvoiceBtn.Image = ((System.Drawing.Image)(resources.GetObject("CloseInvoiceBtn.Image")));
            this.CloseInvoiceBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CloseInvoiceBtn.Location = new System.Drawing.Point(842, 670);
            this.CloseInvoiceBtn.Name = "CloseInvoiceBtn";
            this.CloseInvoiceBtn.Size = new System.Drawing.Size(128, 42);
            this.CloseInvoiceBtn.TabIndex = 62;
            this.CloseInvoiceBtn.Text = "     Close";
            this.CloseInvoiceBtn.UseVisualStyleBackColor = false;
            this.CloseInvoiceBtn.Click += new System.EventHandler(this.CloseInvoiceBtn_Click);
            // 
            // Divider8
            // 
            this.Divider8.BackColor = System.Drawing.Color.Black;
            this.Divider8.Location = new System.Drawing.Point(24, 650);
            this.Divider8.Name = "Divider8";
            this.Divider8.Size = new System.Drawing.Size(943, 2);
            this.Divider8.TabIndex = 59;
            // 
            // Divider7
            // 
            this.Divider7.BackColor = System.Drawing.Color.Black;
            this.Divider7.Location = new System.Drawing.Point(27, 76);
            this.Divider7.Name = "Divider7";
            this.Divider7.Size = new System.Drawing.Size(943, 2);
            this.Divider7.TabIndex = 56;
            // 
            // Invoicelbl
            // 
            this.Invoicelbl.AutoSize = true;
            this.Invoicelbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Invoicelbl.ForeColor = System.Drawing.Color.Black;
            this.Invoicelbl.Location = new System.Drawing.Point(448, 18);
            this.Invoicelbl.Name = "Invoicelbl";
            this.Invoicelbl.Size = new System.Drawing.Size(154, 39);
            this.Invoicelbl.TabIndex = 55;
            this.Invoicelbl.Text = "INVOICE";
            // 
            // SalesReturn
            // 
            this.SalesReturn.Controls.Add(this.SReturnUpdateRequestPnl);
            this.SalesReturn.Controls.Add(this.SReturnNewRequestPnl);
            this.SalesReturn.Controls.Add(this.ReturnCount);
            this.SalesReturn.Controls.Add(this.SReturnDataGridView);
            this.SalesReturn.Controls.Add(this.SReturnSearchPanel);
            this.SalesReturn.Controls.Add(this.SReturnExitBtn);
            this.SalesReturn.Controls.Add(this.SReturnUpdateBtn);
            this.SalesReturn.Controls.Add(this.Divider17);
            this.SalesReturn.Controls.Add(this.SReturnNewBtn);
            this.SalesReturn.Controls.Add(this.Divider18);
            this.SalesReturn.Controls.Add(this.SalesReturnLbl);
            this.SalesReturn.Location = new System.Drawing.Point(343, 12);
            this.SalesReturn.Name = "SalesReturn";
            this.SalesReturn.Size = new System.Drawing.Size(998, 735);
            this.SalesReturn.TabIndex = 72;
            this.SalesReturn.Visible = false;
            // 
            // SReturnUpdateRequestPnl
            // 
            this.SReturnUpdateRequestPnl.BackColor = System.Drawing.Color.White;
            this.SReturnUpdateRequestPnl.Controls.Add(this.SReturnProductNameTxt);
            this.SReturnUpdateRequestPnl.Controls.Add(this.SReturnUpdateRequestBtn);
            this.SReturnUpdateRequestPnl.Controls.Add(this.SReturnUpdateStatusCmb);
            this.SReturnUpdateRequestPnl.Controls.Add(this.SReturnUpdateInvoiceCmb);
            this.SReturnUpdateRequestPnl.Controls.Add(this.label19);
            this.SReturnUpdateRequestPnl.Controls.Add(this.label15);
            this.SReturnUpdateRequestPnl.Controls.Add(this.label21);
            this.SReturnUpdateRequestPnl.Controls.Add(this.SReturnUpdateStatusCancelBtn);
            this.SReturnUpdateRequestPnl.Controls.Add(this.label22);
            this.SReturnUpdateRequestPnl.Location = new System.Drawing.Point(346, 157);
            this.SReturnUpdateRequestPnl.Name = "SReturnUpdateRequestPnl";
            this.SReturnUpdateRequestPnl.Size = new System.Drawing.Size(420, 421);
            this.SReturnUpdateRequestPnl.TabIndex = 101;
            this.SReturnUpdateRequestPnl.Visible = false;
            // 
            // SReturnProductNameTxt
            // 
            this.SReturnProductNameTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SReturnProductNameTxt.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnProductNameTxt.Location = new System.Drawing.Point(76, 198);
            this.SReturnProductNameTxt.Margin = new System.Windows.Forms.Padding(2);
            this.SReturnProductNameTxt.Name = "SReturnProductNameTxt";
            this.SReturnProductNameTxt.ReadOnly = true;
            this.SReturnProductNameTxt.Size = new System.Drawing.Size(254, 20);
            this.SReturnProductNameTxt.TabIndex = 40;
            this.SReturnProductNameTxt.Text = "-";
            // 
            // SReturnUpdateRequestBtn
            // 
            this.SReturnUpdateRequestBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SReturnUpdateRequestBtn.FlatAppearance.BorderSize = 0;
            this.SReturnUpdateRequestBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SReturnUpdateRequestBtn.Font = new System.Drawing.Font("Futura Bk BT", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnUpdateRequestBtn.ForeColor = System.Drawing.Color.White;
            this.SReturnUpdateRequestBtn.Image = ((System.Drawing.Image)(resources.GetObject("SReturnUpdateRequestBtn.Image")));
            this.SReturnUpdateRequestBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SReturnUpdateRequestBtn.Location = new System.Drawing.Point(122, 348);
            this.SReturnUpdateRequestBtn.Name = "SReturnUpdateRequestBtn";
            this.SReturnUpdateRequestBtn.Size = new System.Drawing.Size(128, 42);
            this.SReturnUpdateRequestBtn.TabIndex = 36;
            this.SReturnUpdateRequestBtn.Text = "Update";
            this.SReturnUpdateRequestBtn.UseVisualStyleBackColor = false;
            this.SReturnUpdateRequestBtn.Click += new System.EventHandler(this.SReturnUpdateRequestBtn_Click);
            // 
            // SReturnUpdateStatusCmb
            // 
            this.SReturnUpdateStatusCmb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.SReturnUpdateStatusCmb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.SReturnUpdateStatusCmb.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnUpdateStatusCmb.FormattingEnabled = true;
            this.SReturnUpdateStatusCmb.Location = new System.Drawing.Point(77, 276);
            this.SReturnUpdateStatusCmb.Name = "SReturnUpdateStatusCmb";
            this.SReturnUpdateStatusCmb.Size = new System.Drawing.Size(255, 27);
            this.SReturnUpdateStatusCmb.TabIndex = 36;
            // 
            // SReturnUpdateInvoiceCmb
            // 
            this.SReturnUpdateInvoiceCmb.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnUpdateInvoiceCmb.FormattingEnabled = true;
            this.SReturnUpdateInvoiceCmb.Location = new System.Drawing.Point(73, 111);
            this.SReturnUpdateInvoiceCmb.Name = "SReturnUpdateInvoiceCmb";
            this.SReturnUpdateInvoiceCmb.Size = new System.Drawing.Size(259, 27);
            this.SReturnUpdateInvoiceCmb.TabIndex = 31;
            this.SReturnUpdateInvoiceCmb.SelectedIndexChanged += new System.EventHandler(this.SReturnUpdateInvoiceCmb_SelectedIndexChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(73, 161);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(109, 19);
            this.label19.TabIndex = 39;
            this.label19.Text = "Product Name";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(73, 242);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 19);
            this.label15.TabIndex = 35;
            this.label15.Text = "Status";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(72, 73);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(83, 19);
            this.label21.TabIndex = 30;
            this.label21.Text = "Invoice No";
            // 
            // SReturnUpdateStatusCancelBtn
            // 
            this.SReturnUpdateStatusCancelBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SReturnUpdateStatusCancelBtn.FlatAppearance.BorderSize = 0;
            this.SReturnUpdateStatusCancelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SReturnUpdateStatusCancelBtn.Font = new System.Drawing.Font("Futura Bk BT", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnUpdateStatusCancelBtn.ForeColor = System.Drawing.Color.White;
            this.SReturnUpdateStatusCancelBtn.Image = ((System.Drawing.Image)(resources.GetObject("SReturnUpdateStatusCancelBtn.Image")));
            this.SReturnUpdateStatusCancelBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SReturnUpdateStatusCancelBtn.Location = new System.Drawing.Point(257, 348);
            this.SReturnUpdateStatusCancelBtn.Name = "SReturnUpdateStatusCancelBtn";
            this.SReturnUpdateStatusCancelBtn.Size = new System.Drawing.Size(128, 42);
            this.SReturnUpdateStatusCancelBtn.TabIndex = 21;
            this.SReturnUpdateStatusCancelBtn.Text = "Cancel";
            this.SReturnUpdateStatusCancelBtn.UseVisualStyleBackColor = false;
            this.SReturnUpdateStatusCancelBtn.Click += new System.EventHandler(this.SReturnUpdateStatusCancelBtn_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Futura Bk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(30, 20);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(142, 22);
            this.label22.TabIndex = 0;
            this.label22.Text = "Update Request";
            // 
            // SReturnNewRequestPnl
            // 
            this.SReturnNewRequestPnl.BackColor = System.Drawing.Color.White;
            this.SReturnNewRequestPnl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SReturnNewRequestPnl.Controls.Add(this.SReturnQuantitytxt);
            this.SReturnNewRequestPnl.Controls.Add(this.SReturnReasonCmb);
            this.SReturnNewRequestPnl.Controls.Add(this.label42);
            this.SReturnNewRequestPnl.Controls.Add(this.Quantitytxt);
            this.SReturnNewRequestPnl.Controls.Add(this.SReturnProductNameCmb);
            this.SReturnNewRequestPnl.Controls.Add(this.SReturnProductName);
            this.SReturnNewRequestPnl.Controls.Add(this.SReturnSubmitNewRequestBtn);
            this.SReturnNewRequestPnl.Controls.Add(this.SReturnInvoiceNoCmb);
            this.SReturnNewRequestPnl.Controls.Add(this.label44);
            this.SReturnNewRequestPnl.Controls.Add(this.SReturnNewRequestCancelBtn);
            this.SReturnNewRequestPnl.Controls.Add(this.label45);
            this.SReturnNewRequestPnl.Location = new System.Drawing.Point(262, 148);
            this.SReturnNewRequestPnl.Name = "SReturnNewRequestPnl";
            this.SReturnNewRequestPnl.Size = new System.Drawing.Size(587, 325);
            this.SReturnNewRequestPnl.TabIndex = 102;
            this.SReturnNewRequestPnl.Visible = false;
            // 
            // SReturnQuantitytxt
            // 
            this.SReturnQuantitytxt.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnQuantitytxt.Location = new System.Drawing.Point(302, 176);
            this.SReturnQuantitytxt.Name = "SReturnQuantitytxt";
            this.SReturnQuantitytxt.Size = new System.Drawing.Size(239, 27);
            this.SReturnQuantitytxt.TabIndex = 93;
            // 
            // SReturnReasonCmb
            // 
            this.SReturnReasonCmb.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnReasonCmb.FormattingEnabled = true;
            this.SReturnReasonCmb.Location = new System.Drawing.Point(301, 106);
            this.SReturnReasonCmb.Name = "SReturnReasonCmb";
            this.SReturnReasonCmb.Size = new System.Drawing.Size(240, 27);
            this.SReturnReasonCmb.TabIndex = 92;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(298, 80);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(60, 19);
            this.label42.TabIndex = 91;
            this.label42.Text = "Reason";
            // 
            // Quantitytxt
            // 
            this.Quantitytxt.AutoSize = true;
            this.Quantitytxt.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Quantitytxt.ForeColor = System.Drawing.Color.Black;
            this.Quantitytxt.Location = new System.Drawing.Point(298, 144);
            this.Quantitytxt.Name = "Quantitytxt";
            this.Quantitytxt.Size = new System.Drawing.Size(69, 19);
            this.Quantitytxt.TabIndex = 89;
            this.Quantitytxt.Text = "Quantity";
            // 
            // SReturnProductNameCmb
            // 
            this.SReturnProductNameCmb.DropDownWidth = 319;
            this.SReturnProductNameCmb.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnProductNameCmb.FormattingEnabled = true;
            this.SReturnProductNameCmb.Location = new System.Drawing.Point(35, 176);
            this.SReturnProductNameCmb.Name = "SReturnProductNameCmb";
            this.SReturnProductNameCmb.Size = new System.Drawing.Size(240, 27);
            this.SReturnProductNameCmb.TabIndex = 88;
            // 
            // SReturnProductName
            // 
            this.SReturnProductName.AutoSize = true;
            this.SReturnProductName.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnProductName.Location = new System.Drawing.Point(32, 145);
            this.SReturnProductName.Name = "SReturnProductName";
            this.SReturnProductName.Size = new System.Drawing.Size(109, 19);
            this.SReturnProductName.TabIndex = 87;
            this.SReturnProductName.Text = "Product Name";
            // 
            // SReturnSubmitNewRequestBtn
            // 
            this.SReturnSubmitNewRequestBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SReturnSubmitNewRequestBtn.FlatAppearance.BorderSize = 0;
            this.SReturnSubmitNewRequestBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SReturnSubmitNewRequestBtn.Font = new System.Drawing.Font("Futura Bk BT", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnSubmitNewRequestBtn.ForeColor = System.Drawing.Color.White;
            this.SReturnSubmitNewRequestBtn.Image = ((System.Drawing.Image)(resources.GetObject("SReturnSubmitNewRequestBtn.Image")));
            this.SReturnSubmitNewRequestBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SReturnSubmitNewRequestBtn.Location = new System.Drawing.Point(279, 240);
            this.SReturnSubmitNewRequestBtn.Name = "SReturnSubmitNewRequestBtn";
            this.SReturnSubmitNewRequestBtn.Size = new System.Drawing.Size(128, 42);
            this.SReturnSubmitNewRequestBtn.TabIndex = 36;
            this.SReturnSubmitNewRequestBtn.Text = "Save";
            this.SReturnSubmitNewRequestBtn.UseVisualStyleBackColor = false;
            this.SReturnSubmitNewRequestBtn.Click += new System.EventHandler(this.SReturnSubmitNewRequestBtn_Click);
            // 
            // SReturnInvoiceNoCmb
            // 
            this.SReturnInvoiceNoCmb.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnInvoiceNoCmb.FormattingEnabled = true;
            this.SReturnInvoiceNoCmb.Location = new System.Drawing.Point(35, 107);
            this.SReturnInvoiceNoCmb.Name = "SReturnInvoiceNoCmb";
            this.SReturnInvoiceNoCmb.Size = new System.Drawing.Size(240, 27);
            this.SReturnInvoiceNoCmb.TabIndex = 31;
            this.SReturnInvoiceNoCmb.SelectedIndexChanged += new System.EventHandler(this.SReturnInvoiceNoCmb_SelectedIndexChanged);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Futura Bk BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(32, 80);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(88, 19);
            this.label44.TabIndex = 30;
            this.label44.Text = "Invoice No.";
            // 
            // SReturnNewRequestCancelBtn
            // 
            this.SReturnNewRequestCancelBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SReturnNewRequestCancelBtn.FlatAppearance.BorderSize = 0;
            this.SReturnNewRequestCancelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SReturnNewRequestCancelBtn.Font = new System.Drawing.Font("Futura Bk BT", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnNewRequestCancelBtn.ForeColor = System.Drawing.Color.White;
            this.SReturnNewRequestCancelBtn.Image = ((System.Drawing.Image)(resources.GetObject("SReturnNewRequestCancelBtn.Image")));
            this.SReturnNewRequestCancelBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SReturnNewRequestCancelBtn.Location = new System.Drawing.Point(413, 240);
            this.SReturnNewRequestCancelBtn.Name = "SReturnNewRequestCancelBtn";
            this.SReturnNewRequestCancelBtn.Size = new System.Drawing.Size(128, 42);
            this.SReturnNewRequestCancelBtn.TabIndex = 21;
            this.SReturnNewRequestCancelBtn.Text = "Cancel";
            this.SReturnNewRequestCancelBtn.UseVisualStyleBackColor = false;
            this.SReturnNewRequestCancelBtn.Click += new System.EventHandler(this.SReturnNewRequestCancelBtn_Click);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Futura Bk BT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(32, 31);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(118, 22);
            this.label45.TabIndex = 0;
            this.label45.Text = "New Request";
            // 
            // ReturnCount
            // 
            this.ReturnCount.AutoSize = true;
            this.ReturnCount.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReturnCount.Location = new System.Drawing.Point(21, 610);
            this.ReturnCount.Name = "ReturnCount";
            this.ReturnCount.Size = new System.Drawing.Size(128, 18);
            this.ReturnCount.TabIndex = 85;
            this.ReturnCount.Text = "Total records: ???";
            // 
            // SReturnDataGridView
            // 
            this.SReturnDataGridView.AllowUserToAddRows = false;
            this.SReturnDataGridView.AllowUserToDeleteRows = false;
            this.SReturnDataGridView.AllowUserToResizeColumns = false;
            this.SReturnDataGridView.AllowUserToResizeRows = false;
            this.SReturnDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.SReturnDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.SReturnDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SReturnDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.SReturnDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle25.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.SReturnDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.SReturnDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.SReturnDataGridView.DefaultCellStyle = dataGridViewCellStyle26;
            this.SReturnDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.SReturnDataGridView.EnableHeadersVisualStyles = false;
            this.SReturnDataGridView.GridColor = System.Drawing.Color.White;
            this.SReturnDataGridView.Location = new System.Drawing.Point(28, 145);
            this.SReturnDataGridView.Margin = new System.Windows.Forms.Padding(0);
            this.SReturnDataGridView.Name = "SReturnDataGridView";
            this.SReturnDataGridView.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.SReturnDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.SReturnDataGridView.RowHeadersVisible = false;
            this.SReturnDataGridView.RowHeadersWidth = 80;
            this.SReturnDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.SReturnDataGridView.RowsDefaultCellStyle = dataGridViewCellStyle28;
            this.SReturnDataGridView.RowTemplate.Height = 30;
            this.SReturnDataGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.SReturnDataGridView.Size = new System.Drawing.Size(943, 444);
            this.SReturnDataGridView.TabIndex = 103;
            // 
            // SReturnSearchPanel
            // 
            this.SReturnSearchPanel.Controls.Add(this.SReturnSearch);
            this.SReturnSearchPanel.Controls.Add(this.TxtReturnSearch);
            this.SReturnSearchPanel.Controls.Add(this.SearchLbl11);
            this.SReturnSearchPanel.Location = new System.Drawing.Point(453, 93);
            this.SReturnSearchPanel.Name = "SReturnSearchPanel";
            this.SReturnSearchPanel.Size = new System.Drawing.Size(519, 42);
            this.SReturnSearchPanel.TabIndex = 80;
            // 
            // SReturnSearch
            // 
            this.SReturnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SReturnSearch.FlatAppearance.BorderSize = 0;
            this.SReturnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SReturnSearch.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnSearch.ForeColor = System.Drawing.Color.White;
            this.SReturnSearch.Image = ((System.Drawing.Image)(resources.GetObject("SReturnSearch.Image")));
            this.SReturnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SReturnSearch.Location = new System.Drawing.Point(390, 0);
            this.SReturnSearch.Name = "SReturnSearch";
            this.SReturnSearch.Size = new System.Drawing.Size(128, 42);
            this.SReturnSearch.TabIndex = 76;
            this.SReturnSearch.Text = "      Search";
            this.SReturnSearch.UseVisualStyleBackColor = false;
            this.SReturnSearch.Click += new System.EventHandler(this.SReturnSearch_Click);
            // 
            // TxtReturnSearch
            // 
            this.TxtReturnSearch.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtReturnSearch.Location = new System.Drawing.Point(71, 9);
            this.TxtReturnSearch.Name = "TxtReturnSearch";
            this.TxtReturnSearch.Size = new System.Drawing.Size(310, 25);
            this.TxtReturnSearch.TabIndex = 75;
            // 
            // SearchLbl11
            // 
            this.SearchLbl11.AutoSize = true;
            this.SearchLbl11.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchLbl11.Location = new System.Drawing.Point(7, 12);
            this.SearchLbl11.Name = "SearchLbl11";
            this.SearchLbl11.Size = new System.Drawing.Size(58, 18);
            this.SearchLbl11.TabIndex = 74;
            this.SearchLbl11.Text = "Search:";
            // 
            // SReturnExitBtn
            // 
            this.SReturnExitBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SReturnExitBtn.FlatAppearance.BorderSize = 0;
            this.SReturnExitBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SReturnExitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnExitBtn.ForeColor = System.Drawing.Color.White;
            this.SReturnExitBtn.Image = ((System.Drawing.Image)(resources.GetObject("SReturnExitBtn.Image")));
            this.SReturnExitBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SReturnExitBtn.Location = new System.Drawing.Point(842, 670);
            this.SReturnExitBtn.Name = "SReturnExitBtn";
            this.SReturnExitBtn.Size = new System.Drawing.Size(128, 42);
            this.SReturnExitBtn.TabIndex = 62;
            this.SReturnExitBtn.Text = "     Close";
            this.SReturnExitBtn.UseVisualStyleBackColor = false;
            // 
            // SReturnUpdateBtn
            // 
            this.SReturnUpdateBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SReturnUpdateBtn.FlatAppearance.BorderSize = 0;
            this.SReturnUpdateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SReturnUpdateBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnUpdateBtn.ForeColor = System.Drawing.Color.White;
            this.SReturnUpdateBtn.Image = ((System.Drawing.Image)(resources.GetObject("SReturnUpdateBtn.Image")));
            this.SReturnUpdateBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SReturnUpdateBtn.Location = new System.Drawing.Point(688, 670);
            this.SReturnUpdateBtn.Name = "SReturnUpdateBtn";
            this.SReturnUpdateBtn.Size = new System.Drawing.Size(128, 42);
            this.SReturnUpdateBtn.TabIndex = 60;
            this.SReturnUpdateBtn.Text = "     Update";
            this.SReturnUpdateBtn.UseVisualStyleBackColor = false;
            this.SReturnUpdateBtn.Click += new System.EventHandler(this.SReturnUpdateBtn_Click);
            // 
            // Divider17
            // 
            this.Divider17.BackColor = System.Drawing.Color.Black;
            this.Divider17.Location = new System.Drawing.Point(24, 650);
            this.Divider17.Name = "Divider17";
            this.Divider17.Size = new System.Drawing.Size(943, 2);
            this.Divider17.TabIndex = 59;
            // 
            // SReturnNewBtn
            // 
            this.SReturnNewBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.SReturnNewBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(22)))), ((int)(((byte)(26)))));
            this.SReturnNewBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SReturnNewBtn.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SReturnNewBtn.ForeColor = System.Drawing.Color.White;
            this.SReturnNewBtn.Image = ((System.Drawing.Image)(resources.GetObject("SReturnNewBtn.Image")));
            this.SReturnNewBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SReturnNewBtn.Location = new System.Drawing.Point(536, 670);
            this.SReturnNewBtn.Name = "SReturnNewBtn";
            this.SReturnNewBtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SReturnNewBtn.Size = new System.Drawing.Size(128, 42);
            this.SReturnNewBtn.TabIndex = 58;
            this.SReturnNewBtn.Text = "    New";
            this.SReturnNewBtn.UseVisualStyleBackColor = false;
            this.SReturnNewBtn.Click += new System.EventHandler(this.SReturnNewBtn_Click);
            // 
            // Divider18
            // 
            this.Divider18.BackColor = System.Drawing.Color.Black;
            this.Divider18.Location = new System.Drawing.Point(27, 76);
            this.Divider18.Name = "Divider18";
            this.Divider18.Size = new System.Drawing.Size(943, 2);
            this.Divider18.TabIndex = 56;
            // 
            // SalesReturnLbl
            // 
            this.SalesReturnLbl.AutoSize = true;
            this.SalesReturnLbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalesReturnLbl.ForeColor = System.Drawing.Color.Black;
            this.SalesReturnLbl.Location = new System.Drawing.Point(372, 23);
            this.SalesReturnLbl.Name = "SalesReturnLbl";
            this.SalesReturnLbl.Size = new System.Drawing.Size(245, 39);
            this.SalesReturnLbl.TabIndex = 55;
            this.SalesReturnLbl.Text = "SALES RETURN";
            // 
            // LowStock
            // 
            this.LowStock.Controls.Add(this.StockCount);
            this.LowStock.Controls.Add(this.LStockSearchPanel);
            this.LowStock.Controls.Add(this.LStockCloseBtn);
            this.LowStock.Controls.Add(this.Divider13);
            this.LowStock.Controls.Add(this.LowStocksTbl);
            this.LowStock.Controls.Add(this.Divider14);
            this.LowStock.Controls.Add(this.LowStockLbl);
            this.LowStock.Location = new System.Drawing.Point(343, 12);
            this.LowStock.Name = "LowStock";
            this.LowStock.Size = new System.Drawing.Size(998, 735);
            this.LowStock.TabIndex = 73;
            this.LowStock.Visible = false;
            // 
            // StockCount
            // 
            this.StockCount.AutoSize = true;
            this.StockCount.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StockCount.Location = new System.Drawing.Point(21, 610);
            this.StockCount.Name = "StockCount";
            this.StockCount.Size = new System.Drawing.Size(128, 18);
            this.StockCount.TabIndex = 85;
            this.StockCount.Text = "Total records: ???";
            // 
            // LStockSearchPanel
            // 
            this.LStockSearchPanel.Controls.Add(this.LStockSearch);
            this.LStockSearchPanel.Controls.Add(this.TxtLStockSearch);
            this.LStockSearchPanel.Controls.Add(this.SearchLbl7);
            this.LStockSearchPanel.Location = new System.Drawing.Point(453, 93);
            this.LStockSearchPanel.Name = "LStockSearchPanel";
            this.LStockSearchPanel.Size = new System.Drawing.Size(519, 42);
            this.LStockSearchPanel.TabIndex = 80;
            // 
            // LStockSearch
            // 
            this.LStockSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.LStockSearch.FlatAppearance.BorderSize = 0;
            this.LStockSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LStockSearch.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LStockSearch.ForeColor = System.Drawing.Color.White;
            this.LStockSearch.Image = ((System.Drawing.Image)(resources.GetObject("LStockSearch.Image")));
            this.LStockSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LStockSearch.Location = new System.Drawing.Point(390, 0);
            this.LStockSearch.Name = "LStockSearch";
            this.LStockSearch.Size = new System.Drawing.Size(128, 42);
            this.LStockSearch.TabIndex = 76;
            this.LStockSearch.Text = "      Search";
            this.LStockSearch.UseVisualStyleBackColor = false;
            this.LStockSearch.Click += new System.EventHandler(this.LStockSearch_Click);
            // 
            // TxtLStockSearch
            // 
            this.TxtLStockSearch.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtLStockSearch.Location = new System.Drawing.Point(71, 9);
            this.TxtLStockSearch.Name = "TxtLStockSearch";
            this.TxtLStockSearch.Size = new System.Drawing.Size(310, 25);
            this.TxtLStockSearch.TabIndex = 75;
            // 
            // SearchLbl7
            // 
            this.SearchLbl7.AutoSize = true;
            this.SearchLbl7.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchLbl7.Location = new System.Drawing.Point(7, 12);
            this.SearchLbl7.Name = "SearchLbl7";
            this.SearchLbl7.Size = new System.Drawing.Size(58, 18);
            this.SearchLbl7.TabIndex = 74;
            this.SearchLbl7.Text = "Search:";
            // 
            // LStockCloseBtn
            // 
            this.LStockCloseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.LStockCloseBtn.FlatAppearance.BorderSize = 0;
            this.LStockCloseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LStockCloseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LStockCloseBtn.ForeColor = System.Drawing.Color.White;
            this.LStockCloseBtn.Image = ((System.Drawing.Image)(resources.GetObject("LStockCloseBtn.Image")));
            this.LStockCloseBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LStockCloseBtn.Location = new System.Drawing.Point(842, 670);
            this.LStockCloseBtn.Name = "LStockCloseBtn";
            this.LStockCloseBtn.Size = new System.Drawing.Size(128, 42);
            this.LStockCloseBtn.TabIndex = 62;
            this.LStockCloseBtn.Text = "     Close";
            this.LStockCloseBtn.UseVisualStyleBackColor = false;
            this.LStockCloseBtn.Click += new System.EventHandler(this.LStockCloseBtn_Click);
            // 
            // Divider13
            // 
            this.Divider13.BackColor = System.Drawing.Color.Black;
            this.Divider13.Location = new System.Drawing.Point(24, 650);
            this.Divider13.Name = "Divider13";
            this.Divider13.Size = new System.Drawing.Size(943, 2);
            this.Divider13.TabIndex = 59;
            // 
            // LowStocksTbl
            // 
            this.LowStocksTbl.AllowUserToAddRows = false;
            this.LowStocksTbl.AllowUserToDeleteRows = false;
            this.LowStocksTbl.AllowUserToResizeColumns = false;
            this.LowStocksTbl.AllowUserToResizeRows = false;
            this.LowStocksTbl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.LowStocksTbl.BackgroundColor = System.Drawing.Color.White;
            this.LowStocksTbl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.LowStocksTbl.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.LowStocksTbl.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle29.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.LowStocksTbl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.LowStocksTbl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.LowStocksTbl.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.LStockItem,
            this.LStockQuantity,
            this.LStockOrderP});
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.LowStocksTbl.DefaultCellStyle = dataGridViewCellStyle30;
            this.LowStocksTbl.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.LowStocksTbl.EnableHeadersVisualStyles = false;
            this.LowStocksTbl.GridColor = System.Drawing.Color.White;
            this.LowStocksTbl.Location = new System.Drawing.Point(27, 145);
            this.LowStocksTbl.Margin = new System.Windows.Forms.Padding(0);
            this.LowStocksTbl.Name = "LowStocksTbl";
            this.LowStocksTbl.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.LowStocksTbl.RowHeadersDefaultCellStyle = dataGridViewCellStyle31;
            this.LowStocksTbl.RowHeadersVisible = false;
            this.LowStocksTbl.RowHeadersWidth = 80;
            this.LowStocksTbl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle32.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.LowStocksTbl.RowsDefaultCellStyle = dataGridViewCellStyle32;
            this.LowStocksTbl.RowTemplate.Height = 30;
            this.LowStocksTbl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.LowStocksTbl.Size = new System.Drawing.Size(943, 444);
            this.LowStocksTbl.TabIndex = 57;
            // 
            // LStockItem
            // 
            this.LStockItem.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.LStockItem.FillWeight = 110F;
            this.LStockItem.HeaderText = "Item";
            this.LStockItem.Name = "LStockItem";
            // 
            // LStockQuantity
            // 
            this.LStockQuantity.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.LStockQuantity.FillWeight = 120F;
            this.LStockQuantity.HeaderText = "Quantity";
            this.LStockQuantity.Name = "LStockQuantity";
            // 
            // LStockOrderP
            // 
            this.LStockOrderP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.LStockOrderP.HeaderText = "Production Point";
            this.LStockOrderP.Name = "LStockOrderP";
            // 
            // Divider14
            // 
            this.Divider14.BackColor = System.Drawing.Color.Black;
            this.Divider14.Location = new System.Drawing.Point(27, 76);
            this.Divider14.Name = "Divider14";
            this.Divider14.Size = new System.Drawing.Size(943, 2);
            this.Divider14.TabIndex = 56;
            // 
            // LowStockLbl
            // 
            this.LowStockLbl.AutoSize = true;
            this.LowStockLbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LowStockLbl.ForeColor = System.Drawing.Color.Black;
            this.LowStockLbl.Location = new System.Drawing.Point(372, 23);
            this.LowStockLbl.Name = "LowStockLbl";
            this.LowStockLbl.Size = new System.Drawing.Size(311, 39);
            this.LowStockLbl.TabIndex = 55;
            this.LowStockLbl.Text = "LOW STOCK ITEMS";
            // 
            // CompletedSales
            // 
            this.CompletedSales.Controls.Add(this.CSalesSearchPanel);
            this.CompletedSales.Controls.Add(this.CompleteCount);
            this.CompletedSales.Controls.Add(this.CSalesCloseBtn);
            this.CompletedSales.Controls.Add(this.Divider9);
            this.CompletedSales.Controls.Add(this.CompletedSalesTbl);
            this.CompletedSales.Controls.Add(this.Divider10);
            this.CompletedSales.Controls.Add(this.CompletedSalesLbl);
            this.CompletedSales.Location = new System.Drawing.Point(343, 12);
            this.CompletedSales.Name = "CompletedSales";
            this.CompletedSales.Size = new System.Drawing.Size(998, 735);
            this.CompletedSales.TabIndex = 69;
            this.CompletedSales.Visible = false;
            // 
            // CSalesSearchPanel
            // 
            this.CSalesSearchPanel.Controls.Add(this.CSalesSearch);
            this.CSalesSearchPanel.Controls.Add(this.TxtCSalesSearch);
            this.CSalesSearchPanel.Controls.Add(this.Searchlbl4);
            this.CSalesSearchPanel.Location = new System.Drawing.Point(453, 93);
            this.CSalesSearchPanel.Name = "CSalesSearchPanel";
            this.CSalesSearchPanel.Size = new System.Drawing.Size(519, 42);
            this.CSalesSearchPanel.TabIndex = 86;
            // 
            // CSalesSearch
            // 
            this.CSalesSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.CSalesSearch.FlatAppearance.BorderSize = 0;
            this.CSalesSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CSalesSearch.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CSalesSearch.ForeColor = System.Drawing.Color.White;
            this.CSalesSearch.Image = ((System.Drawing.Image)(resources.GetObject("CSalesSearch.Image")));
            this.CSalesSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CSalesSearch.Location = new System.Drawing.Point(390, 0);
            this.CSalesSearch.Name = "CSalesSearch";
            this.CSalesSearch.Size = new System.Drawing.Size(128, 42);
            this.CSalesSearch.TabIndex = 76;
            this.CSalesSearch.Text = "      Search";
            this.CSalesSearch.UseVisualStyleBackColor = false;
            this.CSalesSearch.Click += new System.EventHandler(this.CSalesSearch_Click);
            // 
            // TxtCSalesSearch
            // 
            this.TxtCSalesSearch.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCSalesSearch.Location = new System.Drawing.Point(71, 9);
            this.TxtCSalesSearch.Name = "TxtCSalesSearch";
            this.TxtCSalesSearch.Size = new System.Drawing.Size(310, 25);
            this.TxtCSalesSearch.TabIndex = 75;
            // 
            // Searchlbl4
            // 
            this.Searchlbl4.AutoSize = true;
            this.Searchlbl4.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchlbl4.Location = new System.Drawing.Point(7, 12);
            this.Searchlbl4.Name = "Searchlbl4";
            this.Searchlbl4.Size = new System.Drawing.Size(58, 18);
            this.Searchlbl4.TabIndex = 74;
            this.Searchlbl4.Text = "Search:";
            // 
            // CompleteCount
            // 
            this.CompleteCount.AutoSize = true;
            this.CompleteCount.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompleteCount.Location = new System.Drawing.Point(21, 610);
            this.CompleteCount.Name = "CompleteCount";
            this.CompleteCount.Size = new System.Drawing.Size(128, 18);
            this.CompleteCount.TabIndex = 85;
            this.CompleteCount.Text = "Total records: ???";
            // 
            // CSalesCloseBtn
            // 
            this.CSalesCloseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.CSalesCloseBtn.FlatAppearance.BorderSize = 0;
            this.CSalesCloseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CSalesCloseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CSalesCloseBtn.ForeColor = System.Drawing.Color.White;
            this.CSalesCloseBtn.Image = ((System.Drawing.Image)(resources.GetObject("CSalesCloseBtn.Image")));
            this.CSalesCloseBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CSalesCloseBtn.Location = new System.Drawing.Point(842, 670);
            this.CSalesCloseBtn.Name = "CSalesCloseBtn";
            this.CSalesCloseBtn.Size = new System.Drawing.Size(128, 42);
            this.CSalesCloseBtn.TabIndex = 62;
            this.CSalesCloseBtn.Text = "     Close";
            this.CSalesCloseBtn.UseVisualStyleBackColor = false;
            this.CSalesCloseBtn.Click += new System.EventHandler(this.CSalesCloseBtn_Click);
            // 
            // Divider9
            // 
            this.Divider9.BackColor = System.Drawing.Color.Black;
            this.Divider9.Location = new System.Drawing.Point(24, 650);
            this.Divider9.Name = "Divider9";
            this.Divider9.Size = new System.Drawing.Size(943, 2);
            this.Divider9.TabIndex = 59;
            // 
            // CompletedSalesTbl
            // 
            this.CompletedSalesTbl.AllowUserToAddRows = false;
            this.CompletedSalesTbl.AllowUserToDeleteRows = false;
            this.CompletedSalesTbl.AllowUserToResizeColumns = false;
            this.CompletedSalesTbl.AllowUserToResizeRows = false;
            this.CompletedSalesTbl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.CompletedSalesTbl.BackgroundColor = System.Drawing.Color.White;
            this.CompletedSalesTbl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CompletedSalesTbl.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.CompletedSalesTbl.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle33.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle33.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.CompletedSalesTbl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle33;
            this.CompletedSalesTbl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.CompletedSalesTbl.DefaultCellStyle = dataGridViewCellStyle34;
            this.CompletedSalesTbl.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.CompletedSalesTbl.EnableHeadersVisualStyles = false;
            this.CompletedSalesTbl.GridColor = System.Drawing.Color.White;
            this.CompletedSalesTbl.Location = new System.Drawing.Point(27, 145);
            this.CompletedSalesTbl.Margin = new System.Windows.Forms.Padding(0);
            this.CompletedSalesTbl.Name = "CompletedSalesTbl";
            this.CompletedSalesTbl.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.CompletedSalesTbl.RowHeadersDefaultCellStyle = dataGridViewCellStyle35;
            this.CompletedSalesTbl.RowHeadersVisible = false;
            this.CompletedSalesTbl.RowHeadersWidth = 80;
            this.CompletedSalesTbl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle36.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.CompletedSalesTbl.RowsDefaultCellStyle = dataGridViewCellStyle36;
            this.CompletedSalesTbl.RowTemplate.Height = 30;
            this.CompletedSalesTbl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.CompletedSalesTbl.Size = new System.Drawing.Size(943, 444);
            this.CompletedSalesTbl.TabIndex = 57;
            // 
            // Divider10
            // 
            this.Divider10.BackColor = System.Drawing.Color.Black;
            this.Divider10.Location = new System.Drawing.Point(27, 76);
            this.Divider10.Name = "Divider10";
            this.Divider10.Size = new System.Drawing.Size(943, 2);
            this.Divider10.TabIndex = 56;
            // 
            // CompletedSalesLbl
            // 
            this.CompletedSalesLbl.AutoSize = true;
            this.CompletedSalesLbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompletedSalesLbl.ForeColor = System.Drawing.Color.Black;
            this.CompletedSalesLbl.Location = new System.Drawing.Point(337, 21);
            this.CompletedSalesLbl.Name = "CompletedSalesLbl";
            this.CompletedSalesLbl.Size = new System.Drawing.Size(310, 39);
            this.CompletedSalesLbl.TabIndex = 55;
            this.CompletedSalesLbl.Text = "COMPLETED SALES";
            // 
            // PaymentRecieved
            // 
            this.PaymentRecieved.Controls.Add(this.PaymentCount);
            this.PaymentRecieved.Controls.Add(this.PRecievedSearchPanel);
            this.PaymentRecieved.Controls.Add(this.PReceivedCloseBtn);
            this.PaymentRecieved.Controls.Add(this.Divider11);
            this.PaymentRecieved.Controls.Add(this.PaymentsTbl);
            this.PaymentRecieved.Controls.Add(this.Divider12);
            this.PaymentRecieved.Controls.Add(this.PaymentsRecievedLbl);
            this.PaymentRecieved.Location = new System.Drawing.Point(343, 12);
            this.PaymentRecieved.Name = "PaymentRecieved";
            this.PaymentRecieved.Size = new System.Drawing.Size(998, 735);
            this.PaymentRecieved.TabIndex = 74;
            this.PaymentRecieved.Visible = false;
            // 
            // PaymentCount
            // 
            this.PaymentCount.AutoSize = true;
            this.PaymentCount.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PaymentCount.Location = new System.Drawing.Point(21, 610);
            this.PaymentCount.Name = "PaymentCount";
            this.PaymentCount.Size = new System.Drawing.Size(128, 18);
            this.PaymentCount.TabIndex = 85;
            this.PaymentCount.Text = "Total records: ???";
            // 
            // PRecievedSearchPanel
            // 
            this.PRecievedSearchPanel.Controls.Add(this.PRecievedSearch);
            this.PRecievedSearchPanel.Controls.Add(this.TxtPRecievedSearch);
            this.PRecievedSearchPanel.Controls.Add(this.SearchLbl6);
            this.PRecievedSearchPanel.Location = new System.Drawing.Point(453, 93);
            this.PRecievedSearchPanel.Name = "PRecievedSearchPanel";
            this.PRecievedSearchPanel.Size = new System.Drawing.Size(517, 42);
            this.PRecievedSearchPanel.TabIndex = 80;
            // 
            // PRecievedSearch
            // 
            this.PRecievedSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.PRecievedSearch.FlatAppearance.BorderSize = 0;
            this.PRecievedSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PRecievedSearch.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PRecievedSearch.ForeColor = System.Drawing.Color.White;
            this.PRecievedSearch.Image = ((System.Drawing.Image)(resources.GetObject("PRecievedSearch.Image")));
            this.PRecievedSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PRecievedSearch.Location = new System.Drawing.Point(390, 0);
            this.PRecievedSearch.Name = "PRecievedSearch";
            this.PRecievedSearch.Size = new System.Drawing.Size(128, 42);
            this.PRecievedSearch.TabIndex = 76;
            this.PRecievedSearch.Text = "      Search";
            this.PRecievedSearch.UseVisualStyleBackColor = false;
            this.PRecievedSearch.Click += new System.EventHandler(this.PRecievedSearch_Click);
            // 
            // TxtPRecievedSearch
            // 
            this.TxtPRecievedSearch.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPRecievedSearch.Location = new System.Drawing.Point(71, 9);
            this.TxtPRecievedSearch.Name = "TxtPRecievedSearch";
            this.TxtPRecievedSearch.Size = new System.Drawing.Size(310, 25);
            this.TxtPRecievedSearch.TabIndex = 75;
            // 
            // SearchLbl6
            // 
            this.SearchLbl6.AutoSize = true;
            this.SearchLbl6.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchLbl6.Location = new System.Drawing.Point(7, 12);
            this.SearchLbl6.Name = "SearchLbl6";
            this.SearchLbl6.Size = new System.Drawing.Size(58, 18);
            this.SearchLbl6.TabIndex = 74;
            this.SearchLbl6.Text = "Search:";
            // 
            // PReceivedCloseBtn
            // 
            this.PReceivedCloseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.PReceivedCloseBtn.FlatAppearance.BorderSize = 0;
            this.PReceivedCloseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PReceivedCloseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PReceivedCloseBtn.ForeColor = System.Drawing.Color.White;
            this.PReceivedCloseBtn.Image = ((System.Drawing.Image)(resources.GetObject("PReceivedCloseBtn.Image")));
            this.PReceivedCloseBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PReceivedCloseBtn.Location = new System.Drawing.Point(842, 670);
            this.PReceivedCloseBtn.Name = "PReceivedCloseBtn";
            this.PReceivedCloseBtn.Size = new System.Drawing.Size(128, 42);
            this.PReceivedCloseBtn.TabIndex = 62;
            this.PReceivedCloseBtn.Text = "     Close";
            this.PReceivedCloseBtn.UseVisualStyleBackColor = false;
            this.PReceivedCloseBtn.Click += new System.EventHandler(this.PReceivedCloseBtn_Click);
            // 
            // Divider11
            // 
            this.Divider11.BackColor = System.Drawing.Color.Black;
            this.Divider11.Location = new System.Drawing.Point(24, 650);
            this.Divider11.Name = "Divider11";
            this.Divider11.Size = new System.Drawing.Size(943, 2);
            this.Divider11.TabIndex = 59;
            // 
            // PaymentsTbl
            // 
            this.PaymentsTbl.AllowUserToAddRows = false;
            this.PaymentsTbl.AllowUserToDeleteRows = false;
            this.PaymentsTbl.AllowUserToResizeColumns = false;
            this.PaymentsTbl.AllowUserToResizeRows = false;
            this.PaymentsTbl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.PaymentsTbl.BackgroundColor = System.Drawing.Color.White;
            this.PaymentsTbl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.PaymentsTbl.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.PaymentsTbl.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle37.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle37.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.PaymentsTbl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle37;
            this.PaymentsTbl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PaymentsTbl.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PRecievedDate,
            this.PRecievedInvoiceNo,
            this.PRCusName,
            this.PRTotalPayment});
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle38.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.PaymentsTbl.DefaultCellStyle = dataGridViewCellStyle38;
            this.PaymentsTbl.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.PaymentsTbl.EnableHeadersVisualStyles = false;
            this.PaymentsTbl.GridColor = System.Drawing.Color.White;
            this.PaymentsTbl.Location = new System.Drawing.Point(27, 145);
            this.PaymentsTbl.Margin = new System.Windows.Forms.Padding(0);
            this.PaymentsTbl.Name = "PaymentsTbl";
            this.PaymentsTbl.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle39.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle39.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.PaymentsTbl.RowHeadersDefaultCellStyle = dataGridViewCellStyle39;
            this.PaymentsTbl.RowHeadersVisible = false;
            this.PaymentsTbl.RowHeadersWidth = 80;
            this.PaymentsTbl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle40.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle40.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.PaymentsTbl.RowsDefaultCellStyle = dataGridViewCellStyle40;
            this.PaymentsTbl.RowTemplate.Height = 30;
            this.PaymentsTbl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.PaymentsTbl.Size = new System.Drawing.Size(943, 444);
            this.PaymentsTbl.TabIndex = 57;
            // 
            // PRecievedDate
            // 
            this.PRecievedDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PRecievedDate.FillWeight = 110F;
            this.PRecievedDate.HeaderText = "Date";
            this.PRecievedDate.Name = "PRecievedDate";
            // 
            // PRecievedInvoiceNo
            // 
            this.PRecievedInvoiceNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PRecievedInvoiceNo.FillWeight = 80F;
            this.PRecievedInvoiceNo.HeaderText = "Invoice No";
            this.PRecievedInvoiceNo.Name = "PRecievedInvoiceNo";
            // 
            // PRCusName
            // 
            this.PRCusName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PRCusName.HeaderText = "Customer Name";
            this.PRCusName.Name = "PRCusName";
            // 
            // PRTotalPayment
            // 
            this.PRTotalPayment.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PRTotalPayment.HeaderText = "Total Payment";
            this.PRTotalPayment.Name = "PRTotalPayment";
            // 
            // Divider12
            // 
            this.Divider12.BackColor = System.Drawing.Color.Black;
            this.Divider12.Location = new System.Drawing.Point(27, 76);
            this.Divider12.Name = "Divider12";
            this.Divider12.Size = new System.Drawing.Size(943, 2);
            this.Divider12.TabIndex = 56;
            // 
            // PaymentsRecievedLbl
            // 
            this.PaymentsRecievedLbl.AutoSize = true;
            this.PaymentsRecievedLbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PaymentsRecievedLbl.ForeColor = System.Drawing.Color.Black;
            this.PaymentsRecievedLbl.Location = new System.Drawing.Point(372, 23);
            this.PaymentsRecievedLbl.Name = "PaymentsRecievedLbl";
            this.PaymentsRecievedLbl.Size = new System.Drawing.Size(346, 39);
            this.PaymentsRecievedLbl.TabIndex = 55;
            this.PaymentsRecievedLbl.Text = "PAYMENTS RECIEVED";
            // 
            // InventorySummary
            // 
            this.InventorySummary.Controls.Add(this.SummaryCount);
            this.InventorySummary.Controls.Add(this.ISummaryCloseBtn);
            this.InventorySummary.Controls.Add(this.Divider15);
            this.InventorySummary.Controls.Add(this.InventorySummaryTbl);
            this.InventorySummary.Controls.Add(this.Divider16);
            this.InventorySummary.Controls.Add(this.InventorySummaryLbl);
            this.InventorySummary.Location = new System.Drawing.Point(343, 12);
            this.InventorySummary.Name = "InventorySummary";
            this.InventorySummary.Size = new System.Drawing.Size(998, 735);
            this.InventorySummary.TabIndex = 75;
            this.InventorySummary.Visible = false;
            // 
            // SummaryCount
            // 
            this.SummaryCount.AutoSize = true;
            this.SummaryCount.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryCount.Location = new System.Drawing.Point(21, 610);
            this.SummaryCount.Name = "SummaryCount";
            this.SummaryCount.Size = new System.Drawing.Size(128, 18);
            this.SummaryCount.TabIndex = 85;
            this.SummaryCount.Text = "Total records: ???";
            // 
            // ISummaryCloseBtn
            // 
            this.ISummaryCloseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.ISummaryCloseBtn.FlatAppearance.BorderSize = 0;
            this.ISummaryCloseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ISummaryCloseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ISummaryCloseBtn.ForeColor = System.Drawing.Color.White;
            this.ISummaryCloseBtn.Image = ((System.Drawing.Image)(resources.GetObject("ISummaryCloseBtn.Image")));
            this.ISummaryCloseBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ISummaryCloseBtn.Location = new System.Drawing.Point(842, 670);
            this.ISummaryCloseBtn.Name = "ISummaryCloseBtn";
            this.ISummaryCloseBtn.Size = new System.Drawing.Size(128, 42);
            this.ISummaryCloseBtn.TabIndex = 62;
            this.ISummaryCloseBtn.Text = "     Close";
            this.ISummaryCloseBtn.UseVisualStyleBackColor = false;
            this.ISummaryCloseBtn.Click += new System.EventHandler(this.ISummaryCloseBtn_Click);
            // 
            // Divider15
            // 
            this.Divider15.BackColor = System.Drawing.Color.Black;
            this.Divider15.Location = new System.Drawing.Point(24, 650);
            this.Divider15.Name = "Divider15";
            this.Divider15.Size = new System.Drawing.Size(943, 2);
            this.Divider15.TabIndex = 59;
            // 
            // InventorySummaryTbl
            // 
            this.InventorySummaryTbl.AllowUserToAddRows = false;
            this.InventorySummaryTbl.AllowUserToDeleteRows = false;
            this.InventorySummaryTbl.AllowUserToResizeColumns = false;
            this.InventorySummaryTbl.AllowUserToResizeRows = false;
            this.InventorySummaryTbl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.InventorySummaryTbl.BackgroundColor = System.Drawing.Color.White;
            this.InventorySummaryTbl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.InventorySummaryTbl.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.InventorySummaryTbl.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle41.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle41.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle41.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle41.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.InventorySummaryTbl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle41;
            this.InventorySummaryTbl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.InventorySummaryTbl.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ISummaryItem,
            this.ISummaryQuantityIn,
            this.ISummaryQuantityOut});
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle42.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle42.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.InventorySummaryTbl.DefaultCellStyle = dataGridViewCellStyle42;
            this.InventorySummaryTbl.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.InventorySummaryTbl.EnableHeadersVisualStyles = false;
            this.InventorySummaryTbl.GridColor = System.Drawing.Color.White;
            this.InventorySummaryTbl.Location = new System.Drawing.Point(27, 145);
            this.InventorySummaryTbl.Margin = new System.Windows.Forms.Padding(0);
            this.InventorySummaryTbl.Name = "InventorySummaryTbl";
            this.InventorySummaryTbl.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle43.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle43.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.InventorySummaryTbl.RowHeadersDefaultCellStyle = dataGridViewCellStyle43;
            this.InventorySummaryTbl.RowHeadersVisible = false;
            this.InventorySummaryTbl.RowHeadersWidth = 80;
            this.InventorySummaryTbl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle44.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.InventorySummaryTbl.RowsDefaultCellStyle = dataGridViewCellStyle44;
            this.InventorySummaryTbl.RowTemplate.Height = 30;
            this.InventorySummaryTbl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.InventorySummaryTbl.Size = new System.Drawing.Size(943, 444);
            this.InventorySummaryTbl.TabIndex = 57;
            // 
            // ISummaryItem
            // 
            this.ISummaryItem.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ISummaryItem.FillWeight = 110F;
            this.ISummaryItem.HeaderText = "Item Name";
            this.ISummaryItem.Name = "ISummaryItem";
            // 
            // ISummaryQuantityIn
            // 
            this.ISummaryQuantityIn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ISummaryQuantityIn.FillWeight = 80F;
            this.ISummaryQuantityIn.HeaderText = "Quantity In";
            this.ISummaryQuantityIn.Name = "ISummaryQuantityIn";
            // 
            // ISummaryQuantityOut
            // 
            this.ISummaryQuantityOut.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ISummaryQuantityOut.HeaderText = "Quantity Out";
            this.ISummaryQuantityOut.Name = "ISummaryQuantityOut";
            // 
            // Divider16
            // 
            this.Divider16.BackColor = System.Drawing.Color.Black;
            this.Divider16.Location = new System.Drawing.Point(27, 76);
            this.Divider16.Name = "Divider16";
            this.Divider16.Size = new System.Drawing.Size(943, 2);
            this.Divider16.TabIndex = 56;
            // 
            // InventorySummaryLbl
            // 
            this.InventorySummaryLbl.AutoSize = true;
            this.InventorySummaryLbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InventorySummaryLbl.ForeColor = System.Drawing.Color.Black;
            this.InventorySummaryLbl.Location = new System.Drawing.Point(372, 23);
            this.InventorySummaryLbl.Name = "InventorySummaryLbl";
            this.InventorySummaryLbl.Size = new System.Drawing.Size(373, 39);
            this.InventorySummaryLbl.TabIndex = 55;
            this.InventorySummaryLbl.Text = "INVENTORY SUMMARY";
            // 
            // AuditLog
            // 
            this.AuditLog.Controls.Add(this.AuditCount);
            this.AuditLog.Controls.Add(this.AuditSearchPanel);
            this.AuditLog.Controls.Add(this.AuditCloseBtn);
            this.AuditLog.Controls.Add(this.Divider19);
            this.AuditLog.Controls.Add(this.AuditLogTbl);
            this.AuditLog.Controls.Add(this.Divder20);
            this.AuditLog.Controls.Add(this.AuditLogLbl);
            this.AuditLog.Location = new System.Drawing.Point(343, 12);
            this.AuditLog.Name = "AuditLog";
            this.AuditLog.Size = new System.Drawing.Size(998, 735);
            this.AuditLog.TabIndex = 76;
            this.AuditLog.Visible = false;
            // 
            // AuditCount
            // 
            this.AuditCount.AutoSize = true;
            this.AuditCount.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AuditCount.Location = new System.Drawing.Point(21, 610);
            this.AuditCount.Name = "AuditCount";
            this.AuditCount.Size = new System.Drawing.Size(128, 18);
            this.AuditCount.TabIndex = 85;
            this.AuditCount.Text = "Total records: ???";
            // 
            // AuditSearchPanel
            // 
            this.AuditSearchPanel.Controls.Add(this.AuditSearch);
            this.AuditSearchPanel.Controls.Add(this.TxtAuditSearch);
            this.AuditSearchPanel.Controls.Add(this.SearchLbl8);
            this.AuditSearchPanel.Location = new System.Drawing.Point(453, 93);
            this.AuditSearchPanel.Name = "AuditSearchPanel";
            this.AuditSearchPanel.Size = new System.Drawing.Size(518, 42);
            this.AuditSearchPanel.TabIndex = 82;
            // 
            // AuditSearch
            // 
            this.AuditSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.AuditSearch.FlatAppearance.BorderSize = 0;
            this.AuditSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AuditSearch.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AuditSearch.ForeColor = System.Drawing.Color.White;
            this.AuditSearch.Image = ((System.Drawing.Image)(resources.GetObject("AuditSearch.Image")));
            this.AuditSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AuditSearch.Location = new System.Drawing.Point(390, 0);
            this.AuditSearch.Name = "AuditSearch";
            this.AuditSearch.Size = new System.Drawing.Size(128, 42);
            this.AuditSearch.TabIndex = 76;
            this.AuditSearch.Text = "      Search";
            this.AuditSearch.UseVisualStyleBackColor = false;
            this.AuditSearch.Click += new System.EventHandler(this.AuditSearch_Click);
            // 
            // TxtAuditSearch
            // 
            this.TxtAuditSearch.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtAuditSearch.Location = new System.Drawing.Point(71, 9);
            this.TxtAuditSearch.Name = "TxtAuditSearch";
            this.TxtAuditSearch.Size = new System.Drawing.Size(310, 25);
            this.TxtAuditSearch.TabIndex = 75;
            // 
            // SearchLbl8
            // 
            this.SearchLbl8.AutoSize = true;
            this.SearchLbl8.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchLbl8.Location = new System.Drawing.Point(7, 12);
            this.SearchLbl8.Name = "SearchLbl8";
            this.SearchLbl8.Size = new System.Drawing.Size(58, 18);
            this.SearchLbl8.TabIndex = 74;
            this.SearchLbl8.Text = "Search:";
            // 
            // AuditCloseBtn
            // 
            this.AuditCloseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            this.AuditCloseBtn.FlatAppearance.BorderSize = 0;
            this.AuditCloseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AuditCloseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AuditCloseBtn.ForeColor = System.Drawing.Color.White;
            this.AuditCloseBtn.Image = ((System.Drawing.Image)(resources.GetObject("AuditCloseBtn.Image")));
            this.AuditCloseBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AuditCloseBtn.Location = new System.Drawing.Point(842, 670);
            this.AuditCloseBtn.Name = "AuditCloseBtn";
            this.AuditCloseBtn.Size = new System.Drawing.Size(128, 42);
            this.AuditCloseBtn.TabIndex = 62;
            this.AuditCloseBtn.Text = "     Close";
            this.AuditCloseBtn.UseVisualStyleBackColor = false;
            // 
            // Divider19
            // 
            this.Divider19.BackColor = System.Drawing.Color.Black;
            this.Divider19.Location = new System.Drawing.Point(24, 650);
            this.Divider19.Name = "Divider19";
            this.Divider19.Size = new System.Drawing.Size(943, 2);
            this.Divider19.TabIndex = 59;
            // 
            // AuditLogTbl
            // 
            this.AuditLogTbl.AllowUserToAddRows = false;
            this.AuditLogTbl.AllowUserToDeleteRows = false;
            this.AuditLogTbl.AllowUserToResizeColumns = false;
            this.AuditLogTbl.AllowUserToResizeRows = false;
            this.AuditLogTbl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.AuditLogTbl.BackgroundColor = System.Drawing.Color.White;
            this.AuditLogTbl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AuditLogTbl.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.AuditLogTbl.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(20)))), ((int)(((byte)(24)))));
            dataGridViewCellStyle45.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle45.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle45.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle45.SelectionBackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle45.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle45.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.AuditLogTbl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle45;
            this.AuditLogTbl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle46.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle46.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle46.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle46.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle46.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle46.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.AuditLogTbl.DefaultCellStyle = dataGridViewCellStyle46;
            this.AuditLogTbl.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.AuditLogTbl.EnableHeadersVisualStyles = false;
            this.AuditLogTbl.GridColor = System.Drawing.Color.White;
            this.AuditLogTbl.Location = new System.Drawing.Point(27, 145);
            this.AuditLogTbl.Margin = new System.Windows.Forms.Padding(0);
            this.AuditLogTbl.Name = "AuditLogTbl";
            this.AuditLogTbl.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle47.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle47.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle47.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle47.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.AuditLogTbl.RowHeadersDefaultCellStyle = dataGridViewCellStyle47;
            this.AuditLogTbl.RowHeadersVisible = false;
            this.AuditLogTbl.RowHeadersWidth = 80;
            this.AuditLogTbl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle48.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle48.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.AuditLogTbl.RowsDefaultCellStyle = dataGridViewCellStyle48;
            this.AuditLogTbl.RowTemplate.Height = 30;
            this.AuditLogTbl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.AuditLogTbl.Size = new System.Drawing.Size(943, 444);
            this.AuditLogTbl.TabIndex = 57;
            // 
            // Divder20
            // 
            this.Divder20.BackColor = System.Drawing.Color.Black;
            this.Divder20.Location = new System.Drawing.Point(27, 76);
            this.Divder20.Name = "Divder20";
            this.Divder20.Size = new System.Drawing.Size(943, 2);
            this.Divder20.TabIndex = 56;
            // 
            // AuditLogLbl
            // 
            this.AuditLogLbl.AutoSize = true;
            this.AuditLogLbl.Font = new System.Drawing.Font("Futura Hv BT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AuditLogLbl.ForeColor = System.Drawing.Color.Black;
            this.AuditLogLbl.Location = new System.Drawing.Point(413, 16);
            this.AuditLogLbl.Name = "AuditLogLbl";
            this.AuditLogLbl.Size = new System.Drawing.Size(196, 39);
            this.AuditLogLbl.TabIndex = 55;
            this.AuditLogLbl.Text = "AUDIT LOG";
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // System1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1367, 759);
            this.ControlBox = false;
            this.Controls.Add(this.SalesOrder);
            this.Controls.Add(this.ItemProduction);
            this.Controls.Add(this.InventorySummary);
            this.Controls.Add(this.PaymentRecieved);
            this.Controls.Add(this.LowStock);
            this.Controls.Add(this.CompletedSales);
            this.Controls.Add(this.Item);
            this.Controls.Add(this.Invoice);
            this.Controls.Add(this.SalesReturn);
            this.Controls.Add(this.Dashboard);
            this.Controls.Add(this.Contacts);
            this.Controls.Add(this.AuditLog);
            this.Controls.Add(this.exitSys1Btn);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.MainMenu);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(343, 12);
            this.Name = "System1";
            this.Load += new System.EventHandler(this.System1_Load);
            this.Dashboard.ResumeLayout(false);
            this.Dashboard.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SalesChart)).EndInit();
            this.StockPanel.ResumeLayout(false);
            this.StockPanel.PerformLayout();
            this.StockPic.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ItemPanel.ResumeLayout(false);
            this.ItemPanel.PerformLayout();
            this.ItemPic.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.CustomerPanel.ResumeLayout(false);
            this.CustomerPanel.PerformLayout();
            this.CustomerPic.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.MReport.ResumeLayout(false);
            this.MSales.ResumeLayout(false);
            this.MainMenu.ResumeLayout(false);
            this.MInventory.ResumeLayout(false);
            this.Title.ResumeLayout(false);
            this.Title.PerformLayout();
            this.Contacts.ResumeLayout(false);
            this.Contacts.PerformLayout();
            this.ContactsSearchPanel.ResumeLayout(false);
            this.ContactsSearchPanel.PerformLayout();
            this.NewCus.ResumeLayout(false);
            this.NewCus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerTbl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EmployeeTbl)).EndInit();
            this.SalesOrder.ResumeLayout(false);
            this.SalesOrder.PerformLayout();
            this.SOrderUpdate.ResumeLayout(false);
            this.SOrderUpdate.PerformLayout();
            this.NewSOrder.ResumeLayout(false);
            this.NewSOrder.PerformLayout();
            this.SOrderSearchPanel.ResumeLayout(false);
            this.SOrderSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OSalesTbl)).EndInit();
            this.Item.ResumeLayout(false);
            this.Item.PerformLayout();
            this.pnl_AddItem.ResumeLayout(false);
            this.pnl_AddItem.PerformLayout();
            this.pnl_UpdtPrc.ResumeLayout(false);
            this.pnl_UpdtPrc.PerformLayout();
            this.ItemSearchPanel.ResumeLayout(false);
            this.ItemSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemTbl)).EndInit();
            this.ItemProduction.ResumeLayout(false);
            this.ItemProduction.PerformLayout();
            this.UPDTPRDCTN.ResumeLayout(false);
            this.UPDTPRDCTN.PerformLayout();
            this.pnl_NwPrdctn.ResumeLayout(false);
            this.pnl_NwPrdctn.PerformLayout();
            this.IProductionSearchPanel.ResumeLayout(false);
            this.IProductionSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemProductionTbl)).EndInit();
            this.Invoice.ResumeLayout(false);
            this.Invoice.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.InvoiceTbl)).EndInit();
            this.InvoiceSearchPanel.ResumeLayout(false);
            this.InvoiceSearchPanel.PerformLayout();
            this.SalesReturn.ResumeLayout(false);
            this.SalesReturn.PerformLayout();
            this.SReturnUpdateRequestPnl.ResumeLayout(false);
            this.SReturnUpdateRequestPnl.PerformLayout();
            this.SReturnNewRequestPnl.ResumeLayout(false);
            this.SReturnNewRequestPnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SReturnDataGridView)).EndInit();
            this.SReturnSearchPanel.ResumeLayout(false);
            this.SReturnSearchPanel.PerformLayout();
            this.LowStock.ResumeLayout(false);
            this.LowStock.PerformLayout();
            this.LStockSearchPanel.ResumeLayout(false);
            this.LStockSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LowStocksTbl)).EndInit();
            this.CompletedSales.ResumeLayout(false);
            this.CompletedSales.PerformLayout();
            this.CSalesSearchPanel.ResumeLayout(false);
            this.CSalesSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CompletedSalesTbl)).EndInit();
            this.PaymentRecieved.ResumeLayout(false);
            this.PaymentRecieved.PerformLayout();
            this.PRecievedSearchPanel.ResumeLayout(false);
            this.PRecievedSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PaymentsTbl)).EndInit();
            this.InventorySummary.ResumeLayout(false);
            this.InventorySummary.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InventorySummaryTbl)).EndInit();
            this.AuditLog.ResumeLayout(false);
            this.AuditLog.PerformLayout();
            this.AuditSearchPanel.ResumeLayout(false);
            this.AuditSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AuditLogTbl)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button exitSys1Btn;
        private System.Windows.Forms.Timer ContactsTransition;
        private System.Windows.Forms.Timer SalesTransition;
        private System.Windows.Forms.Timer ReportTransition;
        private System.Windows.Forms.Panel Dashboard;
        private System.Windows.Forms.Label TotalSalesLbl;
        private System.Windows.Forms.Label TotalSalesCount;
        private System.Windows.Forms.Label CompletedLbl;
        private System.Windows.Forms.Label InTransitLbl;
        private System.Windows.Forms.Label OrderPlacedLbl;
        private System.Windows.Forms.Label CompletedCount;
        private System.Windows.Forms.Label SalesActivityLbl;
        private System.Windows.Forms.Panel StockPanel;
        private System.Windows.Forms.Label TotalStock;
        private System.Windows.Forms.Panel StockPic;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label TotalStockLbl;
        private System.Windows.Forms.Panel ItemPanel;
        private System.Windows.Forms.Label TotalItems;
        private System.Windows.Forms.Panel ItemPic;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label TotalItemLbl;
        private System.Windows.Forms.Panel CustomerPanel;
        private System.Windows.Forms.Panel CustomerPic;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label TotalCustomer;
        private System.Windows.Forms.Label TotalCus;
        private System.Windows.Forms.Label DashboardLbl;
        private System.Windows.Forms.Panel Divider1;
        private System.Windows.Forms.Button logOutBtn;
        private System.Windows.Forms.FlowLayoutPanel MReport;
        private System.Windows.Forms.Button ReportBtn;
        private System.Windows.Forms.Button RLowStock;
        private System.Windows.Forms.Button RCompletedSales;
        private System.Windows.Forms.Button RPaymentsReceived;
        private System.Windows.Forms.Button RInventorySummary;
        private System.Windows.Forms.FlowLayoutPanel MSales;
        private System.Windows.Forms.Button SalesBtn;
        private System.Windows.Forms.Button SOrder;
        private System.Windows.Forms.Button SInvoice;
        private System.Windows.Forms.Button SReturn;
        private System.Windows.Forms.Button DashboardBtn;
        private System.Windows.Forms.FlowLayoutPanel MainMenu;
        private System.Windows.Forms.Label Logo;
        private System.Windows.Forms.Panel Title;
        private System.Windows.Forms.FlowLayoutPanel MInventory;
        private System.Windows.Forms.Button InventoryBtn;
        private System.Windows.Forms.Button ItemBtn;
        private System.Windows.Forms.Button ItemProductionBtn;
        private System.Windows.Forms.Timer InventoryTransition;
        private System.Windows.Forms.Panel Contacts;
        private System.Windows.Forms.Button ContactsCloseBtn;
        private System.Windows.Forms.Panel Divider3;
        public System.Windows.Forms.DataGridView EmployeeTbl;
        private System.Windows.Forms.Panel Divider2;
        private System.Windows.Forms.Label EmpLbl;
        private System.Windows.Forms.Label CusLbl;
        public System.Windows.Forms.DataGridView CustomerTbl;
        private System.Windows.Forms.Button cusNew;
        private System.Windows.Forms.Button ContactsBtn;
        private System.Windows.Forms.Panel SalesOrder;
        private System.Windows.Forms.Button SOrderExitBtn1;
        private System.Windows.Forms.Button SOrderUpdateBtn1;
        private System.Windows.Forms.Panel SOrderDivider;
        private System.Windows.Forms.Button SOrderNewBtn1;
        public System.Windows.Forms.DataGridView OSalesTbl;
        private System.Windows.Forms.Panel Divider;
        private System.Windows.Forms.Label SalesOrderLbl;
        private System.Windows.Forms.Panel Item;
        private System.Windows.Forms.Button ItemCloseBtn;
        private System.Windows.Forms.Button ItemUpdateBtn;
        private System.Windows.Forms.Panel Divider5;
        private System.Windows.Forms.Button NewItemBtn;
        public System.Windows.Forms.DataGridView ItemTbl;
        private System.Windows.Forms.Panel Divider6;
        private System.Windows.Forms.Label ItemLbl;
        private System.Windows.Forms.Panel ItemProduction;
        private System.Windows.Forms.Button IProductionCloseBtn;
        private System.Windows.Forms.Button IProductionUpdateBtn;
        private System.Windows.Forms.Panel Divider22;
        private System.Windows.Forms.Button IProductionNewBtn;
        public System.Windows.Forms.DataGridView ItemProductionTbl;
        private System.Windows.Forms.DataGridViewTextBoxColumn IProductDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn IProductionNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn IItemID;
        private System.Windows.Forms.DataGridViewTextBoxColumn IProduct;
        private System.Windows.Forms.DataGridViewTextBoxColumn IQuantity;
        private System.Windows.Forms.Panel Divider21;
        private System.Windows.Forms.Label ItemProductionLbl;
        private System.Windows.Forms.Panel Invoice;
        private System.Windows.Forms.Button CloseInvoiceBtn;
        private System.Windows.Forms.Panel Divider7;
        private System.Windows.Forms.Label Invoicelbl;
        private System.Windows.Forms.Panel Divider8;
        private System.Windows.Forms.Panel SalesReturn;
        private System.Windows.Forms.Button SReturnExitBtn;
        private System.Windows.Forms.Button SReturnUpdateBtn;
        private System.Windows.Forms.Panel Divider17;
        private System.Windows.Forms.Button SReturnNewBtn;
        private System.Windows.Forms.Panel Divider18;
        private System.Windows.Forms.Label SalesReturnLbl;
        private System.Windows.Forms.Panel LowStock;
        private System.Windows.Forms.Button LStockCloseBtn;
        private System.Windows.Forms.Panel Divider13;
        public System.Windows.Forms.DataGridView LowStocksTbl;
        private System.Windows.Forms.Panel Divider14;
        private System.Windows.Forms.Label LowStockLbl;
        private System.Windows.Forms.Button RAuditLog;
        private System.Windows.Forms.Panel CompletedSales;
        private System.Windows.Forms.Button CSalesCloseBtn;
        private System.Windows.Forms.Panel Divider9;
        public System.Windows.Forms.DataGridView CompletedSalesTbl;
        private System.Windows.Forms.Panel Divider10;
        private System.Windows.Forms.Label CompletedSalesLbl;
        private System.Windows.Forms.Panel PaymentRecieved;
        private System.Windows.Forms.Button PReceivedCloseBtn;
        private System.Windows.Forms.Panel Divider11;
        public System.Windows.Forms.DataGridView PaymentsTbl;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRecievedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRecievedInvoiceNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRCusName;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRTotalPayment;
        private System.Windows.Forms.Panel Divider12;
        private System.Windows.Forms.Label PaymentsRecievedLbl;
        private System.Windows.Forms.Panel InventorySummary;
        private System.Windows.Forms.Button ISummaryCloseBtn;
        private System.Windows.Forms.Panel Divider15;
        public System.Windows.Forms.DataGridView InventorySummaryTbl;
        private System.Windows.Forms.DataGridViewTextBoxColumn ISummaryItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn ISummaryQuantityIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ISummaryQuantityOut;
        private System.Windows.Forms.Panel Divider16;
        private System.Windows.Forms.Label InventorySummaryLbl;
        private System.Windows.Forms.Panel AuditLog;
        private System.Windows.Forms.Button AuditCloseBtn;
        private System.Windows.Forms.Panel Divider19;
        public System.Windows.Forms.DataGridView AuditLogTbl;
        private System.Windows.Forms.Panel Divder20;
        private System.Windows.Forms.Label AuditLogLbl;
        private System.Windows.Forms.Panel SOrderUpdate;
        private System.Windows.Forms.Label UpdateSalesStatusLbl;
        private System.Windows.Forms.Button SOrderUpExitBtn;
        private System.Windows.Forms.Button SOrderUpStatusBtn;
        private System.Windows.Forms.Label SOrderLbl1;
        private System.Windows.Forms.ComboBox SOrderStatusCbx1;
        private System.Windows.Forms.Label SInvoiceLbl2;
        private System.Windows.Forms.ComboBox InvoiceCbx1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOrderDate1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOrderID1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOrderInvoice1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOrderCustomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOrderStatus1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOrderDueDate1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOrderEmployeeID;
        private System.Windows.Forms.Label OrderPlacedCount;
        private System.Windows.Forms.Label InTransitCount;
        private System.Windows.Forms.DataVisualization.Charting.Chart SalesChart;
        private System.Windows.Forms.Label SalesOrderSummaryLbl;
        private System.Windows.Forms.Label CustomerCount;
        private System.Windows.Forms.Label EmployeeCount;
        private System.Windows.Forms.Panel ItemSearchPanel;
        private System.Windows.Forms.Button ItemSearch;
        private System.Windows.Forms.TextBox TxtItemSearch;
        private System.Windows.Forms.Label SearchLbl2;
        private System.Windows.Forms.Panel SReturnSearchPanel;
        private System.Windows.Forms.Button SReturnSearch;
        private System.Windows.Forms.TextBox TxtReturnSearch;
        private System.Windows.Forms.Label SearchLbl11;
        private System.Windows.Forms.Panel LStockSearchPanel;
        private System.Windows.Forms.Button LStockSearch;
        private System.Windows.Forms.TextBox TxtLStockSearch;
        private System.Windows.Forms.Label SearchLbl7;
        private System.Windows.Forms.Panel PRecievedSearchPanel;
        private System.Windows.Forms.Button PRecievedSearch;
        private System.Windows.Forms.TextBox TxtPRecievedSearch;
        private System.Windows.Forms.Label SearchLbl6;
        private System.Windows.Forms.Panel AuditSearchPanel;
        private System.Windows.Forms.Button AuditSearch;
        private System.Windows.Forms.TextBox TxtAuditSearch;
        private System.Windows.Forms.Label SearchLbl8;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeId;
        private System.Windows.Forms.DataGridViewTextBoxColumn DDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn PNumber;
        private System.Windows.Forms.Label ItemCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn FullName;
        private System.Windows.Forms.DataGridViewTextBoxColumn PNumber2;
        private System.Windows.Forms.Label ProductionCount;
        private System.Windows.Forms.Label AuditCount;
        private System.Windows.Forms.Label OrderCount;
        private System.Windows.Forms.Label ReturnCount;
        private System.Windows.Forms.Label SummaryCount;
        private System.Windows.Forms.Label InvoiceCount;
        private System.Windows.Forms.Label StockCount;
        private System.Windows.Forms.Label CompleteCount;
        private System.Windows.Forms.Label PaymentCount;
        private System.Windows.Forms.Panel Divider4;
        private System.Windows.Forms.Panel ContactsSearchPanel;
        private System.Windows.Forms.Button ContactsSearch;
        private System.Windows.Forms.TextBox TxtSearch;
        private System.Windows.Forms.Label SearchLbl1;
        private System.Windows.Forms.Panel SOrderSearchPanel;
        private System.Windows.Forms.Button SOrderSearch;
        private System.Windows.Forms.TextBox TxtOrderSearch;
        private System.Windows.Forms.Label SearchLbl12;
        private System.Windows.Forms.Panel NewCus;
        private System.Windows.Forms.Label NewCustomerContact;
        private System.Windows.Forms.TextBox txtPNum;
        private System.Windows.Forms.Label PhoneNumber;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.Label LastName;
        private System.Windows.Forms.Label FirstName;
        private System.Windows.Forms.Button CusCancel;
        private System.Windows.Forms.Button CusSaveBtn;
        private System.Windows.Forms.Panel IProductionSearchPanel;
        private System.Windows.Forms.Button IProductionSearch;
        private System.Windows.Forms.TextBox TxtProductionSearch;
        private System.Windows.Forms.Label SearchLbl14;
        private System.Windows.Forms.Panel InvoiceSearchPanel;
        private System.Windows.Forms.Button InvoiceSearch;
        private System.Windows.Forms.TextBox TxtInvoiceSearch;
        private System.Windows.Forms.Label SearchLbl3;
        private System.Windows.Forms.Panel CSalesSearchPanel;
        private System.Windows.Forms.Button CSalesSearch;
        private System.Windows.Forms.TextBox TxtCSalesSearch;
        private System.Windows.Forms.Label Searchlbl4;
        private System.Windows.Forms.Panel NewSOrder;
        private System.Windows.Forms.Button NewSOrderClose;
        private System.Windows.Forms.Label NewOrderLabel;
        private System.Windows.Forms.Button NewSOrderSave;
        private System.Windows.Forms.Label SQuantityLabel;
        private System.Windows.Forms.ComboBox SProductCBX;
        private System.Windows.Forms.Label SProductLabel;
        private System.Windows.Forms.Label SCustomerLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button NewSOrderAdd;
        private System.Windows.Forms.TextBox TxtQuantity;
        private System.Windows.Forms.Button SOrderClear;
        private System.Windows.Forms.ComboBox SCustomerCBX;
        private System.Windows.Forms.ListView OrderList;
        private System.Windows.Forms.DateTimePicker DueDate;
        private System.Windows.Forms.Label DueDateLbl;
        private System.Windows.Forms.Panel pnl_UpdtPrc;
        private System.Windows.Forms.TextBox TxtbxUntPrc;
        private System.Windows.Forms.Label lblUntPrc;
        private System.Windows.Forms.Button bttnUpdte;
        private System.Windows.Forms.Button UppdtBtncncl;
        private System.Windows.Forms.Panel pnl_AddItem;
        private System.Windows.Forms.TextBox txtbx_ROrdrLvl;
        private System.Windows.Forms.Label lbl_ROrdrLvl;
        private System.Windows.Forms.TextBox txtbx_Dscrptn;
        private System.Windows.Forms.Label lbl_Dscptn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtbx_Prc;
        private System.Windows.Forms.Label lbl_Prc;
        private System.Windows.Forms.TextBox txtbx_Nme;
        private System.Windows.Forms.Label lbl_ItmNme;
        private System.Windows.Forms.Button AddItmCnclbttn;
        private System.Windows.Forms.Button bttnAddItm;
        private System.Windows.Forms.Label UpdatePrce;
        private System.Windows.Forms.Label lblPrdctNme;
        private System.Windows.Forms.ComboBox comboBox_ProductID;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Label lblSubTotal;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblOrder;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        public System.Windows.Forms.DataGridView InvoiceTbl;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoicedate;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoiceno;
        private System.Windows.Forms.DataGridViewTextBoxColumn customername;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalamount;
        private System.Windows.Forms.DataGridViewImageColumn print;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemUnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCategory;
        private System.Windows.Forms.Panel UPDTPRDCTN;
        private System.Windows.Forms.ComboBox operationCB;
        private System.Windows.Forms.Label lbl_RsnUpdt;
        private System.Windows.Forms.Button UpdateClose;
        private System.Windows.Forms.Button BTTN_PrdctnUpdt;
        private System.Windows.Forms.Label lbl_QnttyUpdt;
        private System.Windows.Forms.Label lbl_PrdctUpdte;
        private System.Windows.Forms.ComboBox UpdtPrdctCBX;
        private System.Windows.Forms.Label lbl_UpdtPrdctn;
        private System.Windows.Forms.Panel pnl_NwPrdctn;
        private System.Windows.Forms.ListView LVProductList;
        private System.Windows.Forms.ColumnHeader Quantity;
        private System.Windows.Forms.ColumnHeader Product;
        private System.Windows.Forms.Button bttn_Clear;
        private System.Windows.Forms.Label lbl_OrderList;
        private System.Windows.Forms.Button bttn_Add;
        private System.Windows.Forms.TextBox txtbx_Qntty;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cmbbx_Product;
        private System.Windows.Forms.Label lbl_Product;
        private System.Windows.Forms.Button bttn_Save;
        private System.Windows.Forms.Button bttn_Cancel;
        private System.Windows.Forms.Label lbl_Nwprdctn;
        private System.Windows.Forms.TextBox Reason;
        private System.Windows.Forms.TextBox txtbx_QnttyUpdte;
        private System.Windows.Forms.Panel SReturnUpdateRequestPnl;
        private System.Windows.Forms.Button SReturnUpdateRequestBtn;
        private System.Windows.Forms.ComboBox SReturnUpdateStatusCmb;
        private System.Windows.Forms.ComboBox SReturnUpdateInvoiceCmb;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button SReturnUpdateStatusCancelBtn;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox SReturnProductNameTxt;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel SReturnNewRequestPnl;
        private System.Windows.Forms.TextBox SReturnQuantitytxt;
        private System.Windows.Forms.ComboBox SReturnReasonCmb;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label Quantitytxt;
        private System.Windows.Forms.ComboBox SReturnProductNameCmb;
        private System.Windows.Forms.Label SReturnProductName;
        private System.Windows.Forms.Button SReturnSubmitNewRequestBtn;
        private System.Windows.Forms.ComboBox SReturnInvoiceNoCmb;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Button SReturnNewRequestCancelBtn;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox productiobCBX;
        public System.Windows.Forms.DataGridView SReturnDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn LStockItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn LStockQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn LStockOrderP;
        private System.Windows.Forms.DataGridViewTextBoxColumn productname;
        private System.Windows.Forms.DataGridViewTextBoxColumn qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitprice;
        private System.Windows.Forms.DataGridViewTextBoxColumn total;
    }
}